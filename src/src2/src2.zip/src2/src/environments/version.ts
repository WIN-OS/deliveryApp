// IMPORTANT: THIS FILE IS AUTO GENERATED! DO NOT MANUALLY EDIT OR CHECKIN!
/* eslint-disable */
export const VERSION = {
  short: 'd1d7fe3',
  branch: 'develop',
  version: '0.0.1',
  date: '2024-02-13',
};
/* eslint-enable */
