import { NgxLoggerLevel } from 'ngx-logger';
//import { AppEnvironment } from '../app/shared/model/app-environment';
import { AppEnvironmentName } from '../app/shared/model/app-environment-name';
import { VERSION } from './version';
import { STAGING_API_URL } from '../app/shared/constants';

export const environment = {
  production: true,
  envName: AppEnvironmentName.PROD,

  loggingLevel: NgxLoggerLevel.DEBUG,
  serverLoggingLevel: NgxLoggerLevel.OFF,
  disableConsoleLogging: false,

  apiUrl: 'https://retail-prd.apps.rosa.nxb.uw2.aws.vsp.com',
  openIdUrl: 'https://api-staging.vspglobal.com/idp/userinfo.openid',
  patientEncounterUrl: 'https://api.vsp.com',
  oauthApiUrl: 'https://api.vsp.com',
  oauthClientId : 'vsp-retail-admin-ui',
  oauthScopes : 'read:gb.retailadmin write:gb.retailadmin read:vc.pe_management provider_view auth_employee openid profile auth_employee_sso',
  oauthRedirectPageUrl:'https://2020admin.pub.eyefinity.com',
  applicationUrl: 'https://2020admin.pub.eyefinity.com',
  sessionConfig: {
    idle: 1800,
    timeout: 30
  },
  showBuildNumbers: false,
  repository: 'repo',

  //oauthScopes :  'auth_employee_sso openid profile write:gb.retailadmin read:gb.retailadmin read:vc.pe_management provider_view',
  // Possible values: 'HH:mm:ss.SSS' (custom), ' ' (to remove); see also https://angular.io/api/common/DatePipe
  timestampFormat: 'HH:mm:ss.SSS',

  // for debugging and testing
  useDebugMode: false, // This will display dom values of components in the UI to debug potential sync issues
  mockDatabase: false, // This can be set to true to use subbed calls to the api

  /*
  {
  "apiUrl": "https://api.vsp.com",
  "patientEncounterUrl": "https://api.vsp.com",
  "oauthUrl": "https://api.vsp.com",
  "applicationUrl": "https://2020admin.vsp.com",
  "showBuildNumbers": false,
  "uiCommonVersion": "1.233",
  "repository": "repo"
}
  */
};
