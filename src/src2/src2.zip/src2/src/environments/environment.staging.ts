// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

//import { AppEnvironment } from '../app/shared/model/app-environment';
import { AppEnvironmentName } from '../app/shared/model/app-environment-name';
import { NgxLoggerLevel } from 'ngx-logger';

export const environment = {
  production: false,
  envName: AppEnvironmentName.STG,

  loggingLevel: NgxLoggerLevel.DEBUG,
  serverLoggingLevel: NgxLoggerLevel.OFF,
  disableConsoleLogging: false,

  apiUrl: 'https://retail-stg.apps.rosa.nxb.uw2.aws.vsp.com',
  openIdUrl: 'https://api-staging.vspglobal.com/idp/userinfo.openid',
  patientEncounterUrl: 'https://api-acpt.vsp.com',
  oauthApiUrl: 'https://api-acpt.vsp.com',
  oauthClientId : 'vsp-retail-admin-ui',
  oauthScopes : 'read:gb.retailadmin write:gb.retailadmin read:vc.pe_management provider_view auth_employee openid profile auth_employee_sso',
  oauthRedirectPageUrl: 'https://2020admin-stg.pub.eyefinity.com',
  applicationUrl: 'https://2020admin-stg.pub.eyefinity.com',
  sessionConfig: {
    idle: 1800,
    timeout: 30
  },
  showBuildNumbers: false,
  repository: 'repo',

  //oauthScopes :  'auth_employee_sso openid profile write:gb.retailadmin read:gb.retailadmin read:vc.pe_management provider_view',
  // Possible values: 'HH:mm:ss.SSS' (custom), ' ' (to remove); see also https://angular.io/api/common/DatePipe
  timestampFormat: 'HH:mm:ss.SSS',

  // for debugging and testing
  useDebugMode: false, // This will display dom values of components in the UI to debug potential sync issues
  mockDatabase: false, // This can be set to true to use subbed calls to the api

  /*
{
  "apiUrl": "https://api-acpt.vsp.com",
  "patientEncounterUrl": "https://api-acpt.vsp.com",
  "oauthUrl": "https://api-staging.vsp.com",
  "applicationUrl": "https://2020admin-stg.vsp.com",
  "showBuildNumbers": false,
  "uiCommonVersion": "1.233",
  "repository": "repo"
}

*/

};
