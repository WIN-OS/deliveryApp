import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LandingPageComponent } from './public/landing-page/landing-page.component';
import { AccessDeniedComponent } from './public/access-denied/access-denied.component';
import { AccountSearchComponent } from './secured/pages/account-search/account-search.component';
//import { EditProfileFormComponent } from './shared/vsp-ui-components/edit-profile-form/edit-profile-form.component';
import {AuthGuard} from './core/oauth/guards/auth.guard';
import { CreateAccountComponent } from './secured/pages/create-account/create-account.component';
import { SearchResultsComponent } from './secured/pages/account-search/search-results/search-results.component';
import { MessagesComponent } from './secured/pages/messages/messages.component';
import { AccountDetailsComponent } from './secured/pages/account-details/account-details.component';
import { EditProfileComponent } from './secured/pages/edit-account/edit-profile/edit-profile.component';
import { EditAccountComponent } from './secured/pages/edit-account/edit-account.component';
import { EditPasswordComponent } from './secured/pages/edit-account/edit-password/edit-password.component';
import { ReferenceTableComponent } from './secured/pages/reference-table/reference-table.component';
import { EditAuthorizedUsersComponent } from './secured/pages/edit-account/edit-authorized-users/edit-authorized-users.component';
import { EditContactUsComponent } from './secured/pages/edit-contact-us/edit-contact-us.component';
import { EditManualsComponent } from './secured/pages/edit-manuals/edit-manuals.component';
import { EditPopulationsComponent } from './secured/pages/edit-populations/edit-populations.component';


const routes: Routes = [
  { path: 'secured', loadChildren: () => import('./secured/secured.module').then(m => m.SecuredModule) },
  { path: 'shared', loadChildren: () => import('./shared/shared.module').then(m => m.SharedModule) },
  { path: 'sat-account-search', component: AccountSearchComponent, canActivate: [AuthGuard] },
  { path: 'sat-create-account', component: CreateAccountComponent, canActivate: [AuthGuard] },
  { path: 'sat-search-results', component: SearchResultsComponent, canActivate: [AuthGuard] },
  { path: 'sat-account-details', component: AccountDetailsComponent, canActivate: [AuthGuard] },
  { path: 'sat-edit-populations', component: EditPopulationsComponent, canActivate: [AuthGuard] },
  { path: 'sat-edit-account', component: EditAccountComponent,
    children: [
      { path: 'sat-edit-profile', component: EditProfileComponent, canActivate: [AuthGuard] },
      { path: 'sat-edit-password', component: EditPasswordComponent, canActivate: [AuthGuard] },
      { path: 'sat-edit-authorized-users', component: EditAuthorizedUsersComponent, canActivate: [AuthGuard] },
      { path: '', redirectTo: 'sat-edit-profile', pathMatch: 'full' }
    ],
    canActivate: [AuthGuard] },
  { path: 'sat-messages', component: MessagesComponent, canActivate: [AuthGuard] },
  { path: 'sat-edit-manuals', component: EditManualsComponent, canActivate: [AuthGuard] },
  { path: 'sat-edit-contact-us', component: EditContactUsComponent, canActivate: [AuthGuard] },
  { path: 'sat-reference-table', component: ReferenceTableComponent, canActivate: [AuthGuard]},
  { path: 'oauth_redirect.html', pathMatch: 'full', redirectTo: 'sat-account-search'},
  { path: '', redirectTo: 'sat-account-search', pathMatch: 'full' },
  { path: 'home', component: LandingPageComponent },
  { path: '**', component: AccessDeniedComponent }
];

//canActivate: [canActivateUser]},
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]

})
export class AppRoutingModule { }
