/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/naming-convention */
import { Injectable, inject } from '@angular/core';
import { ApiConfigService } from 'app/core/api-config.service';
import { BaseHttpService } from 'app/core/base-http.service';
import { IHttpClient } from 'app/shared/model/http-client.interface';
import { QueryBuilderService } from 'app/shared/services/query-builder.service';
import { environment } from 'environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccountActivityHistoryApiService extends BaseHttpService {

  apiConfigService = inject(ApiConfigService);
  queryBuilderService = inject(QueryBuilderService);
  //http = inject

  public serviceUrl: string;

  constructor(
    httpClient: IHttpClient,
    ) {
      super(httpClient);
      this.serviceUrl = environment.apiUrl
  }

  private readonly URL = `${environment.apiUrl}/retail-admin/accountactivities`;
  
   buildApiUrl(accountNumber : string, paginationState: boolean):string{
    // build a query string from the pagination state
     const queryString = this.queryBuilderService.buildQueryStringFromObject('', {paginationState: paginationState});
      console.log('buildApiUrl history query: ',[this.URL, accountNumber].join('/') + queryString);
    // combine the base URL, account number and query string
    // {domain}/retail-admin-account/accountactivities/{accountNumber}?paginationQueryString
    return [this.URL, accountNumber].join('/') + queryString;
  }
  
  getActivity(accountNumber:string, paginationState: any):Observable<any>{
    // if pagination state is not defined set it to true to use the default pagination state
    paginationState = paginationState || true;

    // get the history records
    console.log('History Query: ',this.buildApiUrl(accountNumber, paginationState));
    const someresp = this.get(this.buildApiUrl(accountNumber, paginationState));
    console.log('response in History ', JSON.stringify(someresp));
    return this.get(this.buildApiUrl(accountNumber, paginationState));
}

}
