/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/naming-convention */
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { BaseHttpService } from 'app/core/base-http.service';
import { IHttpClient } from 'app/shared/model/http-client.interface';
import { ICreateAccountForm, ICreateAccountFormPayload } from 'app/shared/model/interfaces';
import { environment } from 'environments/environment';
import { Observable, catchError, map, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CreateAccountApiService {

  serviceUrl = `${environment.apiUrl}/retail-admin/account`;
  http = inject(HttpClient);

  // sends a request to the appropriate API
  createAccount(createAccountPayload: ICreateAccountFormPayload): Observable<any>  {
    return this.http.post(this.serviceUrl,createAccountPayload).pipe(
      map(data  => {
        console.log('Create Account Response: ',JSON.stringify(data));
        // return the response
        return data;
      }),
      catchError(this.handleError)
    );
  }

  private handleError(error:HttpErrorResponse):Observable<never>{
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong.
      console.error(`Backend returned code ${error.status}, body was: ${error.error}`);
    }
    // Return an observable with a user-facing error message.
    return throwError(() => 'Something bad happened; please try again later.');
  }

}
