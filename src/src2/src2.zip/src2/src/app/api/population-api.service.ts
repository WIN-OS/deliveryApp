/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/naming-convention */
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { ApiConfigService } from 'app/core/api-config.service';
import { IPopulationList, IPopulationListResponse } from 'app/shared/model/interfaces';
import { environment } from 'environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PopulationApiService {

  private URL = `${environment.apiUrl}/retail-admin/population`; 
  // TODO - Update this with your actual API URL
  selectedPopulation = new BehaviorSubject<IPopulationList>({
    populationId: 1008,
    populationName: '',
    programIdBenefitDescList:   [
      {
      programId : '',
    benefitDescription: '',
  }]
});

  constructor(private http: HttpClient, private apiConfig:ApiConfigService) { }

  private formatPopulations(populations: IPopulationList[]): void {
    if (!populations) {
      return;
    }
    populations.sort(this.sortByPopulationName);
  }

  private sortByPopulationName(a: any, b: any): number {
    if (a.populationName < b.populationName) {
      return -1;
    }
    if (a.populationName > b.populationName) {
      return 1;
    }
    return 0;
  }

  private buildUrlWithPopulationId(populationId: string): string {
    return `${this.URL}/${populationId}`;
  }

  private buildPopulationPayload(population: any): any {
    return {
      populationName: population.populationName,
      programIdBenefitDescList: this.buildProgramIdBenefitDescListForPayload(population)
    };
  }

  private buildProgramIdBenefitDescListForPayload(population: any): any[] {
    const programIdBenefitDescList : any[] = [];
    for (let i = 0; i < population.programIdBenefitDescList.length; i++) {
      const benefit = population.programIdBenefitDescList[i];
      programIdBenefitDescList.push({
        programId: benefit.programId,
        benefitDescription: benefit.benefitDescription
      });
    }
    return programIdBenefitDescList;
  }

  getAllPopulations(): Observable<any> {
     return this.http.get<IPopulationListResponse>(this.URL).pipe(
      map((response) => {
   this.formatPopulations(response.populationList);
   console.log('getAllPopulations after formatted API: ', JSON.stringify(response));
        return response;
      })
    );
  }

  createPopulation(population: any): Observable<any> {
    const payload = this.buildPopulationPayload(population);
    return this.http.post(this.URL, payload);
  }

  updatePopulation(population: any): Observable<any> {
    const payload = this.buildPopulationPayload(population);
    return this.http.put(this.buildUrlWithPopulationId(population.populationId), payload);
  }

  deletePopulation(population: any): Observable<any> {
    const payload = {
      populationName: population.populationName
    };
    return this.http.put(this.buildUrlWithPopulationId(population.populationId), payload);
  }

 getSelectedPopulationSub(): Observable<IPopulationList> | null {
  if(this.selectedPopulation){
    return this.selectedPopulation.asObservable();
  }else{
    return null;
  }
  }

  setSelectedPopulation(selectedPopulation: IPopulationList):void{
 this.selectedPopulation.next(selectedPopulation);
  }

}
