/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/naming-convention */
import { Injectable, OnDestroy, inject } from '@angular/core';
import { environment } from '../../environments/environment';
import { QueryBuilderService } from '../shared/services/query-builder.service';
import { IAccount, IAccountSearchFormQuery, IAccountSearchResponse } from '../shared/model/interfaces';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { AuthorizedUsersService } from '../shared/services/authorized-users.service';
import { BehaviorSubject, Observable, Subject, catchError, map, throwError } from 'rxjs';
import { ApiConfigService } from 'app/core/api-config.service';
import { Router } from '@angular/router';
import { SaveStateService } from 'app/core/save-state.service';
import { RouteHelperService } from 'app/shared/services/route-helper.service';

@Injectable({
  providedIn: 'root'
})
export class AccountSearchApiService {
  private destroy$ = new Subject<void>();
  private requestNewSearchSubject = new Subject<any>();
  private clearSearchResultsSubject = new BehaviorSubject<void>(undefined);
  private newSearchResultsSubject = new BehaviorSubject<any>(null);
  clickedLinkSubject = new Subject<any>();


  queryBuilderService = inject(QueryBuilderService);
  apiConfigService = inject(ApiConfigService);
  http = inject(HttpClient);
  authorizedUsersService = inject(AuthorizedUsersService);

   // Constants for save state keys
   private SAVE_STATE_KEYS = {
    SEARCH_INPUTS: 'ACCOUNT_SEARCH_INPUTS',
    SEARCH_RESULTS: 'ACCOUNT_SEARCH_RESULTS'
  };

  // Constants for account search events
  private ACCOUNT_SEARCH_EVENTS = {
    REQUEST_NEW_SEARCH: 'vsp.accountSearch.requestNewSearch', // Event when something is requesting the search form to perform a new search
    CLEAR_SEARCH_RESULTS: 'vsp.accountSearch.clearSearchResults', // Event to request the search results view to clear results
    NEW_SEARCH_RESULTS: 'vsp.accountSearch.newSearchResults' // Event when we have new search results
  };

  constructor(private router: Router, private saveStateService: SaveStateService, private routeHelperService: RouteHelperService) {}

  // Sends the REQUEST_NEW_SEARCH event
  sendRequestNewSearchEvent(searchCriteria: Partial<IAccountSearchFormQuery>): void {
    // Route to the Account Search page (will do nothing if already on the page)
  //  this.routeHelperService.goToAccountSearch().then(() => {
  //    setTimeout(() => {
        // Emit the REQUEST_NEW_SEARCH after a timeout (timeout is required because we need to wait
        // for the page to finish compiling if transitioning)
        console.log('inside sendRequestNewSearchEvent');
        this.requestNewSearchSubject.next(searchCriteria);
     // });
   // });
  }

  // Listens to the REQUEST_NEW_SEARCH event and invokes the supplied callback
  onRequestNewSearch(): Observable<any> {
    return this.requestNewSearchSubject.asObservable();
  }

  // Sends the CLEAR_SEARCH_RESULTS event
  sendClearSearchResultsEvent(): void {
    this.clearSearchResultsSubject.next();
  }

  // Listens to the CLEAR_SEARCH_RESULTS event and invokes the supplied callback
  onClearSearchResults(): Observable<void> {
    return this.clearSearchResultsSubject.asObservable();
  }

  // Sends the NEW_SEARCH_RESULTS event
  sendNewSearchResultsEvent(searchData: any): void {
    // Store the inputs used for this search so that we can restore them if necessary
    this.saveStateService.saveStateData(this.SAVE_STATE_KEYS.SEARCH_INPUTS, searchData.stateData, { safeRoutes: ['/sat-account-details'] });

    this.newSearchResultsSubject.next(searchData);
  }

  // Listens to the NEW_SEARCH_RESULTS event and invokes the supplied callback
  onNewSearchResults(): Observable<any> {
    return this.newSearchResultsSubject.asObservable();
  }

  // Save state and go to Account Details
  saveStateAndGoToAccountDetails(account: any, previousAccountSearch: any): Promise<boolean> {
    // Store the previous search data so that we can restore it later
    this.saveStateService.saveStateData(this.SAVE_STATE_KEYS.SEARCH_RESULTS, previousAccountSearch, { safeRoutes: ['/sat-account-details'], copy: false });

    return this.routeHelperService.goToAccountDetails({ account: account });
  }

  // Go back to Account Search, restoring the previous inputs and search data
  restoreAccountSearch(): Promise<boolean> {
    return this.routeHelperService.goToAccountSearch({
      savedState: {
        searchFormData: this.saveStateService.getStateData(this.SAVE_STATE_KEYS.SEARCH_INPUTS),
        searchResultsData: this.saveStateService.getStateData(this.SAVE_STATE_KEYS.SEARCH_RESULTS)
      }
    });
  }
  
  /*
  // Expose observables for components to subscribe to
  requestNewSearch$ = this.requestNewSearchSubject.asObservable();
  clearSearchResults$ = this.clearSearchResultsSubject.asObservable();
  newSearchResults$ = this.newSearchResultsSubject.asObservable();
  */


  private readonly URL = `${environment.apiUrl}/retail-admin/accounts`;


  private buildUrl(queryObject:string, paginationState:string):string{
    // combine the URL with the search and pagination parameters
    return this.URL + this.queryBuilderService.buildQueryStringFromObject(queryObject, {paginationState: paginationState});
  }

    private formatAccounts(accounts:IAccount[]):void{
      // exit if accounts is not defined
      if (!accounts){
          return;
      }

      // loop through each account
      for (const account of accounts){
          // create a ui object on the account
          account.ui = {
              // statusString will be "Active" if status = "1" or "4", otherwise "Inactive"
              statusString: account.status && (account.status === '1' || account.status === '4') ? 'Active' : 'Inactive'
          };

          // format the authorized users if there are any present
          if (account.users){
              this.authorizedUsersService.formatAuthorizedUsers(account.users,account.users[0].accountUserEmail);
          }
      }
    }

    search(queryObject: any, paginationState?: any): Observable<any> {

      // if pagination state is not defined set it to true to use the default pagination state
      paginationState = paginationState || true;

      // perform the search
      return this.http.get<IAccountSearchResponse>(this.buildUrl(queryObject, paginationState)).pipe(
        map(data  => {
          console.log('AccountSearchResponse: ',JSON.stringify(data));
          // format the accounts response
          this.formatAccounts(data.accounts);
          // return the response
          return data;
        }),
        catchError(this.handleError)
      );
    }


    private handleError(error:HttpErrorResponse):Observable<never>{
      if (error.error instanceof ErrorEvent) {
        // A client-side or network error occurred. Handle it accordingly.
        console.error('An error occurred:', error.error.message);
      } else {
        // The backend returned an unsuccessful response code.
        // The response body may contain clues as to what went wrong.
        console.error(`Backend returned code ${error.status}, body was: ${error.error}`);
      }
      // Return an observable with a user-facing error message.
      return throwError(() => 'Something bad happened; please try again later.');
    }

   


}


/* call these service methods

 private destroy$ = new Subject<void>();

  constructor(private accountSearchService: AccountSearchService) {
    // Listen for new search requests
    this.accountSearchService.requestNewSearch$
      .pipe(takeUntil(this.destroy$))
      .subscribe((searchCriteria) => {
        // Handle the search criteria
        // Example: Perform a new search
      });

    // Listen for clear search results requests
    this.accountSearchService.clearSearchResults$
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        // Handle clearing search results
        // Example: Clear the search results view
      });

    // Listen for new search results
    this.accountSearchService.newSearchResults$
      .pipe(takeUntil(this.destroy$))
      .subscribe((searchData) => {
        // Handle the new search results
        // Example: Update the UI with the search data
      });
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  */