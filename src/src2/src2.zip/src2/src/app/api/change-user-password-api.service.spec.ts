import { TestBed } from '@angular/core/testing';

import { ChangeUserPasswordApiService } from './change-user-password-api.service';

describe('ChangeUserPasswordApiService', () => {
  let service: ChangeUserPasswordApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ChangeUserPasswordApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
