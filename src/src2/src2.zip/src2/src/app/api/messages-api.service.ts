/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/naming-convention */
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { ApiConfigService } from 'app/core/api-config.service';
import { QueryBuilderService } from 'app/shared/services/query-builder.service';
import { Subject } from 'rxjs';
import { IMessageQuery, IMessages, IMessagesResponse, IPaginationObj, IRetailMessages } from 'app/shared/model/interfaces';
import { DateUtilService } from 'app/core/date-util.service';
//import { DateService } from 'common/date.service';
import * as moment from 'moment-timezone';


  @Injectable({
    providedIn: 'root'
  })
  export class MessagesApiService {
    BASE_URL = `${this.apiConfig.baseUrl}/retail-admin/messages`;
  
    constructor(
      private http: HttpClient,
      private apiConfig: ApiConfigService,
      private queryBuilderService: QueryBuilderService,
      //private messagesService: MessagesService,
      private dateService: DateUtilService
    ) { }
  
    buildSearchUrl(queryObject: any, paginationState: boolean | IPaginationObj | undefined): string {
      // combine the GET_URL with the search and pagination parameters
      return this.BASE_URL + this.queryBuilderService.buildQueryStringFromObject(queryObject, {paginationState: paginationState});
    }
  
    buildUpdateUrl(messageId: any): string {
      // join the base URL and the message ID (i.e. {domain}/retail-admin-message/12345
      return `${this.BASE_URL}/${messageId}`;
    }
  
    getMessages(searchQueryObject: IMessageQuery, paginationState: boolean | IPaginationObj | undefined): Observable<any> {
      // perform the http call
      return this.http.get<IMessagesResponse>(this.buildSearchUrl(searchQueryObject, paginationState)).pipe(
        tap(response => {
          if(response.retailMessages){
            // format the messages response
            this.formatMessages(response.retailMessages);
          }
        })
      );
    }
  
    // invokes the Create Message API, returns the $http promise
    createMessage(message: any): Observable<any> {
      return this.http.post(this.BASE_URL, message);
    }
  
    // invokes the Update Message API, returns the $http promise
    updateMessage(messageId: any, message: any): Observable<any> {
      return this.http.put(this.buildUpdateUrl(messageId), message);
    }

  /* Combining Messages Service and MessagesApiService from LEGACY app into one */

  private addMessageEvent = new Subject<any>();

  // Events:
  addMessage$ = this.addMessageEvent.asObservable();

  //constructor() { }

  // sends the ADD_MESSAGE event
  sendAddMessageEvent(newMessage: any): void {
    this.addMessageEvent.next(newMessage);
  }

  // formats all messages in the list of messages
  formatMessages(messages: string | any[]): void {
    // do nothing if messages is not defined
    if (!messages){
      return;
    }

    // loop through each message and set the UI-specific properties
    for (let i = 0, l = messages.length; i < l; i++){
      this.updateUiProperties(messages[i]);
    }
  }

  // sets the ui object and properties on the message. the ui object contains additionally formatted data that the UI can
  // take advantage of without modifying the original message data
  updateUiProperties(message: IMessages): void {
    // do nothing if the message is not defined
    if (!message){
      return;
    }

    // initialize the ui object if it has not been already
    if (!message.ui){
      message.ui = {};
    }

    // sets the ui.populationsString property by joining the populations array with a comma and line-break
    if (message.populations && message.populations instanceof Array){
      message.ui.populationsString = message.populations.join(',\n');
    }

    // build the start date-time string by joining the startDate and startTime
    message.ui.startDateTimeString = this.getDateTimeString(message.startDate, message.startTime);

    if (message.endDate && message.endTime){
      // if the message has an endDate, build the end date-time string by joining the endDate and endTime
      message.ui.endDateTimeString = this.getDateTimeString(message.endDate, message.endTime);
    }
    else {
      // message has no endDate or endTime - set endDateString to "No End Date"
      message.ui.endDateTimeString = 'No End Date';
    }

    // set the status properties
    this.setStatus(message);
  }

  getDateTimeString(date: any, time: any): string {
    return [date, time].join(' ').trim();
  }

  // sets the status and isActive property on the message by checking the "to" date to see if it is prior to the current time
  setStatus(message: IMessages): void {
    let isActive;

    // If the message has the messageStatus attribute from the API, use this to determine if its active/inactive.
    if (message.messageStatus) {
      isActive = this.checkMessageStatusFlag(message);
    } else {
      // If the message is newly created, check the end date to determine if it is active or not.
      // Can't do an API call as it will break the sorting rules.

      // if the message doesn't have endDate and endTime, this is a static message (never expires) - it is always active
      if (!(message.endDate && message.endTime)){
        isActive = true;
      }
      else {
        const localTimePST = this.dateService.getDateInPacificTime(new Date());
        // convert the endDateTimeString to a date object
        const expirationDate = this.dateService.getDateObjectFromDateTimeString(message.ui.endDateTimeString);

        // compare the date object to the current date/time. if it is later than right now, the message is active
        isActive = expirationDate! > localTimePST;
      }

    }

    // set the status and isActive properties on the ui object
    message.ui.isActive = isActive;
    message.ui.status = isActive ? 'Active' : 'Inactive';
  }

  checkMessageStatusFlag(message: IMessages): boolean {
    return message.messageStatus == 'ACTIVE' ? true : false;
  }
  }
  