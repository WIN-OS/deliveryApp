import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';

import { ApiConfigService } from 'app/core/api-config.service';
import { Manual, ManualDTO, PopulationDTO } from 'app/shared/model/manuals.model';

@Injectable({
  providedIn: 'root'
})
export class ManualsApiService {
  private readonly baseUrl = `${this.apiConfigService.baseUrl}/retail-admin`;

  constructor(private httpClient: HttpClient, private apiConfigService: ApiConfigService) {} 

  getPopulations(): Observable<PopulationDTO> {
    return this.httpClient.get<PopulationDTO>(`${this.baseUrl}/population`)
      .pipe(
        catchError(this.handleError)
      );
  }

  getManual(populationId: number): Observable<ManualDTO> {
    return this.httpClient.get<ManualDTO>(`${this.baseUrl}/manual/${populationId}`)
      .pipe(
        catchError(this.handleError)
      );
  }

  uploadManuals(populationId: number, files: File[]) {
    const formData = new FormData();
    files.forEach((f, i) => {
      formData.append(`pdfFile[${i}]`, f);
    });

    return this.httpClient.post<ManualDTO>(`${this.baseUrl}/manual/${populationId}`, formData)
      .pipe(
        catchError(this.handleError)
      );
  }

  deleteManual(manualId: number): Observable<Manual> {
    return this.httpClient.delete<Manual>(`${this.baseUrl}/manual/${manualId}`)
      .pipe(
        catchError(this.handleError)
      );
  }


  private handleError(error: HttpErrorResponse) {
    if (error.status === 0) {
      console.error('An error occurred:', error.error);
    } else {
      console.error(
        `Backend returned code ${error.status}, body was: ${error.error}`);
    }

    return throwError(() => new Error(`A problem was encountered processing your request, please try again. 
      If you are still experiencing a problem, check back at a later time.`));
  }
}
