import { TestBed } from '@angular/core/testing';

import { CreateAccountApiService } from './create-api.service';

describe('CreateApiService', () => {
  let service: CreateAccountApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CreateAccountApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
