/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/naming-convention */
import { HttpClient } from '@angular/common/http';
import { Inject, Injectable, inject } from '@angular/core';
import { BaseHttpService } from 'app/core/base-http.service';
import { IHttpClient } from 'app/shared/model/http-client.interface';
import { environment } from 'environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccountSettingsApiService extends BaseHttpService {

  public serviceUrl: string;

  constructor(
    httpClient: IHttpClient,
    ) {
      super(httpClient);
      this.serviceUrl = environment.apiUrl;
  }


  private BASE_URL = 'retail-admin';
  private CLAIM_FORM_URL = 'accountclaimformlink';
  private STATUS_URL = 'accountstatus';
  private LEGACY_2020_URL = 'accountlegacyappaccess';

  //private http = inject(HttpClient);
  private buildApiUrl(actionUrl: string, accountNumber: string): string {
      // {BASE_URL}/retail-admin-account/{actionUrl}/{accountNumber}
      // i.e https://api.vspglobal.com/retail-admin-account/accountstatus/12345       
    return `${this.BASE_URL}/${actionUrl}/${accountNumber}`;
  }

  // sends a request to the appropriate API
  private updateAccountStatus(actionUrl: string, accountNumber: string, activate: boolean): any  {
   try {
     // build the full URL for the request
     const fullUrl = this.buildApiUrl(actionUrl, accountNumber);
     // to activate the status option, request a PUT. Request DELETE to deactivate
     const action = activate ? 'put' : 'delete';
     if(action === 'put'){
       // send the request and return the promise
       return this.put<any>(fullUrl,{});
      } else if(action === 'delete'){
        return this.delete(fullUrl);
      }
    } catch (err){
       console.log('Error',err);
       }
  }

  // /retail-admin-account/accountstatus
  // updates the overall account status (activate or deactivate)            
  updateStatus(accountNumber: string, activate: boolean): Observable<any> {
    return this.updateAccountStatus(this.STATUS_URL, accountNumber, activate);
  }

  // /retail-admin-account/accountclaimformlink
  // updates the account's access to the claim form (activate or deactivate)          
  updateClaimFormAccess(accountNumber: string, activate: boolean): Observable<any> {
    return this.updateAccountStatus(this.CLAIM_FORM_URL, accountNumber, activate);
  }

   // /retail-admin-account/accountlegacyappaccess
  // updates the account's access to the legacy 2020 system (activate or deactivate)          
  updateLegacy2020Access(accountNumber: string, activate: boolean): Observable<any> {
    return this.updateAccountStatus(this.LEGACY_2020_URL, accountNumber, activate);
  }
}
//|| 'updateClaimFormAccess' || 'updateLegacy2020Access' || 'accountActivityHistory'