import { TestBed } from '@angular/core/testing';

import { PopulationApiService } from './population-api.service';

describe('PopulationApiService', () => {
  let service: PopulationApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PopulationApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
