import { TestBed } from '@angular/core/testing';

import { AccountSettingsApiService } from './account-settings-api.service';

describe('AccountSettingsApiService', () => {
  let service: AccountSettingsApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AccountSettingsApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
