/* eslint-disable @typescript-eslint/no-explicit-any */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ChangeUserPasswordApiService {
  baseUrl = `${environment.apiUrl}/retail-admin/userprofile/password`;
  private newEditUserSubject = new BehaviorSubject<unknown>(null);
  
  constructor(
    private http: HttpClient,

  ) { }

  buildUrl(accountNumber:string, emailAddress:string):string{
    // {domain}/retail-admin-account/userProfile/{accountNumber}/{emailAddress}
   console.log([this.baseUrl, accountNumber, emailAddress].join('/'));
    return [this.baseUrl, accountNumber, emailAddress].join('/');
}


// call the API to get the user profile
updatePassword(accountNumber: string, emailAddress: string, newPassword: string): Observable<any> {
  return this.http.put(this.buildUrl(accountNumber, emailAddress), { password: newPassword });
}

}
