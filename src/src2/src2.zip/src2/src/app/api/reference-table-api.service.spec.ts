import { TestBed } from '@angular/core/testing';

import { ReferenceTableApiService } from './reference-table-api.service';

describe('ReferenceTableApiService', () => {
  let service: ReferenceTableApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ReferenceTableApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
