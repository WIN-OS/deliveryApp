import { TestBed } from '@angular/core/testing';

import { AccountSearchApiService } from './account-search-api.service';

describe('AccountSearchService', () => {
  let service: AccountSearchApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AccountSearchApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
