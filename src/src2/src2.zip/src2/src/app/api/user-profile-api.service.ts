/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-empty-function */
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ApiConfigService } from 'app/core/api-config.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { environment } from 'environments/environment';
import { IEditUser } from 'app/shared/model/interfaces';

@Injectable({
  providedIn: 'root'
})
export class UserProfileApiService {
  BASEURL = `${environment.apiUrl}/retail-admin/userprofile`;
  private newEditUserSubject = new BehaviorSubject<any>(null);
  
  constructor(
    private http: HttpClient,
    private apiConfig: ApiConfigService,
  ) { }

  buildUrl(accountNumber:string, emailAddress:string):string{
    // {domain}/retail-admin-account/userProfile/{accountNumber}/{emailAddress}
   console.log([this.BASEURL, accountNumber, emailAddress].join('/'));
    return [this.BASEURL, accountNumber, emailAddress].join('/');
}

  getUserProfile(accountNumber:string, emailAddress:string):Observable<any>{
    // call the API to get the user profile
    return this.http.get(this.buildUrl(accountNumber, emailAddress));
}

updateUserProfile(accountNumber:string, emailAddress:string, payload:any):Observable<any>{
    // call the API to save the user profile
    return this.http.put(this.buildUrl(accountNumber, emailAddress), payload);
}

sendEditUserEvent(editUserData: IEditUser): void {
  this.newEditUserSubject.next(editUserData);
}

onNewEditUserResults(): Observable<IEditUser> {
  return this.newEditUserSubject.asObservable();
}

}
