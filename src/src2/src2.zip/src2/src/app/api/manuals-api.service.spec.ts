import { TestBed } from '@angular/core/testing';

import { ManualsApiService } from './manuals-api.service';

describe('ManualsApiService', () => {
  let service: ManualsApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ManualsApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
