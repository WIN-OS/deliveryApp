import { TestBed } from '@angular/core/testing';

import { AccountActivityHistoryApiService } from './account-activity-history-api.service';

describe('AccountActivityHistoryApiService', () => {
  let service: AccountActivityHistoryApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AccountActivityHistoryApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
