import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';

import { ApiConfigService } from 'app/core/api-config.service';
import { ReferenceTable } from 'app/shared/model/reference-table.model';


@Injectable({
  providedIn: 'root'
})
export class ReferenceTableApiService{
  private readonly baseUrl = `${this.apiConfigService.baseUrl}/retail-admin/refdata`;

  constructor(private httpClient: HttpClient, private apiConfigService: ApiConfigService) {} 

  getReferenceData(): Observable<any> {
    return this.httpClient.get<ReferenceTable>(this.baseUrl)
      .pipe(
        catchError(this.handleError)
      );
  }

  downloadManual(url: string): Observable<HttpResponse<any>> {
    return this.httpClient.get(url, {observe: 'response', responseType: 'arraybuffer'})
      .pipe(
        catchError(this.handleError)
      );
  }

  private handleError(error: HttpErrorResponse) {
    if (error.status === 0) {
      console.error('An error occurred:', error.error);
    } else {
      console.error(
        `Backend returned code ${error.status}, body was: ${error.error}`);
    }

    return throwError(() => new Error(`A problem was encountered processing your request, please try again. 
      If you are still experiencing a problem, check back at a later time.`));
  }
}
