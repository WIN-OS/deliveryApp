/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/naming-convention */
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'environments/environment';
import { IContactUsResponse, IPhoneLine } from 'app/shared/model/interfaces';


@Injectable({
  providedIn: 'root'
})
export class ContactUsApiService {
  private readonly BASE_URL = `${environment.apiUrl}/retail-admin/contactUs`;

  constructor(private http: HttpClient) {}

  private buildUrlWithPopulationId(populationId: number): string {
    return `${this.BASE_URL}/${populationId}`;
  }

  private buildUpdateContactUsPayload(phoneLines: any[]): any {
    const phoneLinesFormatted = phoneLines.map(phoneLine => ({
      contactUsId: phoneLine.contactUsId,
      phoneLine: phoneLine.phoneLine,
      phoneNumber: phoneLine.phoneNumber,
      phoneAlias: phoneLine.phoneAlias
    }));

    return {
      retailContactUsList: phoneLinesFormatted
    };
  }

  getContactUsForPopulation(populationId: number): Observable<any> {
    return this.http.get<IContactUsResponse>(this.buildUrlWithPopulationId(populationId));
  }
  
  updateContactUsForPopulation(populationId: number, phoneLines: IPhoneLine[]): Observable<any> {
    //remove spl chars in Phoneline
    const payload = this.buildUpdateContactUsPayload(phoneLines);
    const payloadFormated = this.formatPhoneLines(phoneLines);
    console.log('after formatting', JSON.stringify(payloadFormated));
    return this.http.put(this.buildUrlWithPopulationId(populationId), payloadFormated);
  }

  formatPhoneNumber(phoneNumber: string): string {
    return phoneNumber.replace(/\./g, '');
  }

  formatPhoneLines(phoneLines: IPhoneLine[]): IPhoneLine[] {
    return phoneLines.map(line => ({
        ...line,
        phoneNumber: this.formatPhoneNumber(line.phoneNumber)
    }));
}

}
