import { TestBed } from '@angular/core/testing';
import { TranslateService } from '@ngx-translate/core';
import { LanguageService } from './language.service';

describe('LanguageService', () => {
  let service: LanguageService;
  let translateServiceSpy: jasmine.SpyObj<TranslateService>;

  beforeEach(() => {
    const spy = jasmine.createSpyObj('TranslateService', ['use']);

    TestBed.configureTestingModule({
      // Provide both the service-to-test and its (spy) dependency
      providers: [
        LanguageService,
        { provide: TranslateService, useValue: spy },
      ],
    });
    // Inject both the service-to-test and its (spy) dependency
    service = TestBed.inject(LanguageService);
    translateServiceSpy = TestBed.inject(
      TranslateService,
    ) as jasmine.SpyObj<TranslateService>;
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('#initializeLanguage should default to "en" for invalid or null inputs', () => {
    service.initializeLanguage(null);
    service.getLanguage().subscribe((lang) => {
      expect(lang).toBe('en');
    });

    service.initializeLanguage('fr');
    service.getLanguage().subscribe((lang) => {
      expect(lang).toBe('en');
    });
  });

  it('#initializeLanguage should set valid languages', () => {
    service.initializeLanguage('es');
    service.getLanguage().subscribe((lang) => {
      expect(lang).toBe('es');
    });
  });

  it('#setLanguage should call translate.use with the correct language', () => {
    service.setLanguage('en');
    expect(translateServiceSpy.use.calls.count()).toBe(1);
    expect(translateServiceSpy.use.calls.mostRecent().args[0]).toBe('en');
  });

  it('#getLanguage should return the current language as an Observable', () => {
    service.setLanguage('es');
    service.getLanguage().subscribe((lang) => {
      expect(lang).toBe('es');
    });
  });
});
