/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input } from '@angular/core';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'vsp-table-columns',
  templateUrl: './vsp-table-columns.component.html',
  styleUrls: ['./vsp-table-columns.component.scss']
})
export class VspTableColumnsComponent {
  @Input() columns: any[] | undefined;
}
