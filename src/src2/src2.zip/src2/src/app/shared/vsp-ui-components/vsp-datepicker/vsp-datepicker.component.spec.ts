import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VspDatepickerComponent } from './vsp-datepicker.component';

describe('VspDatepickerComponent', () => {
  let component: VspDatepickerComponent;
  let fixture: ComponentFixture<VspDatepickerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VspDatepickerComponent]
    });
    fixture = TestBed.createComponent(VspDatepickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
