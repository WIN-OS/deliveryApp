import { Component } from '@angular/core';

@Component({
  selector: 'sat-table-row',
  templateUrl: './vsp-table-row.component.html',
  styleUrls: ['./vsp-table-row.component.scss']
})
export class SatTableRowComponent {

}
