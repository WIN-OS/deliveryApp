/* eslint-disable @typescript-eslint/no-explicit-any */
import { JsonPipe } from '@angular/common';
import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgbAlertModule, NgbCalendar, NgbDatepickerModule, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'sat-vsp-datepicker',
  templateUrl: './vsp-datepicker.component.html',
  styleUrls: ['./vsp-datepicker.component.scss'],
  standalone: true,
	imports: [NgbDatepickerModule, NgbAlertModule, FormsModule, JsonPipe]
})
export class VspDatepickerComponent {
  //@Input() pickerModel: unknown;
	@Input() model: NgbDateStruct | undefined;
  @Input() id: string | undefined;
  @Input() placeHolder: string | undefined;
  @Input() minDate: NgbDateStruct | undefined;
  @Input() isDisabled: boolean | undefined;
  @Input() isRequired: boolean | undefined;
  @Input() isOutOfRangeAllowed: boolean | undefined;
  @Output() modelChange = new EventEmitter<NgbDateStruct>();
  
  today = inject(NgbCalendar).getToday();

	date: { year: number; month: number; } | undefined;

  onModelChange(value: NgbDateStruct):void {
    if (this.isOutOfRangeAllowed || this.isDateInRange(value)) {
      this.model = value;
      this.modelChange.emit(this.model);
    }
  }

  private isDateInRange(date: NgbDateStruct): boolean {
    if (!this.minDate) {
      return true;
    }
    const dateObj = new Date(date.year, date.month - 1, date.day);
    const minDateObj = new Date(this.minDate.year, this.minDate.month - 1, this.minDate.day);
    return dateObj >= minDateObj;
  }

}
