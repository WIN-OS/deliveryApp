import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VspTableHeadersComponent } from './vsp-table-headers.component';

describe('VspTableHeadersComponent', () => {
  let component: VspTableHeadersComponent;
  let fixture: ComponentFixture<VspTableHeadersComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VspTableHeadersComponent]
    });
    fixture = TestBed.createComponent(VspTableHeadersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
