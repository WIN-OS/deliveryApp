import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import TableData from '../../../api/account-search-response.json';
import { IAccountSearchResponse } from '../../model/interfaces';
import {IAccount} from '../../model/interfaces';


@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'vsp-table',
  templateUrl: './vsp-table.component.html',
  styleUrls: ['./vsp-table.component.scss']
})

export class VspTableComponent  {
/*
  @Input() items =  TableData.accounts;
    @Input() items: TableData[];
  @Input() paginationState: any;
  @Input() totalItems: number | undefined;
  @Input() asyncLoad: any;

  displayedColumns: string[] = ['column1', 'column2']; // Add more column names as needed
  //dataSource: MatTableDataSource<TableData>;
  dataSource: MatTableDataSource<IAccount>;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  ngOnInit() {
    this.dataSource = new MatTableDataSource(this.items);
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }


//searchedAccounts = serached;

  sortedData: IAccount[];

  constructor() {
    this.sortedData = this.items.slice();
  }

  sortData(sort: Sort):void {
    const data = this.desserts.slice();
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }

    this.sortedData = data.sort((a:any, b:any) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'name':
          return this.compare(a.name, b.name, isAsc);
        case 'calories':
          return this.compare(a.calories, b.calories, isAsc);
        case 'fat':
          return this.compare(a.fat, b.fat, isAsc);
        case 'carbs':
          return this.compare(a.carbs, b.carbs, isAsc);
        case 'protein':
          return this.compare(a.protein, b.protein, isAsc);
        default:
          return 0;
      }
    });
  }
  compare(a: number | string, b: number | string, isAsc: boolean):number {
   return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }
  */
}
