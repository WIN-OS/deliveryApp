import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VspTableHeaderComponent } from './vsp-table-header.component';

describe('VspTableHeaderComponent', () => {
  let component: VspTableHeaderComponent;
  let fixture: ComponentFixture<VspTableHeaderComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VspTableHeaderComponent]
    });
    fixture = TestBed.createComponent(VspTableHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
