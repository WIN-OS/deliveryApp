import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VspTableComponent } from './vsp-table.component';

describe('VspTableComponent', () => {
  let component: VspTableComponent;
  let fixture: ComponentFixture<VspTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VspTableComponent]
    });
    fixture = TestBed.createComponent(VspTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
