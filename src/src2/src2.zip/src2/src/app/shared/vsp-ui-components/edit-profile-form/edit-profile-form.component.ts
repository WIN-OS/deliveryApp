/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable @typescript-eslint/no-explicit-any */

import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {  ApiErrorMessageService  } from 'app/shared/services/api-error-message.service';
//import { PageAlertService } from 'app/core/page-alert.service';


@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'vsp-edit-profile-form',
  templateUrl: './edit-profile-form.component.html',
  styleUrls: ['./edit-profile-form.component.scss']
})
export class EditProfileFormComponent implements OnInit {
  @Input() profileInfo: unknown;
  @Input() title: string | undefined;
  @Output() preSaveAccountAction = new EventEmitter<any>();
  @Output() saveAccountAction = new EventEmitter<any>();
  @Output() saveAccountSuccessAction = new EventEmitter<any>();

  editProfileForm: FormGroup | undefined;
  saveAccountInProgress = false;
  saveButtonText = 'Save Profile';
  SAVE_ACCOUNT_ERROR_KEY = 'editProfileFormSaveAccountError';
  saveAccountErrorAlert: any;

  constructor(
    //private pathProvider: PathProviderService,
    private apiErrorMessageService: ApiErrorMessageService,
   // private pageAlertsService: PageAlertService
  ) { }

  ngOnInit(): void {
    this.editProfileForm = new FormGroup({
      // Define your form controls here
    });

    this.title = this.title || 'User Information';
    this.profileInfo = this.profileInfo || {};
  }

  saveAccountClicked(isFormValid: boolean): void {
    if (isFormValid) {
      this.closeSaveAccountErrorMessage();

      if (this.preSaveAccountAction) {
      //  this.preSaveAccountAction.emit().subscribe(this.saveAccount);
      } else {
        this.saveAccount();
      }
    }
  }

  saveAccount(): void {
    if (this.saveAccountAction) {
      this.saveAccountInProgress = true;
      //this.saveAccountAction.emit().subscribe(this.saveAccountSuccess, this.saveAccountFail);
    } else {
    //  console.log.warn('edit-profile-form directive was not supplied a save-account-action binding. Nothing will happen on submit.');
    }
  }

  saveAccountSuccess(response: any): void {
    this.saveAccountInProgress = false;
    if (this.saveAccountSuccessAction) {
      this.saveAccountSuccessAction.emit({ response });
    }
  }

  saveAccountFail(response: any): void {
    let errorMessage;
    let compileMessage;

    if (response.status === 400) {
      if (response.data.code === 'PROVERR') {
/*
        errorMessage = ['We could not locate the practice and billing information for your account.',
          'Please make sure your Federal Tax ID, NPI and Phone Number are correct and try again.',
          'If you continue to receive the error, please contact',
          '<span mailto-apquestions account-number="' + this.profileInfo.accountNumber + '"></span>'].join(' ');
     */
        } else if (response.data.code === 'DUPUSER') {
        errorMessage = 'This email is already associated with a user on this account.';
      } else if (response.data.code === 'USERNOTFOUND') {
        errorMessage = 'This email and account combination being modified was not found. Was not able to make a change.';
      } else {
        errorMessage = response.data.userMessage;
      }

      compileMessage = true;
    } else {
     // errorMessage = this.apiErrorMessageService.GENERIC_MESSAGE;
      compileMessage = false;
    }

   // this.saveAccountErrorAlert = this.pageAlertsService.addDanger(errorMessage, this.SAVE_ACCOUNT_ERROR_KEY, {
    //  trustedHTML: compileMessage,
   //   compileHTML: compileMessage
   // });

    this.saveAccountInProgress = false;
  }

  closeSaveAccountErrorMessage(): void {
  //  this.pageAlertsService.closeAlert(this.saveAccountErrorAlert);
  }
}
