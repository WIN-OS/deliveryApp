import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VspTableColumnComponent } from './vsp-table-column.component';

describe('VspTableColumnComponent', () => {
  let component: VspTableColumnComponent;
  let fixture: ComponentFixture<VspTableColumnComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VspTableColumnComponent]
    });
    fixture = TestBed.createComponent(VspTableColumnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
