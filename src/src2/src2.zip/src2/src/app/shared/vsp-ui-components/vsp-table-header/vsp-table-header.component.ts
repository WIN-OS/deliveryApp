import { Component, Input } from '@angular/core';

@Component({
  selector: 'sat-table-header',
  templateUrl: './vsp-table-header.component.html',
  styleUrls: ['./vsp-table-header.component.scss']
})

export class VspTableHeaderComponent {
  @Input() width!: string;
  @Input() label!: string;
  @Input() sortProperty!: string;
  @Input() columnId!: string;


  activeSort: string | undefined;
  sortReversed= false;

  sortTable(property: string):void {
    this.activeSort = property;
    this.sortReversed = !this.sortReversed;
    // Implement your sorting logic here
  }
  
  // checks if this header is the active sort
  isActiveSort(property: string):boolean {
    return this.activeSort === property;
  }
  /*
  isSortReversed() {
    // Implementation here
    return false;
  }
  */
  onClick():void {
    // sort the table when the header is clicked
    // don't do anything if this header doesn't have a sort property
    if (this.sortProperty){
        this.sortTable(this.sortProperty);
    }
  }

  // show the reverse arrow icon if this is the active sort and sort is reversed
  reverseSortArrow():boolean {
    return this.isActiveSort(this.sortProperty) && this.sortReversed;
  }

}




