import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VspTableRowComponent } from './vsp-table-row.component';

describe('VspTableRowComponent', () => {
  let component: VspTableRowComponent;
  let fixture: ComponentFixture<VspTableRowComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VspTableRowComponent]
    });
    fixture = TestBed.createComponent(VspTableRowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
