import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VspTimepickerComponent } from './vsp-timepicker.component';

describe('VspTimepickerComponent', () => {
  let component: VspTimepickerComponent;
  let fixture: ComponentFixture<VspTimepickerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VspTimepickerComponent]
    });
    fixture = TestBed.createComponent(VspTimepickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
