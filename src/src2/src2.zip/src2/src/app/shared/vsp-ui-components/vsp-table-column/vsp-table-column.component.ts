import { Component } from '@angular/core';

@Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'vsp-table-column',
  templateUrl: './vsp-table-column.component.html',
  styleUrls: ['./vsp-table-column.component.scss']
})
export class VspTableColumnComponent {

}
