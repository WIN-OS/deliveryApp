import { JsonPipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NgbTimeStruct,NgbTimepickerModule } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'sat-vsp-timepicker',
  templateUrl: './vsp-timepicker.component.html',
  styleUrls: ['./vsp-timepicker.component.scss'],
  standalone: true,
	imports: [NgbTimepickerModule, FormsModule, JsonPipe]
})
export class VspTimepickerComponent {
  time: NgbTimeStruct = { hour: 13, minute: 30, second: 0 };
	hourStep = 1;
	minuteStep = 15;
	secondStep = 30;
}
