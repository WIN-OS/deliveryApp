import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VspTableColumnsComponent } from './vsp-table-columns.component';

describe('VspTableColumnsComponent', () => {
  let component: VspTableColumnsComponent;
  let fixture: ComponentFixture<VspTableColumnsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [VspTableColumnsComponent]
    });
    fixture = TestBed.createComponent(VspTableColumnsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
