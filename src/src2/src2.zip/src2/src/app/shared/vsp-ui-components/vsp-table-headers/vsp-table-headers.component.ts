/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input } from '@angular/core';
import { VspTableHeaderComponent } from '../vsp-table-header/vsp-table-header.component';

@Component({
  selector: 'sat-table-headers',
  templateUrl: './vsp-table-headers.component.html',
  styleUrls: ['./vsp-table-headers.component.scss']
})
export class VspTableHeadersComponent {
  @Input() headers: any[] | undefined;
}
