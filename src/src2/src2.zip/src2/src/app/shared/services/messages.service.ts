/* eslint-disable @typescript-eslint/no-explicit-any */
import { Injectable, EventEmitter } from '@angular/core';
import { DateUtilService } from 'app/core/date-util.service';


@Injectable({
  providedIn: 'root'
})

export class MessagesService {

  // eslint-disable-next-line @typescript-eslint/naming-convention
  MESSAGE_EVENTS = {
    ADD_MESSAGE: 'vsp.messages.add'
  };

  addMessageEvent = new EventEmitter<any>();

  constructor(private dateService: DateUtilService) { }

  // sends the ADD_MESSAGE event
  sendAddMessageEvent(newMessage: any):void {
    this.addMessageEvent.emit(newMessage);
  }

  // formats all messages in the list of messages
  formatMessages(messages: any[]):void {
    // do nothing if messages is not defined
    if (!messages) {
      return;
    }

    // loop through each message and set the UI-specific properties
    for (let i = 0, l = messages.length; i < l; i++) {
      this.updateUiProperties(messages[i]);
    }
  }

  // sets the ui object and properties on the message. the ui object contains additionally formatted data that the UI can
  // take advantage of without modifying the original message data
  updateUiProperties(message: any):void {
    // do nothing if the message is not defined
    if (!message) {
      return;
    }

    // initialize the ui object if it has not been already
    if (!message.ui) {
      message.ui = {};
    }

    // sets the ui.populationsString property by joining the populations array with a comma and line-break
    if (message.populations && message.populations instanceof Array) {
      message.ui.populationsString = message.populations.join(',\n');
    }

    // build the start date-time string by joining the startDate and startTime
    message.ui.startDateTimeString = this.getDateTimeString(message.startDate, message.startTime);

    if (message.endDate && message.endTime) {
      // if the message has an endDate, build the end date-time string by joining the endDate and endTime
      message.ui.endDateTimeString = this.getDateTimeString(message.endDate, message.endTime);
    }
    else {
      // message has no endDate or endTime - set endDateString to "No End Date"
      message.ui.endDateTimeString = 'No End Date';
    }

    // set the status properties
    this.setStatus(message);
  }

  getDateTimeString(date: any, time: any):string {
    return [date, time].join(' ').trim();
  }

  // sets the status and isActive property on the message by checking the "to" date to see if it is prior to the current time
  setStatus(message: any):void {
    let isActive;

    // If the message has the messageStatus attribute from the API, use this to determine if its active/inactive.
    if (message.messageStatus) {
      isActive = this.checkMessageStatusFlag(message);
    } else {
      // If the message is newly created, check the end date to determine if it is active or not.
      // Can't do an API call as it will break the sorting rules.

      // if the message doesn't have endDate and endTime, this is a static message (never expires) - it is always active
      if (!(message.endDate && message.endTime)) {
        isActive = true;
      }
      else {
        const localTimePST = this.dateService.getDateInPacificTime(new Date());
        // convert the endDateTimeString to a date object
        // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
        const expirationDate = this.dateService.getDateObjectFromDateTimeString(message.ui.endDateTimeString);

        // compare the date object to the current date/time. if it is later than right now, the message is active
        isActive = expirationDate ? expirationDate > localTimePST :false;
      }

    }

    // set the status and isActive properties on the ui object
    message.ui.isActive = isActive;
    message.ui.status = isActive ? 'Active' : 'Inactive';
  }

  checkMessageStatusFlag(message: any):boolean {
    return message.messageStatus == 'ACTIVE' ? true : false;
  }
}
