import { TestBed } from '@angular/core/testing';

import { LoginTargetService } from './login-target.service';

describe('LoginTargetService', () => {
  let service: LoginTargetService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoginTargetService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
