import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiErrorMessageService {
  showPageAlertErrorMessage(response: any, arg1: string): string {
    throw new Error('Method not implemented.');
  }
  closePageAlertErrorMessages(_alerts: {}):unknown {
    throw new Error('Method not implemented.');
  }

  constructor() { }
}
