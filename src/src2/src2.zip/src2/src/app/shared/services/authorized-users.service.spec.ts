import { TestBed } from '@angular/core/testing';

import { AuthorizedUsersService } from './authorized-users.service';

describe('AuthorizedUsersService', () => {
  let service: AuthorizedUsersService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthorizedUsersService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
