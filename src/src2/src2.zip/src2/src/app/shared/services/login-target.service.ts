import { Injectable } from '@angular/core';
import { AuthenticationServiceInternal } from 'app/core/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class LoginTargetService {

  hideContent: boolean;

  constructor(private authService: AuthenticationServiceInternal ) { 
    this.hideContent = true;
  }

  //based on - legacy APP - provider-portal-2020-admin/src/pages/secure/secure.controller.js

        // hide content until user is authenticated
       
/*
        // wait for the authentication check to finish and then initialize
        this.authService.isAuthenticated().then(initialize, acsTimeout);

        function initialize(isAuthenticated:boolean){
            if (isAuthenticated){
                // get the user profile
                this._oauthService.getUserProfile().then(getUserProfileSuccess, getUserProfileFail);
            }
            else {
                if ($stateParams.saveLoginTarget){
                    // save the current URL to come back to it after login
                    this._loginTargetService.saveLoginTarget();
                }

                // perform login automatically
                this._oauthService.login();
            }
        }

        function getUserProfileSuccess(response){
            // set the user profile on the scope
            let userProfile = response.data;

            // go to the login target (the URL the user tried to access before being authenticated)
            this._loginTargetService.goToLoginTarget();

            // show the child content
            let hideContent = false;

            // if the user is a super user, we need to update the sticky scroll offset of the page alerts directive
            // to accommodate for the Super User Header
            if (this.userProfile.hasFullAccess){
                pageAlertsService.updateStickyScrollOffset();
            }
        }

        function getUserProfileFail(response){
            if (response.status === 401){
                // if we got a 401, user is not authorized to use the Admin Tool - redirect to the Access Denied page
                routeHelperService.goToAccessDenied();
            }
            else {
                // other error occurred - stay in the "Loading" state and show an error message
                apiErrorMessageService.showPageAlertErrorMessage(response, 'getUserProfileApiFail');
            }
        }

        function acsTimeout(){
            // if the ACS iframe timed out, show the timeout error alert
            acsIframeService.showAcsIframeTimeoutError();
        }

    */
}
