/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */

import { Injectable } from '@angular/core';
import { DateUtilService } from 'app/core/date-util.service';
import { PaginationService } from './pagination.service';
import { IQueryObj } from '../model/interfaces';

@Injectable({
  providedIn: 'root'
})
export class QueryBuilderService {
//  buildQueryStringFromObject(queryObject: string, arg1: { paginationState: string; }) {


  constructor(private dateService: DateUtilService, private paginationService: PaginationService) { }

  // Check if value is a string and blank
  isValidValue(value: any, allowEmptyString: boolean): boolean {
    if (typeof value === 'string' && value.trim().length === 0){
      // Return the allowEmptyString value as this is an empty string
      return allowEmptyString;
    }
    // Not valid if undefined, null, or empty array
    return !(value === undefined || value === null || (Array.isArray(value) && value.length === 0));
  }

  getPaginationStateQueryObject(paginationState: any): IQueryObj {
    // Initialize the query object
    const queryObject: IQueryObj = {
      pageSize : 25,
      pageNumber: 0,
      sortBy : '',
      sortDirection : ''
    };

    // Only set the pageSize/pageNumber if itemsPerPage is defined and greater than 0 (0 indicates All records)
    if (paginationState.itemsPerPage && paginationState.itemsPerPage > 0){
      queryObject.pageSize = paginationState.itemsPerPage;
      queryObject.pageNumber = paginationState.currentPage - 1; // Subtract 1, as the API pageNumber is 0-based
    }

    // If there is an itemSort object with a sortProperty...
    if (paginationState.itemSort && paginationState.itemSort.sortProperty){
      // Set the sortBy param to the sortProperty
      queryObject.sortBy = paginationState.itemSort.sortProperty;

      // If the reverse property is defined...
      if (paginationState.itemSort.reverse !== undefined){
        // If reverse is true, set sortDirection to 'DESC' (descending), otherwise 'ASC' (ascending)
        queryObject.sortDirection = paginationState.itemSort.reverse === true ? 'DESC' : 'ASC';
      }
      else {
        // Default to ascending if reverse is not defined
        queryObject.sortDirection = 'ASC';
      }
    }
 
    // Return the query object
    return queryObject;
  }

  // Return a query string from the given object
  // Options:
  //  paginationState: a pagination state object, use this to create pagination query parameters
  //    or set this to true to use the default pagination state
  //  allowEmptyString: set to true to allow parameters with empty string values (false by default)
  buildQueryStringFromObject(queryObj: any, options: any): string {
    let queryString = '';
    let queryValue: any, queryPrefix: string;

    // Initialize the queryObj to a blank object if not defined
    queryObj = queryObj || {};

    // Initialize options if not provided
    options = options || {};

    // If we have a pagination state, build a query object out of it and merge it into the initial query object
    if (options.paginationState){
      // If paginationState is set to true, use the default pagination state
      if (options.paginationState === true){
        options.paginationState = this.paginationService.getDefaultPaginationState();
      }

      queryObj = {...queryObj, ...this.getPaginationStateQueryObject(options.paginationState)};
    }

    for (const queryProp in queryObj){
      if (Object.prototype.hasOwnProperty.call(queryObj, queryProp)){
        queryValue = queryObj[queryProp];

        if (this.isValidValue(queryValue, options.allowEmptyString)){
          // Convert date objects to strings
          if (queryValue instanceof Date){
            queryValue = this.dateService.convertDateToStringYYYYMMDD(queryValue);
          }

          // If we already have query string data, the next value needs to be prepended with "&"
          // Otherwise, prepend the first value with "?"
          queryPrefix = queryString.length > 0 ? '&' : '?';
          queryString += `${queryPrefix}${queryProp}=${queryValue}`;
        }
      }
    }

    return queryString;
  }
}
