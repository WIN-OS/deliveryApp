/* eslint-disable @typescript-eslint/no-explicit-any */
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class AuthorizedUsersService {
  formatAuthorizedUsers(authorizedUsers: any[], currentUserEmailAddress: string): void {
    for (const user of authorizedUsers) {
      // Create a ui object for ui-specific properties
      user.ui = {};

      // Get the user status string based on the accountUserStatus value
      switch (user.accountUserStatus) {
        case '1':
          user.ui.accountUserStatusString = 'Active';
          break;
        case '2':
          user.ui.accountUserStatusString = 'Invited';
          break;
        default:
          user.ui.accountUserStatusString = 'Inactive';
          break;
      }
    }

    // Set the isCurrentUser flag on all users
    this.setIsCurrentUser(authorizedUsers, currentUserEmailAddress);

    // Sort the users - current user first, and then by status (Active first)
    authorizedUsers.sort(this.userSort);
  }

  private setIsCurrentUser(authorizedUsers: any[], currentUserEmailAddress: string): void {
    for (const user of authorizedUsers) {
      user.ui.isCurrentUser = currentUserEmailAddress
        ? user.accountUserEmail.toLowerCase() === currentUserEmailAddress.toLowerCase()
        : false;
    }
  }

  private userSort(a: any, b: any): number {
    if (a.ui.isCurrentUser) {
      return -1;
    }
    if (b.ui.isCurrentUser) {
      return 1;
    }
    return Number(a.accountUserStatus) - Number(b.accountUserStatus);
  }
}
