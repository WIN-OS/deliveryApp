import { Injectable } from '@angular/core';
import { IPaginationAsyncLoad, IPaginationObj } from '../model/interfaces';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PaginationService {
  
  private defaultPaginationOptions: string[] = ['25', '50', '100'];
  private paginationState = new BehaviorSubject<IPaginationAsyncLoad>({ items: [], totalItems: 0 });
  public paginationLoadState$ = this.paginationState.asObservable();

  defaultPagination :IPaginationObj = {
    currentPage: 1,
    itemsPerPage: this.getSmallestPaginationOption(),
    itemSort: {
        sortProperty: '',
        reverse: false
    }}
  
  // Sets the list of default pagination options
  setDefaultPaginationOptions(paginationOptions: string | string[]): void {
    if (!paginationOptions) {
      throw new Error('Default pagination options must be defined.');
    }
    
    // Convert the options to an array if it is a single item
    if (!(paginationOptions instanceof Array)) {
      paginationOptions = [paginationOptions];
    }
    
    // Set the internal reference
    this.defaultPaginationOptions = paginationOptions;
  }
  
  // Returns a copy of the default pagination options
  getDefaultPaginationOptions(): string[] {
    return [...this.defaultPaginationOptions];
  }
  
  // Returns the smallest pagination option (as a numeric value)
  getSmallestPaginationOption(): number | string {
    const smallestPaginationOption = this.defaultPaginationOptions[0];
     // convert to a number
    const smallestPaginationOptionNumeric = Number(smallestPaginationOption);
    
    // if not a valid number, return the original value
    if (isNaN(smallestPaginationOptionNumeric)) {
      return smallestPaginationOption;
    } else {
       // valid number, return the numeric value
      return smallestPaginationOptionNumeric;
    }
  }

  getDefaultPaginationState():IPaginationObj {
    return this.defaultPagination;
  }

  updatePaginationState(newState: IPaginationAsyncLoad): void {
    this.paginationState.next(newState);
  }

}
