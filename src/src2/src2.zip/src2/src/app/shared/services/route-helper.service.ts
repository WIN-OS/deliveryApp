/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable @typescript-eslint/no-explicit-any */


import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { UserProfileApiService } from 'app/api/user-profile-api.service';
import { IEditUser } from '../model/interfaces';

@Injectable({
  providedIn: 'root'
})
export class RouteHelperService {

  constructor(private router: Router,
    private userProfileApiService : UserProfileApiService
  ) { }

  goToAccountDetails(stateParams: any): Promise<boolean> {
    console.log('navigate - /sat-account-details - router hrlper 2');
    return this.router.navigate(['sat-account-details', stateParams]);
  }

  goToAccountSearch(stateParams?: any): Promise<boolean> {
    console.log('navigate - /sat-create-account - router hrlper 1');
    return this.router.navigate(['/sat-create-account', stateParams]);
    // return this.router.navigate(['sat-account-search', stateParams]);
  }
  
  goToEditAccount(passedUserAccountObj: IEditUser):any {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
    this.userProfileApiService.sendEditUserEvent(passedUserAccountObj);
    return this.router.navigate(['sat-edit-account'], {queryParams : passedUserAccountObj});
  }

  goToViewClaim(stateParams: any):any {
    stateParams = stateParams || {};
    const claimData = stateParams.searchResult || stateParams.claim;
    if (!claimData) {
      throw new Error('Error in route-helper.service.goToViewClaim: Please specify either the claim ' +
        'or searchResult property on the stateParams object.');
    }
    stateParams.trackingNumber = claimData.trackingNumber;
    return this.router.navigate(['secure/view-claim/form', stateParams]);
  }

  goToClaimSearch(stateParams: any):any {
    return this.router.navigate(['secure/claim-search', stateParams]);
  }

  goToAccessDenied():any {
    return this.router.navigate(['public/access-denied']);
  }
}
