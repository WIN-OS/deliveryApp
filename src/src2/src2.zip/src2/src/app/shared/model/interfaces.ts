/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/naming-convention */
import { FormArray, FormControl, FormGroup } from '@angular/forms';
import { SafeHtml } from '@angular/platform-browser';
import { Observable } from 'rxjs';

export interface IAppConfigs{
    baseUrl: string,
    patientEncounterUrl: string,
    memberPolicyUrl: string
}


export interface IQueryObj {
  pageSize : number,
  pageNumber : number,
  sortBy :string,
  sortDirection : string
}

export interface IAuthConfigs {
    baseUrl: string,
    acsIframeUrl: string,
    loginLandingPageState: string,
    logoutLandingPageState: string,
    showUserProfileErrorMessage: boolean,
    userInfoApi: string
}

export interface IUserProfile {
    hasFullAccess : true;
    email? : string;
}

export interface IUser {
    userProfile?: IUserProfile;
    isAuthenticated: boolean;
    token: string;
}

export abstract class ISessionService {
    public abstract init(): void;
  
    public abstract startSession(): void;
  
    public abstract stopSession(): void;
  
    public abstract restartSession(): void;
  }
  
  export interface ISessionConfig {
    idle: number;
    timeout: number;
  }
  
  export interface Alert {
    type: string;
    message: string | SafeHtml;
    icon?: string;
    persistOnStateChange?: boolean;
    trustedHTML?: boolean;
    compileHTML?: boolean;
    alertClass?: string;
    id: string;
    fadeTimeout?: any;
  }
  
  export enum AlertType {
    DANGER = 'danger',
    SUCCESS = 'success',
    WARNING = 'warning',
  }
  
  export interface AlertOptions {
    icon?: string;
    persistOnStateChange?: boolean;
    trustedHTML?: boolean;
    compileHTML?: boolean;
    alertClass?: string;
    fadeOut?: number;
  }

export abstract class IAlertService {
    public abstract getAlerts(): Observable<Alert[]>;
  
    public abstract addDanger(message: string, timeout?: number): Alert;
  
    public abstract addAlertDanger(message: string, alertLink?: string, code?: string, timeout?: number): Alert;
  
    public abstract addWarning(message: string, timeout?: number): Alert;
  
    public abstract addSuccess(message: string, timeout?: number): Alert;
  
    public abstract removeAlert(alert: Alert): void;
  
    public abstract clearAlerts(): void;
  }
  
  export interface ISearchForm {
     accountStatus: FormControl<string | null>;
    accountNumber: FormArray; 
    email: FormArray; 
    taxId: FormArray; 
    phoneNumber: FormArray; 
    npi: FormArray; 
  }
  export interface IAccountSearchFormQuery {
    accountStatus: string | null;
    accountNumber: string | null;
    email: string | null;
    taxId: string | null;
    phoneNumber: string | null;
    npi: string | null;
    [key: string]: string | null;
  }

  export interface IRetailMessages{
    actionDate: string,
    activity:string,
    actor: string
  }
  export interface IAccountSearchResponse{
      totalPages: number,
      totalElements: number,
      accounts: [IAccount]
    }
    
    export interface IAccount{
      accountNumber: string,
      address: IAddress,
      name: string,
      status: string,
      ui?: {
        statusString? : string
      },
      claimFormViewStatus: string,
      legacy2020Access: string,
      taxId: string,
      npi: string,
      phone: string,
      users: [IUserAccountDetails],
      activitiesLink: {
        href: string,
        type: string,
        rel: string,
        contextRootPlus: string
      }
    }
  export interface IUserAccountDetails{
        accountUserEmail: string,
        accountUserFirstName: string,
        accountUserLastName: string,
        accountUserStatus: string
  } 

export interface IAddress {
    street1: string,
    city: string,
    stateCode: string,
    zipCode: string
}

export interface IAlert {
  message: string,
  id: string,
  formAlertsContainerId: string,
  type: string,
  icon: string ,
  trustedHTML: unknown,
  compileHTML: unknown
}

export interface IPaginationObj {
  currentPage: number,
  itemsPerPage:  number | string,
  itemSort: {
      sortProperty: string,
      reverse: boolean
}}

export interface IPaginationAsyncLoad {
    items: unknown[],
    totalItems: number,
    pageLoading? : boolean
}


export interface ICreateAccountForm {
   emailAddress: string, 
   password : string,
   firstName: string,
   lastName: string,
   title?: string,
   taxID: string,
   phoneNumber: string,
   npi: string,
   deactivateClaimForm?: boolean; 
}

//will get rid of Null after backend changes
export interface ICreateAccountFormResponse {
  status?: string, 
  statusDesc?: string, 
  code?: string, 
  message?: string, 
  userMessage?: string, 
  accountNumber :string, 
  userEmailAddress?:string, 
  userPassword?: string, 
  userNewPassword?: string, 
  userFirstName?: string, 
  userLastName?: string, 
  userTitle?: string, 
  userPhoneNumber?: string, 
  billingFederalTaxId?: string, 
  billingPhoneNumber?:string, 
  billingNPI?: string, 
  claimFormAccess?: string, 
  x_TransactionID?: string
}
export interface ICreateAccountFormPayload {
  billingFederalTaxId?: string, 
  billingNPI?: string, 
  billingPhoneNumber?:string, 
  claimFormAccess?: boolean, 
  userEmailAddress?:string, 
  userFirstName?: string, 
  userLastName?: string, 
  userTitle?: string, 
  userPassword?: string, 
}
export interface IEditAccountFormPayload {
  federalTaxId?: string, 
  npi?: string, 
  phoneNumber?:string, 
  userEmailAddress?:string,  
  userFirstName?: string, 
  userLastName?: string, 
  userTitle?: string, 
}

export interface IMessages {
   ui?: any, 
   populations?: string[] | undefined, 
   startDate?: string, 
   startTime?: string, 
   endDate?: string, 
   endTime?: string, 
   messageStatus: string, 
   messageId :string,
   message: string
}


export interface IMessagesResponse{
  status?: string,
  statusDesc?: string,
  code?: string,
  message?: string,
  userMessage?: string,
  totalPages: number,
  totalElements: number,
  retailMessages:[IRetailMessages]
}

export interface IRetailMessages
{
  status?: string,
  statusDesc?: string,
  code?: string,
  message?: string,
  userMessage?: string,
  messageId: number,
  startDate?: string,
  startTime?: string,
  endDate?: string,
  endTime?: string,
  messageStatus?: string,
  populations: [string],
  x_TransactionID?: string
}

export interface IMessageQuery {
  messageText?: string, 
    messageType:string
}

export interface IAdminUserResponse {
  status?: string,
  statusDesc?: string,
  code?: string,
  message?: string,
  userMessage?: string,
  hasLimitedAccess: boolean,
  hasFullAccess?: string,
  x_TransactionID?: string,
}



export interface IPopulationListResponse {
  status?: string,
  statusDesc?: string,
  code?: string,
  message?: string,
  userMessage?: string,
  populationList: [IPopulationList]
}
export interface IPopulationList {
  status?: string,
  statusDesc?: string,
  code?: string,
  message?: string,
  userMessage?: string,
  populationId: number,
  populationName:  string,
  programIdBenefitDescList:[IProgramIdBenefitDescList],
  x_TransactionID?:  string
}

export interface IProgramIdBenefitDescList {
  programId : string,
  benefitDescription: string,
}

export interface IEditUser {
  user: {
    accountUserEmail: string,
    accountUserFirstName?: string,
    accountUserLastName?: string,
    accountUserStatus?: string
  },
  account: {
    accountStatus: string | null;
    accountNumber: string | null;
    email: string | null;
    taxId: string | null;
    phoneNumber: string | null;
    npi: string | null;
    [key: string]: string | null;
  }
}

export interface IContactUsResponse {
  status?: string,
  statusDesc?: string,
  code?: string,
  message?: string,
  userMessage?: string,
  populationName?: string,
  retailContactUsList: [
      {
          status?: string,
          statusDesc?: string,
          code?: string,
          message?: string,
          userMessage?: string,
          contactUsId?: number,
          phoneLine?: string,
          phoneNumber?: string,
          phoneAlias?: string,
          populationName?: string,
          x_TransactionID?: string,
      }
  ],
  x_TransactionID?: string,

}

export interface IPhoneLine {
    phoneLine: string,
    phoneNumber: string,
    phoneAlias?: string,
}