export enum AppEnvironmentName {
  DEV,
  TEST,
  STG,
  PROD,
  SBOX,
}
