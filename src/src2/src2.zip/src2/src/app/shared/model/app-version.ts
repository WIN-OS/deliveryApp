export class AppVersion {
  short = '';
  branch = '';
  version = '';
  date = '';
}

