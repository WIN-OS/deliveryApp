export interface ILanguageModel {
    languageName: string;
//dashboard:{
    // label1: string;
    // label2: string;
//}
}