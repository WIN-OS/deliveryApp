export interface ReferenceTable {
    retailReferenceData: RetailReferenceData[]
}

export interface RetailReferenceData {
    population: string,
    contacts: Contact[],
    manuals: Manual[],
    programIdBenefitDescList: ProgramIdBenefitDesc[]
}

export interface Contact {
    phoneLine: string,
    phoneNumber: string,
    phoneAlias: string
}

export interface Manual {
    manualName: string,
    manualLink: ManualLink,
    isDownloading: boolean
}

export interface ManualLink {
    href: string
}

export interface ProgramIdBenefitDesc {
    programId: string,
    benefitDescription: string
}