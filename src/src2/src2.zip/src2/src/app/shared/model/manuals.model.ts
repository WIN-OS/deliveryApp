export interface ManualDTO {
    retailManuals: Manual[]
}

export interface Manual {
    hasFile: boolean,
    manualId?: number,
    manualName?: string,
    lastUpdatedDate?: string,
    file?: File
}

export interface PopulationDTO {
    populationList: Population[]
}

export interface Population {
    populationId: number,
    populationName: string
}