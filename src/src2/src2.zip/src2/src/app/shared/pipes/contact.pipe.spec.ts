import { ContactPipe } from './contact.pipe';

describe('ContactPipe', () => {
  it('create an instance', () => {
    const pipe = new ContactPipe();
    expect(pipe).toBeTruthy();
  });
});
