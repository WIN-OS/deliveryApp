import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'taxId'
})
export class TaxIdPipe implements PipeTransform {

  transform(value: string): string {
    const digits = (value || '').replace(/-/g, '');
    return digits ? `${digits.substr(0, 2)}-${digits.substr(2, 7)}` : '';
  }

}

@Pipe({
  name: 'phone'
})
export class PhonePipe implements PipeTransform {
  transform(value: string): string {
    const digits = (value || '').replace(/\./g, '');
    return digits ? `${digits.substr(0, 3)}.${digits.substr(3, 3)}.${digits.substr(6, 4)}` : '';
  }
}