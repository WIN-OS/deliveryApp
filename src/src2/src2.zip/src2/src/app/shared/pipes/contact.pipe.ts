import { Pipe, PipeTransform } from '@angular/core';

import { Contact } from '../model/reference-table.model';

@Pipe({
  name: 'formatPhoneNumber'
})
export class ContactPipe implements PipeTransform {

  transform(contact: Contact): string {
    if (!contact){
      return '';
    }

    const phoneNumberFormatted = this.formatPhoneNumberString(contact.phoneNumber);
    if (contact.phoneAlias){
        // if the contact has an alias and a phone number, return it in the format: 
        // "{contact.phoneAlias} ({phoneNumberFormatted})", i.e. "855.METEYE1 (855.638.3931)"
        if (phoneNumberFormatted){
            return [contact.phoneAlias, ' (', phoneNumberFormatted, ')'].join('');
        }
        else {
            // if there is no phone number, return just the alias
            return contact.phoneAlias;
        }
    }
    else {
        // if the contact doesn't have an alias just return the formatted number
        return phoneNumberFormatted;
    }
  }

  private formatPhoneNumberString(phoneNumber: string){
    const phoneString = (phoneNumber ?? '').replace(/[-\.]/g, '');

    let phoneNumberFormatted = phoneString.substring(0, 3);
    if (phoneString.substring(3, 6))
    {
      phoneNumberFormatted = `${phoneNumberFormatted}.${phoneString.substring(3, 6)}`;

      if (phoneString.substring(6))
      {
        phoneNumberFormatted = `${phoneNumberFormatted}.${phoneString.substring(6)}`;
      }    
    }

    return phoneNumberFormatted;
  }
}
