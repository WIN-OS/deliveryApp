import { TaxIdPipe } from './form.pipe';

describe('TaxIdPipe', () => {
  it('create an instance', () => {
    const pipe = new TaxIdPipe();
    expect(pipe).toBeTruthy();
  });
});
