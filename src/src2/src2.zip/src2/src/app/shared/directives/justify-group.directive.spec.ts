import { JustifyGroupDirective } from './justify-group.directive';

describe('JustifyGroupDirective', () => {
  it('should create an instance', () => {
    const directive = new JustifyGroupDirective();
    expect(directive).toBeTruthy();
  });
});
