import { PhoneNumberFormatDirective } from './phone-number-format.directive';

describe('PhoneNumberFormatDirective', () => {
  it('should create an instance', () => {
    const directive = new PhoneNumberFormatDirective();
    expect(directive).toBeTruthy();
  });
});
