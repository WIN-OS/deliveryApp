import { Directive, ElementRef, Input, Renderer2, OnInit } from '@angular/core';

@Directive({
  selector: '[satInputWrapper]'
})
export class InputWrapperDirective implements OnInit {

  @Input('satInputWrapper') columns: string | undefined;
  requiredState = { asteriskElement: null, required: false };
  isDisabled = false;
  
  constructor(private el: ElementRef, private renderer: Renderer2) { }
  
  ngOnInit():void {
    this.updateRequiredAsterisk();
    if (this.columns) {
      const classes = this.parseColumnsAttribute(this.columns);
      classes.forEach(cls => this.renderer.addClass(this.el.nativeElement, cls));
    }
  }
  
  parseColumnsAttribute(columns: string): string[] {
    const columnClasses = [];
    if (isNaN(Number(columns))) {
      const columnsArray = columns.split(';');
      for (let i = 0, l = columnsArray.length; i < l; i++) {
        const columnPieces = columnsArray[i].split(':');
        const columnClass = ['col', columnPieces[0], columnPieces[1]].join('-');
        columnClasses.push(columnClass);
      }
    } else {
      columnClasses.push('col-' + columns);
    }
    return columnClasses;
  }
  
  updateRequiredAsterisk():void {
    const required = this.el.nativeElement.hasAttribute('required');
    if (required !== this.requiredState.required) {
      if (required) {
        if (!this.requiredState.asteriskElement) {
          this.requiredState.asteriskElement = this.renderer.createElement('span');
          this.renderer.addClass(this.requiredState.asteriskElement, 'required-label-asterisk');
          this.renderer.appendChild(this.el.nativeElement, this.requiredState.asteriskElement);
        }
      } else if (this.requiredState.asteriskElement) {
        this.renderer.removeChild(this.el.nativeElement, this.requiredState.asteriskElement);
      }
      this.requiredState.required = required;
    }
  }


}  





