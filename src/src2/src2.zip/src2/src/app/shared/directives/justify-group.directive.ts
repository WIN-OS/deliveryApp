/* eslint-disable @typescript-eslint/no-unsafe-argument */
import { Directive, ElementRef, AfterViewInit, Renderer2 } from '@angular/core';


@Directive({
  selector: '[satJustifyGroup]'
})
export class JustifyGroupDirective implements AfterViewInit {
  
    constructor(private el: ElementRef, private renderer: Renderer2) { }
  
    ngAfterViewInit(): void{

      //get the parent element
      const parent = this.el.nativeElement;
      
      //Get all the children elements
      const children = Array.from(parent.children as HTMLCollectionOf<Element>).filter((child: Element) => {
        child.classList.contains('flex-item') || child.hasAttribute('sat-flex-item')
      });
    
      const numChildren = children.length;

      if(numChildren > 0){
        const flexBasis = `${100 / numChildren}%`;

        //Aply stylew to the oarent to make it a flex container
        this.renderer.setStyle(parent, 'display', 'flex');

        //Aply styles to each child
        for (let i = 0; i < children.length; i++){
          this.renderer.setStyle(children[i], 'flex', `0 0 ${flexBasis}`);
          
          this.renderer.setStyle(children[i], 'max-width', flexBasis);
          
          this.renderer.setStyle(children[i], 'box-sizing', 'border-box');

          this.renderer.setStyle(children[i], 'padding', '10px');
          
          this.renderer.setStyle(children[i], 'margin', '5px');
          
          this.renderer.setStyle(children[i], 'border', '1px solid #ccc');

          this.renderer.setStyle(children[i], 'background-color', '#f1f1f1');

          this.renderer.setStyle(children[i], 'text-align', 'center');
         }
       }
      }
    }
    

      
       // OLD code 
       /*
      // set group width to 100%  
      this.el.nativeElement.style.width = '100%';
  
      // get all direct children
      // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
      const children = Array.from(this.el.nativeElement.children) as HTMLElement[];
      const childCount = children.length;
  
      if (childCount > 0) {
        // figure out the width in percentage of each child
        const width = 100 / childCount;
        // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
        children.forEach((child: HTMLElement) => {
          child.style.width = width + '%';
        });  
      }  
    }  
*/
