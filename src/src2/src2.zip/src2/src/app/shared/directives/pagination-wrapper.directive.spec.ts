import { PaginationWrapperDirective } from './pagination-wrapper.directive';

describe('PaginationWrapperDirective', () => {
  it('should create an instance', () => {
    const directive = new PaginationWrapperDirective();
    expect(directive).toBeTruthy();
  });
});
