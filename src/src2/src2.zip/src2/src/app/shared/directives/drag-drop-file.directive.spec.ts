import { DragDropFileDirective } from './drag-drop-file.directive';

describe('DragDropFileDirective', () => {
  it('should create an instance', () => {
    const directive = new DragDropFileDirective();
    expect(directive).toBeTruthy();
  });
});
