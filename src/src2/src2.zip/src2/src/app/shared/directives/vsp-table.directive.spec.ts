import { VspTableDirective } from './vsp-table.directive';

describe('VspTableDirective', () => {
  it('should create an instance', () => {
    const directive = new VspTableDirective();
    expect(directive).toBeTruthy();
  });
});
