import { PhoneNumberPipeDirective } from './phone-number-pipe.directive';

describe('PhoneNumberPipeDirective', () => {
  it('should create an instance', () => {
    const directive = new PhoneNumberPipeDirective();
    expect(directive).toBeTruthy();
  });
});
