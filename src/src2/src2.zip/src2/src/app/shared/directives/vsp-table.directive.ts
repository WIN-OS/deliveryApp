import { Directive } from '@angular/core';

@Directive({
  selector: '[appVspTable]'
})
export class VspTableDirective {

  constructor() { }

}
