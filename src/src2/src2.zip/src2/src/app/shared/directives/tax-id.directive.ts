// tax-id.directive.ts
import { Directive, HostListener, Self } from '@angular/core';
import { NgControl } from '@angular/forms';
import { PhonePipe, TaxIdPipe } from 'app/shared/pipes/form.pipe';

@Directive({
  selector: '[satTaxId]'
})
export class TaxIdDirective {

  constructor(private taxIdPipe: TaxIdPipe, @Self() private ngControl: NgControl) { }

  @HostListener('ngModelChange', ['$event'])
  onModelChange(value: string):void {
    this.ngControl.valueAccessor?.writeValue(this.taxIdPipe.transform(value));
  }

  @HostListener('blur', ['$event'])
  onBlur(event: FocusEvent):void {
    this.ngControl.control?.setValue(this.taxIdPipe.transform((event.target as HTMLInputElement).value));
  }

}

