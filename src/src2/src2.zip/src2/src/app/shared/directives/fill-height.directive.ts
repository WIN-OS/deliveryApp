import { AfterViewInit, Directive, ElementRef, Renderer2 } from '@angular/core';

@Directive({
  selector: '[satFillHeight]'
})
export class FillHeightDirective implements AfterViewInit {

  constructor(private elementRef: ElementRef, private render: Renderer2) { }

  ngAfterViewInit(): void {
    const parentHeight = this.elementRef.nativeElement.parentElement.offsetHeight + 'px';

    this.render.setStyle(this.elementRef.nativeElement, 'minHeight', parentHeight);
  }
}
