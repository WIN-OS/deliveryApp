import { TaxIdDirective } from './tax-id.directive';

describe('TaxIdDirective', () => {
  it('should create an instance', () => {
    const directive = new TaxIdDirective();
    expect(directive).toBeTruthy();
  });
});
