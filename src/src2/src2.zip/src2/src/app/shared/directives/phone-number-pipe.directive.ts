import { Directive, HostListener, Self } from '@angular/core';
import { NgControl } from '@angular/forms';
import { PhonePipe, TaxIdPipe } from 'app/shared/pipes/form.pipe';

@Directive({
  selector: '[satPhoneNumberPipe]'
})
export class PhoneNumberPipeDirective {

  constructor(private phonePipe: PhonePipe, @Self() private ngControl: NgControl) { }

  @HostListener('ngModelChange', ['$event'])
  onModelChange(value: string):void {
    this.ngControl.valueAccessor?.writeValue(this.phonePipe.transform(value));
  }

  @HostListener('blur', ['$event'])
  onBlur(event: FocusEvent):void {
    this.ngControl.control?.setValue(this.phonePipe.transform((event.target as HTMLInputElement).value));
  }

}

