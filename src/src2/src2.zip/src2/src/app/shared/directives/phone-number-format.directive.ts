import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[satPhoneNumberFormat]'
})
export class PhoneNumberFormatDirective {

  private regex = new RegExp(/^[0-9]*$/);
  private maxLength = 12;

  constructor(private el: ElementRef) {}

  @HostListener('input', ['$event']) onInputChange(event: Event): void {
    const input = this.el.nativeElement as HTMLInputElement;
    let inputValue = input.value;

    // Remove non-numeric characters
    inputValue = inputValue.replace(/[^0-9]/g, '');

    // Limit the length to 10 characters
    if (inputValue.length > this.maxLength) {
      inputValue = inputValue.substring(0, this.maxLength);
    }

    // Update the input value
    input.value = inputValue;
  }

}
