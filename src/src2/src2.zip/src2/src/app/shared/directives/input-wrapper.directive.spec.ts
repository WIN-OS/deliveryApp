import { InputWrapperDirective } from './input-wrapper.directive';

describe('InputWrapperDirective', () => {
  it('should create an instance', () => {
    const directive = new InputWrapperDirective();
    expect(directive).toBeTruthy();
  });
});
