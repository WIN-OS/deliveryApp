/* eslint-disable @typescript-eslint/no-explicit-any */
import { Directive, ElementRef, Input, OnChanges, SimpleChanges } from '@angular/core';

@Directive({
  selector: '[satLabelAddress]'
})
export class LabelAddressDirective implements OnChanges {

  @Input() satLabelAddress: any;

  constructor(private el: ElementRef) { }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['satLabelAddress'] && this.satLabelAddress) {
      this.el.nativeElement.textContent = this.combineAddressValues(this.satLabelAddress);
    }
  }

  private combineAddressValues(address: any): string {
    console.log('satLabelAddress: ', JSON.stringify(address));
    let combinedAddress = '';
    for (const key in address) {
      if (address[key]) {
        combinedAddress += address[key] + ', ';
      }
    }
    // Remove the trailing comma and space
    combinedAddress = combinedAddress.slice(0, -2);
    return combinedAddress;
  }

}
