import { LabelAddressDirective } from './label-address.directive';

describe('LabelAddressDirective', () => {
  it('should create an instance', () => {
    const directive = new LabelAddressDirective();
    expect(directive).toBeTruthy();
  });
});
