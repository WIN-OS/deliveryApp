/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable @typescript-eslint/no-explicit-any */

import { EventEmitter, Injectable, Output } from '@angular/core';
import { Directive, Input, OnChanges, SimpleChanges } from '@angular/core';
import { PaginationService } from '../services/pagination.service';
import { IPaginationObj, IPaginationAsyncLoad } from '../model/interfaces';
import { Observable, finalize, map } from 'rxjs';
import * as sampleData from '../../api/search-results-npi.json';

@Directive({
  selector: '[satPaginationWrapper]'
})
export class PaginationWrapperDirective implements OnChanges {
  /*
  @Input() set paginationAsyncLoad(data: IPaginationAsyncLoad) {
    if (data) {
      this.paginationService.updatePaginationState(data);
    }
  }
 */

  @Input() totalItemsLabel = 'Items';
  @Input() items: unknown[] = [];
  @Input() totalItems = 0 ;
  @Output() asyncLoad = new EventEmitter<void>();

  //paginationState="accountSearch.pagination"
  // eslint-disable-next-line @angular-eslint/no-input-rename
  @Input('paginationOptions') set setPaginationOptions(options: string) {
    this.parsePaginationOptions(options);
  }

  private defaultPaginationState: any;
  private firstPass = true;
  private paginationAsyncLoad: IPaginationAsyncLoad = {
    items: [],
    totalItems: 0,
    pageLoading: true // Set to false once the loading is complete
  };

  constructor(private paginationService: PaginationService) {

    this.asyncLoad.subscribe(() => {
      this.paginationService.updatePaginationState(this.paginationAsyncLoad = {
        items: this.items,
        totalItems: this.totalItems,
        pageLoading: true // Set to false once the loading is complete
      });
    });

    this.defaultPaginationState = this.paginationService.getDefaultPaginationState();
    delete this.defaultPaginationState.itemsPerPage;
    this.paginationAsyncLoad = { ...this.defaultPaginationState, ...this.paginationAsyncLoad };
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['paginationState']) {
      this.loadItems();
    }
  }

  //get data from the service to this directive
  private loadItems(): void {
    if (!(this.firstPass && this.paginationAsyncLoad.items)) {
      this.paginationAsyncLoad.pageLoading = true;
      this.paginationService.paginationLoadState$.pipe(
        map(data => {
          this.paginationAsyncLoad.items = data.items;
          this.paginationAsyncLoad.totalItems = data.totalItems;
        }),
        finalize(() => this.paginationAsyncLoad.pageLoading = false)
      )      
      //this.paginationService.asyncLoad(this.paginationState).then((data: IPaginationAsyncLoad) => {
      // this.paginationState.items = data.items;
      // this.paginationState.totalItems = data.totalItems;
      // }).finally(() => {
      //   this.paginationState.pageLoading = false;
      // });
      this.firstPass = false;
    }
  }

  parsePaginationOptions(paginationOptions: string): any[]| boolean{
    let paginationOptionsParsed: any[];
    if (!paginationOptions || paginationOptions === 'default') {
      paginationOptionsParsed = this.paginationService.getDefaultPaginationOptions();
    } else if (paginationOptions.toLowerCase() === 'null' || paginationOptions.toLowerCase() === 'false') {
      return false; // Disable pagination
    } else {
      const paginationOptionsArray = paginationOptions.split(';');
      paginationOptionsParsed = paginationOptionsArray.map(option => {
        if (option.toLowerCase() !== 'all' && isNaN(Number(option))) {
          throw new Error(`Error compiling pagination-wrapper directive! "${paginationOptions}" is not a valid value for the pagination-options attribute! Valid values are: [null or false] to disable pagination or a string with whole numeric numbers (or the "All" keyword) separated by a semi-colon: i.e. "10;20;100;All"`);
        }
        return option;
      });
    }
    return this.buildPaginationOptionsList(paginationOptionsParsed);
  }

  buildPaginationOptionsList(paginationOptions: any[]): { label: string, value: number }[] {
    return paginationOptions.map(option => {
      if (option.toLowerCase() === 'all') {
        return { label: 'All', value: 0 }; // 0 indicates all items
      } else {
        const value = Number(option);
        return { label: `${value} per page`, value };
      }
    });
  }
}


