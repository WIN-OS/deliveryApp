import { NgModule, Query } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiErrorMessageService } from 'app/core/api-error-message.service';
import { AuthorizedUsersService } from './services/authorized-users.service';
import { LoginTargetService } from './services/login-target.service';
import { MessagesService } from './services/messages.service';
import { PaginationService } from './services/pagination.service';
import { QueryBuilderService } from './services/query-builder.service';
import { RouteHelperService } from './services/route-helper.service';
import { SecurityService } from './services/security.service';
import { ValidationService } from './services/validation.service';
import { InputWrapperDirective } from './directives/input-wrapper.directive';
import { JustifyGroupDirective } from './directives/justify-group.directive';
import { HttpClientModule } from '@angular/common/http';
//import { EditProfileFormComponent } from './vsp-ui-components/edit-profile-form/edit-profile-form.component';
import { CoreModule } from 'app/core/core.module';
//import { PaginationWrapperComponent } from './vsp-ui-components/pagination-wrapper/pagination-wrapper.component';
//import { VspTableColumnComponent } from './vsp-ui-components/vsp-table-column/vsp-table-column.component';
//import { VspTableComponent } from './vsp-ui-components/vsp-table/vsp-table.component';
//import { VspTableHeaderComponent } from './vsp-ui-components/vsp-table-header/vsp-table-header.component';
//import { VspTableColumnsComponent } from './vsp-ui-components/vsp-table-columns/vsp-table-columns.component';
//import { VspTableHeadersComponent } from './vsp-ui-components/vsp-table-headers/vsp-table-headers.component';



@NgModule({
  declarations: [
    //VspTableHeaderComponent,
    //VspTableHeadersComponent,
    //VspTableComponent,
    //VspTableColumnComponent,
    //VspTableColumnsComponent,
   // EditProfileFormComponent
  

  ],
  providers : [
    ApiErrorMessageService,
    AuthorizedUsersService,
    MessagesService,
    PaginationService,
    QueryBuilderService,
    RouteHelperService,
    SecurityService,
    ValidationService,
    InputWrapperDirective,
    JustifyGroupDirective,
    

  ],
  imports: [
    CommonModule,
    HttpClientModule,
    CoreModule
  ]
})
export class SharedModule { }
