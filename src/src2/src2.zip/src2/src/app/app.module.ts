import { NgModule, inject } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppMaterialModule } from './shared/app-material.module';
import { HeaderComponent } from './secured/components/header/header.component';
import { AccessDeniedComponent } from './public/access-denied/access-denied.component';
import { FooterComponent } from './secured/components/footer/footer.component';
import { SecuredModule } from './secured/secured.module';
import { FormsModule, ReactiveFormsModule, FormGroup } from '@angular/forms';
import { AuthenticationService, AuthenticationModule } from '@vsp/angular-core-libraries';
import { MatPasswordStrengthModule } from '@angular-material-extensions/password-strength';

import {
  HTTP_INTERCEPTORS,
  HttpClientModule,
  HttpClient,
} from '@angular/common/http';
import { LoadingInterceptorService } from './core/loading-interceptor.service';
//import { LandingPageComponent } from './public/landing-page/landing-page.component';
import { OAuthConfigService } from './core/oauth/oauth-config.service';
import { ApiConfigService } from './core/api-config.service';
//import { AuthorizedUsersApiConfigService } from './core/authorized-users-api-config.service';
import { AuthenticationServiceInternal } from './core/authentication.service';
//import { ApiService } from './core/api.service';
//import { BaseHttpService } from './core/base-http.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { OauthRedirectComponent } from './oauth-redirect.component';
//import { canActivateUser } from './core/oauth/auth.guard';
import { HeadersInterceptor } from './core/headers.interceptor';
import { SharedModule } from './shared/shared.module';
import { environment } from 'environments/environment';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';
//import { EditProfileFormComponent } from './shared/vsp-ui-components/edit-profile-form/edit-profile-form.component';
//import { IHttpClient } from './shared/model/http-client.interface';

import {RouterLink, RouterLinkActive, RouterOutlet} from '@angular/router';
import {CoreModule} from './core/core.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { DateUtilService } from './core/date-util.service';

@NgModule({
  declarations: [
    AppComponent,
   // HeaderComponent,
    AccessDeniedComponent,
    //FooterComponent,
    OauthRedirectComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
   SecuredModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgbModule,
    SharedModule,
    AppMaterialModule,
    AuthenticationModule.forRoot(
      environment.oauthApiUrl,
      environment.openIdUrl,
      environment.oauthClientId,
      environment.oauthScopes,
      environment.oauthRedirectPageUrl
    ),
    MatPasswordStrengthModule.forRoot(),
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    FontAwesomeModule,
  ],
  providers: [
    LoadingInterceptorService,
    OAuthConfigService,
    ApiConfigService,
    //AuthorizedUsersApiConfigService,
    AuthenticationServiceInternal,
    //AuthenticationService,
    HttpClientModule,
    ApiConfigService,
    CoreModule,
    DateUtilService
    //ApiService,
    //AuthorizedUsersApiConfigService,
    /*{
      provide: HTTP_INTERCEPTORS,
      useClass: HeadersInterceptor,
      multi: true,
    },
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: { appearance: 'outline' },
    },*/
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

/*

{
    "oauthApiUrl": "https://api-integration.vsp.com",
    "openIdUrl": "https://api-integration.vspglobal.com/idp/userinfo.openid",
    "oauthClientId" : "vsp-retail-admin-ui",
    "oauthScopes" : "auth_employee_sso openid profile write:gb.retailadmin read:gb.retailadmin read:vc.pe_management provider_view",
    "oauthRedirectPageUrl": "http://localhost:4200/sat-account-search"
  }
  */