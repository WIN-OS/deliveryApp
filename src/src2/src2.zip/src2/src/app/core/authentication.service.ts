/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/naming-convention */
import { Injectable, OnInit, Renderer2, RendererFactory2, inject } from '@angular/core';
import { BehaviorSubject, Observable, ReplaySubject, Subject, catchError, filter, fromEvent, map, of, tap, throwError } from 'rxjs';
import { OauthTokenService } from './oauth/oauth-token.service';
import { IAdminUserResponse, IUser } from '../shared/model/interfaces';
import { OAuthConfigService } from './oauth/oauth-config.service';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthenticationService } from '@vsp/angular-core-libraries';
import { environment } from 'environments/environment';
import { LocalStorage } from '@ng-idle/core/lib/localstorage';
import { ApiConfigService } from './api-config.service';


@Injectable({
  providedIn: 'root'
})
export class AuthenticationServiceInternal {

  userProfile: any = null;
  userProfileDeferred: Subject<any> = new Subject<any>();
  acsLogoutDeferred: Subject<any> = new Subject<any>();
  watchingSessionTimeout = false;
  preLogoutHandlers: any[] = [];
  preSessionTimeoutHandlers: any[] = [];
  userInfoApi: any; // Replace with the actual type

  private router = inject(Router);
  private vspAuthService = inject(AuthenticationService);
  private oauthConfigService = inject(OAuthConfigService);
  private apiConfigService = inject(ApiConfigService);
  BASE_URL = `${environment.apiUrl}/retail-admin/adminuser`;
  private http =inject(HttpClient);
  /**
   * Called by the AuthGuard to determine if the session is active for all secure pages. If true is returned then the
   * user is logged in, false if the user is not logged in.
   * @returns Observable<boolean>
   */
  isSessionActive(): boolean {
   return this.vspAuthService.isAuthenticated()?? false;
    }

   logout():void {
    this.vspAuthService.logout();
   } 

  checkAuth():boolean|void{
    this.vspAuthService
    .checkAuthentication(environment.oauthRedirectPageUrl)
    .pipe(
      tap(result => {
        if (result) {
          let redirectUrl = '';
          if (
            localStorage &&
            localStorage.getItem('login_redirect') !== null &&
            localStorage.getItem('login_redirect') !== ''
          ) {
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            redirectUrl = localStorage.getItem('login_redirect');
            localStorage.removeItem('login_redirect');
            this.router.navigateByUrl(redirectUrl);
          }
        }
        return result;
      })
    );
  }

//Oauth service methods from LEGACY app

getUserProfile(): Observable<any> {
  // perform the call to check admin access
  return this.http.get<IAdminUserResponse>(this.BASE_URL).pipe(
    tap(response => {
      // This will be executed if the request is successful.
      // You can call your success function here.
      this.loadUserProfileSuccess(response);
    }),
    catchError(error => {
      // This will be executed if the request fails.
      // You can call your failure function here.
      this.loadUserProfileFail(error);
      // We need to return an Observable for the catchError operator.
      // Here we return an Observable of the error.
      return throwError(error);
    })
  );
}

loadUserProfileSuccess(userProfile: any): void {
  // set the user profile on the oauth service
  this.userProfile = userProfile;

  //TODO
  // set google analytics user information
  //this.setAnalyticsUser(userProfile);

  //TODO
  // check if the user is a costco dispensary
  //this.checkIfUserIsCostcoDispensary();

  // resolve the user profile promise
  this.userProfileDeferred.next(this.userProfile);
}
 
loadUserProfileFail(response: any): void {
  // if userInfoApi is null, there was an issue injecting the service (or no service was defined)
  // log an error and then reject the userProfileDeferred promise
  console.error('Could not find a service named "' + this.oauthConfigService.userInfoApi + '" to use for common.oauth.service.getUserProfile(). ' +
              'Rejecting the getUserProfile promise, use common.oauth.config.setUserInfoApi() to set the name of the service to be used.');
        
  // log the user out
    this.logout();
      // show an error message when logout is complete unless showUserProfileErrorMessage is set to false
      if (this.oauthConfigService.showUserProfileErrorMessage){
        //TODO
        //this.apiErrorMessageService.showPageAlertErrorMessage(response, 'userInfoApiError', this.USER_INFO_GENERIC_ERROR_MESSAGE, {parseToHTML: true});
      }
  
      // reject the userprofile promise
      this.userProfileDeferred.error(response);
}
}

//TODO - refactor later  or delete it - not sure if userProfileDeferred subject is needed in Angular v16
  // if userProfileDeferred is null, create a new deferred promise and call the userinfo API
  //this.userProfileDeferred = new Subject<any>();
  //if (!this.userProfileDeferred){
       
    //}

    // make sure we have a valid userInfoApi
    // invoke the get function to get the user profile
    /*
    if (this.userInfoApi){
      this.userInfoApi.get().subscribe(
        (        userProfile: any) => this.loadUserProfileSuccess(userProfile),
        (        response: any) => this.loadUserProfileFail(response)
      );
    }
    else {
      // if userInfoApi is null, there was an issue injecting the service (or no service was defined)
      // log an error and then reject the userProfileDeferred promise
      console.error('Could not find a service named "' + this.oauthConfigService.userInfoApi + '" to use for common.oauth.service.getUserProfile(). ' +
                    'Rejecting the getUserProfile promise, use common.oauth.config.setUserInfoApi() to set the name of the service to be used.');
      this.userProfileDeferred.error({});
    }
  }

  // return the userprofile promise
  return this.userProfileDeferred.asObservable();
  }
*/

  



