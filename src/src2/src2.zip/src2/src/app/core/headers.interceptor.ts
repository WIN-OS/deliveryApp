/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable prefer-const */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Injectable, inject } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ApiConfigService } from './api-config.service';
import { OauthTokenService } from './oauth/oauth-token.service';

@Injectable()
export class HeadersInterceptor implements HttpInterceptor {

  private _apiconfig = inject(ApiConfigService);
  private _oauthTokenService = inject(OauthTokenService);
  
  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
  // Append Authorization header to any API request
  if (this.isApiRequest(request)) {
    // If there is a valid OAuth token, inject the token in the Authorization header
    const token = this.getAccessToken(); // Implement your token retrieval logic
    if (token) {
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`,
        },
      });
    }

    // If the user is on IE9 and performing a GET request to an API, add an additional query parameter
    // with the current timestamp to prevent caching
    if (this.isIE9() && request.method === 'GET') {
      request = request.clone({
        setParams: {
          t: new Date().getTime().toString(),
        },
      });
    }
  }

  return next.handle(request).pipe(
    catchError((error) => {
      // Handle errors here (e.g., log, show notifications, etc.)
      console.error('HTTP error:', error);
      throw error;
    })
  );
}

private isApiRequest(request: HttpRequest<any>): boolean {
 // Check if the URL contains your API base URL
  return (
    request.url.includes(this._apiconfig.getBaseUrl()) ||
    request.url.includes(this._apiconfig.getPatientEncounterUrl()) ||
    request.url.includes(this._apiconfig.getMemberPolicyUrl())
  );
}

private getAccessToken(): string | null {
  let oauthToken = null;
 // check if the user is authenticated and get the accessToken
 if(this._oauthTokenService.isAuthenticated()){
   oauthToken = this._oauthTokenService.getAccessToken();
  }
  return oauthToken;
}

private isIE9(): boolean {
  // detect IE9
  let isOldIE:boolean;
  isOldIE = ($('html').is('.lt-ie7, .lt-ie8, .lt-ie9')) ? true : false;
  return isOldIE; // Replace with your actual check
}

}
