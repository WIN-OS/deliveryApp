/* eslint-disable @typescript-eslint/no-explicit-any */

import { Injectable, inject } from '@angular/core';
import { ApiConfigService } from './api-config.service';
import { Observable } from 'rxjs';
import { ApiService } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class AuthorizedUsersApiConfigService {

  // based on legacy app - provider-portal-2020-ui/src/app/private/account/authorized-users/services/authorized-users.service.ts

// eslint-disable-next-line @typescript-eslint/naming-convention
      BASE_URL!: string;
      endpoint!: string;

      private _apiConfig = inject(ApiConfigService);

      constructor(private readonly _apiService: ApiService) { 

      }

    setEndpoint(endpoint:string):void{
         // get the configured endpoint and append it to the environment base URL
         this.BASE_URL = this._apiConfig.baseUrl + endpoint;
    }
  
    // get the full URL using account number and email address
    // URL will be in the following format: {domain}/{endpoint}/{accountNumber}/users/{emailAddress}
    getFullUrl(accountNumber:string, emailAddress:string):string{
        return [this.BASE_URL, accountNumber, 'users', emailAddress].join('/');
    }

    activateUser(accountNumber:string, emailAddress:string): Observable<any>  {
      // to activate a user, do a PUT to the full URL. No payload required
     return this._apiService.put(this.getFullUrl(accountNumber, emailAddress));
  }

  deactivateUser(accountNumber:string, emailAddress:string): Observable<any>   {
      // to deactivate a user, do a DELETE to the full URL
      return this._apiService.delete(this.getFullUrl(accountNumber, emailAddress));
  }


}
