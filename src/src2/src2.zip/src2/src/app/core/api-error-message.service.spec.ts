import { TestBed } from '@angular/core/testing';

import { ApiErrorMessageService } from './api-error-message.service';

describe('ApiErrorMessageService', () => {
  let service: ApiErrorMessageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ApiErrorMessageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
