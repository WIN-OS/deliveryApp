/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable @typescript-eslint/naming-convention */



import { Injectable } from '@angular/core';
import { IAlertService } from 'app/shared/model/interfaces';
import { BehaviorSubject } from 'rxjs';
import { IAlert } from 'app/shared/model/interfaces';

@Injectable({
  providedIn: 'root'
})

export class FormAlertsService {
  private alertSubject = new BehaviorSubject(<IAlert|null>(null));
  alerts$ = this.alertSubject.asObservable();

   ALERT_TYPES = {
    DANGER: 'danger',
    SUCCESS: 'success',
    WARNING: 'warning'
  };

  addAlert(type: any, message: any, formAlertsContainerId: any, alertKey: any, options: { parseToHTML?: any; icon?: any; trustedHTML?: any; compileHTML?: any; }):unknown {
    const alertId = this.getAlertId(formAlertsContainerId, alertKey);
    options = options || {};

    if (options.parseToHTML) {
      message = this.parseMessageToHTML(message);
    }

    const existingAlert = this.findAlertById(alertId);
    if (existingAlert) {
      existingAlert.message ?? message;
      return existingAlert;
    } else {
      const newAlert = {
        message: message,
        id: alertId,
        formAlertsContainerId: formAlertsContainerId,
        type: type,
        icon: options.icon,
        trustedHTML: options.trustedHTML,
        compileHTML: options.compileHTML
      };
      this.alertSubject.next(newAlert);
      return newAlert;
    }
  }

  closeAlert(alert:any) {
    if (alert) {
      this.alertSubject.next(null);
    }
  }

  closeAlerts(alerts: any) {
    for (const alert of alerts) {
      this.closeAlert(alert);
    }
  }

  getAlertId(formAlertsContainerId: any, alertKey: any):string {
    return `${formAlertsContainerId}-${alertKey}`;
  }

  findAlertById(alertId: string) {
    const alert = this.alertSubject.getValue();
    return alert && alert.id === alertId ? alert : null;
  }

  parseMessageToHTML(message: any) {
    // Implement your HTML parsing logic here
    return message;
  }

  addDanger(message: any, formAlertsContainerId: any, alertKey: any, options: { parseToHTML?: any; icon?: any; trustedHTML?: any; compileHTML?: any; }) {
    return this.addAlert(this.ALERT_TYPES.DANGER, message, formAlertsContainerId, alertKey, options);
  }

  addSuccess(message: any, formAlertsContainerId: any, alertKey: any, options: { parseToHTML?: any; icon?: any; trustedHTML?: any; compileHTML?: any; }) {
    return this.addAlert(this.ALERT_TYPES.SUCCESS, message, formAlertsContainerId, alertKey, options);
  }

  addWarning(message: any, formAlertsContainerId: any, alertKey: any, options: { parseToHTML?: any; icon?: any; trustedHTML?: any; compileHTML?: any; }) {
    return this.addAlert(this.ALERT_TYPES.WARNING, message, formAlertsContainerId, alertKey, options);
  }
  
}
