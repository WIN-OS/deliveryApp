/* eslint-disable @typescript-eslint/no-explicit-any */
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Router, Event as RouterEvent, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SaveStateService {
   // initialize the states object where all data will be stored
  private _states = new BehaviorSubject<{ [key: string]: any }>({});

  constructor(private router: Router) {
    this.router.events.pipe(
      filter((event: RouterEvent): event is NavigationEnd => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.clearStatesNotInSafeRoutes(event.urlAfterRedirects);
    });
  }

    // save state data into the given key
  // stateKey: the key to use in _states to get/set the state (_states[stateKey])
  // data: the data to save for this state
  // options: optional object for the following options:
  //      copy: if true, the saved data will be a deep copy rather than a reference (true by default). Set this
  //            to false to save a reference to the data
  //      safeRoutes: the routes that are safe for keeping
  saveStateData(stateKey: string, data: any, options?: { copy?: boolean, safeRoutes?: string[] | boolean }): void {
    const states = this._states.getValue();
     // default options.copy to true
    const newData = options?.copy !== false ? JSON.parse(JSON.stringify(data)) : data;
     // check if safeRoutes is set
    states[stateKey] = {
      data: newData,
      safeRoutes: options?.safeRoutes || true
    };
    this._states.next(states);
  }

  getStateData(stateKey: string): any {
    // get the state by its key
    // if state is found, return state.data
    // otherwise return null
    const state = this._states.getValue()[stateKey];
    return state ? state.data : null;
  }

  clearStateData(stateKey: string): void {
     // delete the state object by key
    const states = this._states.getValue();
    delete states[stateKey];
    this._states.next(states);
  }

  private clearStatesNotInSafeRoutes(currentRoute: string): void {
     // initialize the list of states to delete during this state change
    const states = this._states.getValue();
     // if safeRoutes is not defined, delete it
     // if safeRoutes is not equal to true (keep for all states) and the current state name is not inside the safeRoutes array, delete it
    // loop through each state to be deleted and clear the state data
     Object.keys(states).forEach(key => {
      const state = states[key];
      if (state.safeRoutes !== true && !(state.safeRoutes as string[]).includes(currentRoute)) {
        delete states[key];
      }
    });
    this._states.next(states);
  }
}


