import { TestBed } from '@angular/core/testing';

import { SanitizationServiceService } from './sanitization-service.service';

describe('SanitizationServiceService', () => {
  let service: SanitizationServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SanitizationServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
