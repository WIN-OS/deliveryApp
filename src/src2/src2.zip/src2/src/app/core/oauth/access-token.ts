export class AccessToken {
  private _type: string | undefined;
  private _value: string | undefined;


  get type(): string {
    return (this._type != undefined) ? this._type : '';
  }

  set type(value: string) {
    this._type = value;
  }

  get value(): string {
    return (this._value != undefined) ? this._value : '';
  }

  set value(value: string) {
    this._value = value;
  }

  public toString(): string {
    return `${this.type} ${this.value}`;
  }
}
