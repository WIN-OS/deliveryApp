/* eslint-disable @typescript-eslint/naming-convention */
import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthenticationService } from '@vsp/angular-core-libraries';
import { environment } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class TokenInterceptor implements HttpInterceptor {
  constructor(private readonly vspAuthenticationService: AuthenticationService) {}

  private readonly LAB_USER_PREFIX = 'LAB';

  private readonly EFAN = 'efan';

  intercept(
    request: HttpRequest<unknown>,
    next: HttpHandler
  ): Observable<HttpEvent<unknown>> {
    const token = this.vspAuthenticationService.getToken();
    if (token) {
      console.log(JSON.stringify(this.vspAuthenticationService.userProfile));
      /*const efan = JSON.parse(
        JSON.stringify(this.authenticationService.userProfile)
      )[this.EFAN];

      if (efan && efan.startsWith(this.LAB_USER_PREFIX)) {
        window.location.href = environment.welcomeUrl;
      }*/

      const modifiedRequest = request.clone({
        setHeaders: {
          Authorization: token,
        },
      });
      return next.handle(modifiedRequest);
    }
    return next.handle(request);
  }
}
