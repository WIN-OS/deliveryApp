import { TestBed } from '@angular/core/testing';

import { OauthHttpInterceptor } from './oauth-http.interceptor';

describe('OauthHttpInterceptor', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      OauthHttpInterceptor
      ]
  }));

  it('should be created', () => {
    const interceptor: OauthHttpInterceptor = TestBed.inject(OauthHttpInterceptor);
    expect(interceptor).toBeTruthy();
  });
});
