import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OauthTokenService {

  //based on - legacy APP - provider-portal-ui-common/src/services/oauth/oauth-token.service.js 

  private accessToken : string | null ;

  constructor() {
    this.accessToken = null;
   }

   getAccessToken(): string | null {
    return this.accessToken ;
  }

  setAccessToken(accessToken:string):void{
    this.accessToken = accessToken;
  }

  isAuthenticated():boolean{
    return this.accessToken !== null;
  }


}
