/* eslint-disable @typescript-eslint/explicit-function-return-type */
import { TestBed } from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { TokenInterceptor } from './TokenInterceptor';
import { AuthenticationService } from '@vsp/angular-core-libraries';
import { UserProfile } from '@vsp/angular-core-libraries/authentication/user-profile';

describe('TokenInterceptor', () => {
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  const someToken = 'my-test-token';
  const testUrl = 'http://some.test.url';

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: HTTP_INTERCEPTORS,
          useClass: TokenInterceptor,
          multi: true,
        },
        {
          provide: AuthenticationService,
          useValue: {
            getToken: () => someToken,
            userProfile: { efan: '800000824' } as unknown as UserProfile,
          },
        },
      ],
    }).compileComponents();
    httpClient = TestBed.inject(HttpClient);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  it('should append bearer token to GET requests', (done: DoneFn) => {
    const testData = {
      prop1: 'some value',
    };

    httpClient.get<{ prop1: string }>(testUrl).subscribe(data => {
      expect(data).toEqual(testData);
      done();
    });
    const testRequest = httpTestingController.expectOne(testUrl);

    expect(testRequest.request.method).toEqual('GET');
    expect(testRequest.request.headers.has('Authorization')).toBeTrue();
    expect(testRequest.request.headers.get('Authorization')).toEqual(someToken);

    testRequest.flush(testData);

    httpTestingController.verify();
  });

  it('should append bearer token to POST requests', (done: DoneFn) => {
    const testData = {
      prop1: 'some value',
    };

    httpClient.post<{ prop1: string }>(testUrl, testData).subscribe(data => {
      expect(data).toEqual(testData);
      done();
    });

    const testRequest = httpTestingController.expectOne(testUrl);

    expect(testRequest.request.method).toEqual('POST');
    expect(testRequest.request.headers.has('Authorization')).toBeTrue();
    expect(testRequest.request.headers.get('Authorization')).toEqual(someToken);

    testRequest.flush(testData);

    httpTestingController.verify();
  });
});
