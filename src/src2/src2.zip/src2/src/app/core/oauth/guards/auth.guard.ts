import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { Observable, of, tap } from 'rxjs';
import { AuthenticationService } from '@vsp/angular-core-libraries';
import { environment } from '../../../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  private readonly cypressTokenKey = 'cypress_token';

  constructor(
    private readonly authenticationService: AuthenticationService,
    private router: Router
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> {
    const token = sessionStorage.getItem(this.cypressTokenKey);

    if (token) {
      this.authenticationService.receiveToken(token);
      //removing the cypress test session token after logged in
      sessionStorage.removeItem(this.cypressTokenKey);
    }
    if (
      !this.authenticationService.loggedIn &&
      localStorage &&
      (localStorage.getItem('login_redirect') == null ||
        localStorage.getItem('login_redirect') === '')
    ) {
      localStorage.setItem('login_redirect', state.url);
    }

    // check if we're already logged in, if so move on
    if (this.authenticationService.loggedIn) {
      return of(true);
    }

    // check if page load or router navigation, then login if appropriate
    return this.authenticationService
      .checkAuthentication(environment.oauthRedirectPageUrl)
      .pipe(
        tap(result => {
          if (result) {
            let redirectUrl = '';
            if (
              localStorage &&
              localStorage.getItem('login_redirect') !== null &&
              localStorage.getItem('login_redirect') !== ''
            ) {
              // eslint-disable-next-line @typescript-eslint/ban-ts-comment
              // @ts-ignore
              redirectUrl = localStorage.getItem('login_redirect');
              localStorage.removeItem('login_redirect');
              this.router.navigateByUrl(redirectUrl);
            }
          }
          return result;
        })
      );
  }
}
