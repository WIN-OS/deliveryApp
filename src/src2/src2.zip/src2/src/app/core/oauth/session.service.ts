import { Injectable } from '@angular/core';
import { AutoResume, DEFAULT_INTERRUPTSOURCES, Idle } from '@ng-idle/core';
import { ISessionService, ISessionConfig, IAlertService } from '../../shared/model/interfaces';

import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
//import { SessionTimeoutComponent } from '@app/shared/components/session-timeout/session-timeout.component';
import { Router } from '@angular/router';
import { AuthenticationServiceInternal } from '../authentication.service';
import { environment } from '../../../environments/environment';
import { SessionTimeoutComponent } from '../../secured/components/session-timeout/session-timeout.component';
import { AuthenticationService } from '@vsp/angular-core-libraries';



@Injectable({
  providedIn: 'root'
})
export class SessionService implements ISessionService {
  private isInitiated = false;
  private modalRef: NgbModalRef | undefined;
  private modalOptions: NgbModalOptions = {
    size: 'md',
  };

  public get sessionConfig(): ISessionConfig {
    return environment.sessionConfig;
  }

  constructor(
    private readonly idle: Idle,
    private readonly _modalService: NgbModal,
    private readonly _authenticationService: AuthenticationServiceInternal,
    private vspAuthenticationService : AuthenticationService,
    private readonly _alertService: IAlertService,
    private readonly _router: Router,
  ) { }

  private onAuthenticationChange(isAuthenticated: boolean): void {
    if (isAuthenticated) {
      this.isInitiated ? this.restartSession() : this.startSession();
    } else {
      console.log('SESSION SERVICE: FAILED AUTH');
      this._router.navigate(['sign-in']);
      this.stopSession();
    }
  }

  public init():void {
    if(this.vspAuthenticationService.isAuthenticated()){
      this.onAuthenticationChange(this.vspAuthenticationService.isAuthenticated());
    }
  }

  public startSession():void {
    this.setupNgIdle();

    this.idle.onIdleStart.subscribe(() => this.openModal());
    this.idle.onTimeoutWarning.subscribe((countdown: number) => this.setCountdown(countdown));
    this.idle.onTimeout.subscribe(() => this.timeoutUser());

    this.isInitiated = true;

    this.restartSession();
  }

  private setupNgIdle(): void {
    this.idle.setIdle(this.sessionConfig.idle);
    this.idle.setTimeout(this.sessionConfig.timeout);
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    this.idle.setAutoResume(AutoResume.notIdle);
  }

  private openModal(): void {
    this.modalRef = this._modalService.open(SessionTimeoutComponent, this.modalOptions);
    this.modalRef.componentInstance.logout.subscribe(() => this.logoutUser());
  }

  private setCountdown(countdown: number): void {
    if (this.modalRef && this.modalRef.componentInstance) {
      this.modalRef.componentInstance.countdown = countdown;
    } else {
      this.restartSession();
    }
  }

  private logoutUser(): void {
    if(this.modalRef){
      this.modalRef.close();
      // TODO 
      //this._authenticationService.signOut();
      this.stopSession();
    }
  }

  private timeoutUser(): void {
    this.logoutUser();
    const idleTimeInMinutes = this.convertSecondsToMinutes(this.sessionConfig.idle);
    console.log('SESSION SERVICE: TIMEOUT USER');
    this._router.navigate(['sign-in']).then(() =>
      this._alertService.addWarning(`Your session has exceeded ${idleTimeInMinutes} minutes of inactivity. Please log in again.`)
    );
  }

  private convertSecondsToMinutes(time: number): number {
    return time / 60;
  }

  public stopSession(): void {
    this.idle.stop();
  }

  public restartSession(): void {
    this.idle.watch();
  }
}
