import { HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { RestApiInterceptor } from './RestApiInterceptor';
import { environment } from '../../../../environments/environment'

describe('RestApiInterceptor', () => {
  let httpClient: HttpClient;
  let httpTestingController: HttpTestingController;
  const testApiEndpoint = '/some/api';
  const testUrlWithBaseSection = 'http://some.url/endpoint';

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: HTTP_INTERCEPTORS,
          useClass: RestApiInterceptor,
          multi: true,
        },
      ],
    }).compileComponents();

    httpClient = TestBed.inject(HttpClient);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  it('should append apiBaseUrl on GET requests', (done: DoneFn) => {
    const testData = {
      prop1: 'some value',
    };

    httpClient.get<{ prop1: string }>(testApiEndpoint).subscribe(data => {
      expect(data).toEqual(testData);
      done();
    });
    const testRequest = httpTestingController.expectOne(
      `${environment.apiBaseUrl}${testApiEndpoint}`
    );

    expect(testRequest.request.method).toEqual('GET');

    testRequest.flush(testData);

    httpTestingController.verify();
  });

  it('should NOT append apiBaseUrl on GET requests when url already has a base url', (done: DoneFn) => {
    const testData = {
      prop1: 'some value',
    };

    httpClient
      .get<{ prop1: string }>(testUrlWithBaseSection)
      .subscribe(data => {
        expect(data).toEqual(testData);
        done();
      });
    const testRequest = httpTestingController.expectOne(testUrlWithBaseSection);

    expect(testRequest.request.method).toEqual('GET');

    testRequest.flush(testData);

    httpTestingController.verify();
  });

  it('should append apiBaseUrl on POST requests', (done: DoneFn) => {
    const testData = {
      prop1: 'some value',
    };

    httpClient
      .post<{ prop1: string }>(testApiEndpoint, { some: 'value' })
      .subscribe(data => {
        expect(data).toEqual(testData);
        done();
      });
    const testRequest = httpTestingController.expectOne(
      `${environment.apiBaseUrl}${testApiEndpoint}`
    );

    expect(testRequest.request.method).toEqual('POST');

    testRequest.flush(testData);

    httpTestingController.verify();
  });

  it('should NOT append apiBaseUrl on POST requests when url contains a valid url', (done: DoneFn) => {
    const testData = {
      prop1: 'some value',
    };

    httpClient
      .post<{ prop1: string }>(testUrlWithBaseSection, { some: 'value' })
      .subscribe(data => {
        expect(data).toEqual(testData);
        done();
      });
    const testRequest = httpTestingController.expectOne(testUrlWithBaseSection);

    expect(testRequest.request.method).toEqual('POST');

    testRequest.flush(testData);

    httpTestingController.verify();
  });
});
