import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RedirectGuard implements CanActivate {
  constructor(private readonly router: Router) {}

  canActivate(): Observable<boolean> {
    const redirectUrl = sessionStorage.getItem('redirectUrl');
    if (redirectUrl) {
      sessionStorage.removeItem('redirectUrl');
      const {
        segments,
        queryParams,
      }: { segments: string[]; queryParams: { [key: string]: string } } =
        JSON.parse(redirectUrl);
      this.router.navigate(segments, { queryParams });
    } else {
      this.router.navigate(['']);
    }
    return of(false);
  }
}
