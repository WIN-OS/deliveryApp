/* eslint-disable @typescript-eslint/no-explicit-any */
import { Injectable, inject } from '@angular/core';
import { Location } from '@angular/common';
import { IAuthConfigs } from '../../shared/model/interfaces';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class OAuthConfigService {

        //based on - legacy APP - provider-portal-ui-common/src/providers/oauth.config.js

        // base config variables
         oauthRedirectPage: string;
         openIdUrl: string;
         oauthBaseUrl: string;
         oauthClientId: string;
         oauthScopes: string[];
         acsIframePath: string;
         private _loginLandingPageState: string;
         private _logoutLandingPageState: string;
         isVerifiedFlag :boolean | undefined;
         errorRedirectUri : string | undefined;
         private _showUserProfileErrorMessage: boolean;
         private _userInfoApi : string | undefined;

        constructor(private _location:Location) { 
            // configure the OAuth provider
            this.oauthBaseUrl =  environment.oauthApiUrl;
            this.openIdUrl = environment.openIdUrl;
            this.oauthClientId = 'vsp-retail-admin-ui';
            this.oauthScopes = [
                'auth_employee_sso',
                'openid',
                'profile',
                'write:gb.retailadmin',
                'read:gb.retailadmin',
                'read:vc.pe_management',
                'provider_view'
              ];
            this.oauthRedirectPage = environment.oauthRedirectPageUrl;
            this._loginLandingPageState = 'sat-search-form';
            this._logoutLandingPageState = '';
            this._showUserProfileErrorMessage = true;
            this._userInfoApi = 'userinfo.api';
            // sets the path to the ACS iframe (relative to "oauthBaseUrl", defaults to "/acs2/iframe")
            this.acsIframePath = '/acs2/iframe';
        }

        private config: any;

        // REQUIRED SETTINGS =========================================
        // sets the base domain/URL to be used when authenticating with the ACS iframe
        setOauthBaseUrl(oauthBaseUrl:string):void{
            this.oauthBaseUrl = oauthBaseUrl;
        }

        // sets the client-id to use with ACS/PingFed
        setOauthClientId(oauthClientId:string):void{
            this.oauthClientId = oauthClientId;
        }

        // sets the OAuth scopes to use with ACS/PingFed
        setOauthScopes(oauthScopes:string[]):void{
            this.oauthScopes = oauthScopes;
        }

        // === END REQUIRED SETTINGS =========================================


        // OPTIONAL SETTINGS =========================================
        // sets the redirect page to be used in the ACS iframe (defaults to '/oauth_redirect.html')
        setOauthRedirectPage(oauthRedirectPage:string):void{
            this.oauthRedirectPage = oauthRedirectPage;
        }
        

        // sets the application state to redirect to when attempting to sign in if user already has a PingFed/ACS session
        setLoginLandingPageState(loginLandingPageState:string):void{
            this._loginLandingPageState = loginLandingPageState;
        }

        // sets the application state to redirect to on logout
        setLogoutLandingPageState(logoutLandingPageState:string):void{
            this._logoutLandingPageState = logoutLandingPageState;
        }

        // defaults to true, set to false to disable automatically showing an API error when
        // common.oauth.service.getUserProfile() fails (some apps may not show an error or show a custom error)
        setShowUserProfileErrorMessage(showUserProfileErrorMessage:boolean):void{
            this._showUserProfileErrorMessage = showUserProfileErrorMessage;
        }

        // set a service name to use when invoking common.oauth.service.getUserProfile()
        // Note: the service defined must contain a "get" function that will be invoked during getUserProfile
        //       and must return a promise
        setUserInfoApi(userInfoApi:string):void{
            this._userInfoApi = userInfoApi;
        }
        
        public getBaseUrl():string {
        if(this.verifyRequiredConfigVariables()){
            return this.oauthBaseUrl;
        }else{
            throw Error('Base Url is undefined');
        }
        }

        public getOauthClientId():string {
        if(this.verifyRequiredConfigVariables()){
            return this.oauthClientId;
        }else{
            throw Error('Base Url is undefined');
        }
        }

        public getOauthScopes():string[] {
        if(this.verifyRequiredConfigVariables()){
            return this.oauthScopes;
        }else{
            throw Error('Base Url is undefined');
        }
        }

        public getOauthRedirectPage():string {
        if(this.verifyRequiredConfigVariables()){
            return this.oauthRedirectPage;
        }else{
            throw Error('Base Url is undefined');
        }
        }

        public getErrorRedirectUri():string | undefined {
        if(this.verifyRequiredConfigVariables()){
            return this.errorRedirectUri;
        }else{
            throw Error('Base Url is undefined');
        }
        }

        // === END OPTIONAL SETTINGS =========================================
        verifyRequiredConfigVariables():boolean{
            const injectError = 'Error injecting oauth.config - ';
            this.isVerifiedFlag = true;
            if((!this.oauthBaseUrl)||(!this.oauthClientId)||(!this.oauthScopes)){
                this.isVerifiedFlag =false;
            }
            if (!this.oauthBaseUrl){
                throw Error(injectError + 'OAuth Base Url has not been set! Use oauth.config.setOauthBaseUrl() to set.');
            }
            if (!this.oauthClientId){
                throw Error(injectError + 'OAuth Client ID has not been set! Use oauth.config.setOauthClientId() to set.');
            }
            if (!this.oauthScopes){
                throw Error(injectError + 'OAuth Scopes have not been set! Use oauth.config.setOauthScopes() to set.');
            }
            return this.isVerifiedFlag;
        }


        public get acsIframeUrl():string {
        if(this.verifyRequiredConfigVariables()){
            // get the current protocol/domain/port for the app to user in the redirect URI
            // we can't use window.location.origin because IE9 does not support that property
            // first split the curren URL by "/"
            const urlPieces: string[] = this._location.path().split('/');
            // join the first piece and 3rd piece with '//' (the second piece of the array is blank because of the double '//'
            const origin = [urlPieces[0], urlPieces[2]].join('//');
            // build the full redirect URL
            const redirectUrl = origin + this.oauthRedirectPage;

            // combine scopes array into a single string, separated by spaces, to set on the acs iframe URL
            const scopeString = this.oauthScopes.join(' ');

            // build the full ACS iframe URL
            const acsIframeUrl = [this.oauthBaseUrl, this.acsIframePath, '?client_id=', this.oauthClientId, '&scope=', scopeString, '&redirect_uri=', redirectUrl].join('');
            console.log('OAUTH CONFIG: acsIframeUrl',acsIframeUrl)
            return acsIframeUrl;
        }else{
            throw Error('acsIframeUrl is undefined');
        }
        }
 
        public get loginLandingPageState():string {
        if(this.verifyRequiredConfigVariables()){
            return this.loginLandingPageState;
        }else{
            throw Error('loginLandingPageState is undefined');
        }
        }
 
        public get logoutLandingPageState():string {
        if(this.verifyRequiredConfigVariables()){
            return this.logoutLandingPageState;
        }else{
            throw Error('logoutLandingPageState is undefined');
        }
        }

        public get showUserProfileErrorMessage():boolean {
        if(this.verifyRequiredConfigVariables()){
            return this.showUserProfileErrorMessage;
        }else{
            throw Error('showUserProfileErrorMessage is undefined');
        }
        }

        public get userInfoApi():string | undefined {
        if(this.verifyRequiredConfigVariables()){
            return this._userInfoApi;
        }else{
            throw Error('userInfoApi is undefined');
        }
        }

    }
 
      

