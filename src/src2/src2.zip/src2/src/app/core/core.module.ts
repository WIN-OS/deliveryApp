import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiConfigService } from './api-config.service';
import { OauthTokenService } from './oauth/oauth-token.service';
import { OAuthConfigService } from './oauth/oauth-config.service';
import { DataService } from './data.service';
import { LoggerService } from './logger.service';
import { NavigationService } from './navigation.service';
import { AnalyticsService } from './analytics.service';
import { PageAlertService } from './page-alert.service';
import { AccessToken } from './oauth/access-token';
import { OauthHttpInterceptor } from './oauth/oauth-http.interceptor';
import { SessionService } from './oauth/session.service';
import { ApiService } from './api.service';
import { AuthenticationServiceInternal } from './authentication.service';
import { AuthorizedUsersApiConfigService } from './authorized-users-api-config.service';
import { LogTransactionService } from './log-transaction.service';
import { SanitizationServiceService } from './sanitization-service.service';
import { StateHelperService } from './state-helper.service';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {AuthenticationService} from '@vsp/angular-core-libraries';
import {TokenInterceptor} from './oauth/interceptors/TokenInterceptor';
import {RestApiInterceptor} from './oauth/interceptors/RestApiInterceptor';
import { NgbModule, NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';
@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    HttpClientModule,
  ],
  providers: [
   // OauthService,
    AccessToken,
    OAuthConfigService,
    OauthTokenService,
    OauthHttpInterceptor,
    SessionService,
    AnalyticsService,
    ApiConfigService,
    ApiService,
    AuthenticationServiceInternal,
    AuthorizedUsersApiConfigService,
    DataService,
    LogTransactionService,
    LoggerService,
    NavigationService,
    PageAlertService,
    SanitizationServiceService,
    StateHelperService,
    AuthenticationService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: RestApiInterceptor,
      multi: true,
    },
  ]
})
export class CoreModule { }


//Abstract classes
//SearchFormComponent,
//BaseHttpService,
//Date util - functions
//   HeadersInterceptor,
//loading interceptors