/* eslint-disable @typescript-eslint/no-explicit-any */

import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ApiErrorMessageService {
  // eslint-disable-next-line @typescript-eslint/naming-convention
  private readonly GENERIC_MESSAGE = 'A problem was encountered processing your request, please try again. If you are still experiencing a problem, check back at a later time.';

  private errorMessageSubject = new BehaviorSubject<string | null>(null);
  errorMessage$: Observable<string | null> = this.errorMessageSubject.asObservable();


  showPageAlertErrorMessage(apiResponse: any, messageKey: string, defaultMessage?: string, options?: any): string {
    const errorMessage = this.getErrorMessage(apiResponse, defaultMessage);
    this.errorMessageSubject.next(errorMessage);
    return errorMessage;
  }

  showFormAlertErrorMessage(apiResponse: any, formAlertsContainerId: string, messageKey: string, defaultMessage?: string, options?: any): void {
    const errorMessage = this.getErrorMessage(apiResponse, defaultMessage);
    // Implement form alerts logic here
  }

  closePageAlertErrorMessage(): void {
    this.errorMessageSubject.next(null);
  }

  closeFormAlertErrorMessage(): void {
    // Implement form alerts close logic here
  }

  private getErrorMessage(apiResponse: any, defaultMessage?: string): string {
    if (apiResponse && apiResponse.data && apiResponse.data.userMessage) {
      return apiResponse.data.userMessage;
    }
    return defaultMessage || this.GENERIC_MESSAGE;
  }
}
