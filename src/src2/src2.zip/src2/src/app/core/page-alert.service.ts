/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/naming-convention */
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { NgbAlertConfig } from '@ng-bootstrap/ng-bootstrap';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { Alert, AlertOptions } from 'app/shared/model/interfaces';

@Injectable({
  providedIn: 'root',
})
export class PageAlertService {
  private readonly FADE_OUT_ANIMATION_DURATION = 500;
  
  public alerts: Alert[] = [];
  private errorMessageSubject = new BehaviorSubject<string | null>(null);
  
  constructor(private alertConfig: NgbAlertConfig,
              private sanitizer: DomSanitizer
  ) { }

  addSuccess(message: string, id: string, options?: AlertOptions):void {
    this.addAlert(ALERT_TYPES.SUCCESS,message,id,options);
    }

  addError(message: string, id: string, options?: AlertOptions):void {
    this.addAlert(ALERT_TYPES.DANGER,message,id,options);
    }

  addWarning(message: string, id: string, options?: AlertOptions):void {
    this.addAlert(ALERT_TYPES.WARNING,message,id,options);
    }

  addAlert(alertType: ALERT_TYPES, message: string, id?: string, options?: AlertOptions): Alert {
    const alertId = id || this.getAlertId();
    const existingAlert = this.getAlertById(alertId);
    let sanitizedMessage :string | SafeHtml = '';

    options = options || {};
    
    if (options.trustedHTML) {
      sanitizedMessage = this.parseMessageToHTML(message);
    }
   
    if (existingAlert) {
      this.updateAlert(existingAlert, sanitizedMessage, options);
      return existingAlert;
    }

    const newAlert: Alert = {
      type: alertType,
      message: sanitizedMessage,
      icon: options.icon,
      persistOnStateChange: options.persistOnStateChange,
      trustedHTML: options.trustedHTML,
      compileHTML: options.compileHTML,
      alertClass: options.alertClass,
      id: alertId,
    };

    if (options.fadeOut) {
      this.initializeFadeOut(newAlert, options.fadeOut);
    }

    this.alerts.push(newAlert);
    return newAlert;
  }

  private updateAlert(alert: Alert, message: string | SafeHtml, options: AlertOptions): void {
    alert.message = message;
    if (alert.fadeTimeout) {
      this.cancelAlertFadeOut(alert);
    }
    if (options.fadeOut) {
      this.initializeFadeOut(alert, options.fadeOut);
    }
  }

  private initializeFadeOut(alert: Alert, fadeOutDuration: number): void {
    if (typeof fadeOutDuration !== 'number') {
      fadeOutDuration = this.FADE_OUT_ANIMATION_DURATION;
    }
    alert.fadeTimeout = setTimeout(() => {
      this.startFadeOut(alert);
    }, fadeOutDuration);
  }

  parseMessageToHTML(message: string): SafeHtml {
    return this.sanitizer.bypassSecurityTrustHtml(message);
  }

  private startFadeOut(alert: Alert): void {
    // Implement fade-out logic here
  }

  private cancelAlertFadeOut(alert: Alert): void {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
    clearTimeout(alert.fadeTimeout);
  }

  public closeAlertById(id: string): void {
    this.alerts = this.alerts.filter(alert => alert.id !== id);
  }

  // Example implementation of getAlertId and getAlertById:
  private getAlertId(id?: string): string {
    return id || `alert-${this.alerts.length + 1}`;
  }

   getAlertById(id: string): Alert | undefined {
    return this.alerts.find((alert) => alert.id === id);
  }
}


export enum ALERT_TYPES  {
  DANGER = 'danger',
  SUCCESS = 'success',
  WARNING = 'warning'
}