import { Injectable } from '@angular/core';
import { Router, UrlTree } from '@angular/router';
import { ERROR_PAGE_URL } from '../shared/constants';

@Injectable({
  providedIn: 'root'
})
export class NavigationService {
  constructor(private router: Router) {}

  navigateToErrorPage(): void {
    this.router.navigate([ERROR_PAGE_URL]);
  }

  navigateToPage(url: string | UrlTree): void {
    this.router.navigateByUrl(url);
  }
}
