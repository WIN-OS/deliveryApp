import { TestBed } from '@angular/core/testing';

import { AuthenticationServiceInternal } from './authentication.service';

describe('AuthenticationService', () => {
  let service: AuthenticationServiceInternal;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthenticationServiceInternal);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
