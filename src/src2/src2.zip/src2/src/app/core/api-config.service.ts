import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class ApiConfigService {
  

  // based on Legacy app - provider-portal-ui-common/src/providers/api.config.js
   baseUrl :string ;
   patientEncounterUrl :string;
   memberPolicyUrl :string;

     constructor() { 
       this.baseUrl = '';
       this.patientEncounterUrl = '';
       this.memberPolicyUrl = '';
     }


     setApiBaseUrl(baseUrl: string):void{
      this.baseUrl = baseUrl;
      }
      
      setMemberPolicyUrl(memberPolicyUrl: string):void{
        this.memberPolicyUrl = memberPolicyUrl;
      }
      
      setPatientEncounterBaseUrl(patientEncounterUrl: string):void {
        this.patientEncounterUrl = patientEncounterUrl;
      }

      isBaseUrlAvailable():boolean{
      if (!this.baseUrl){
          throw new Error('Error injecting api.config - API Base URL has not been set! use api.config.setApiBaseUrl() to set.');
      }
      else{
          return true;
       }
    }

  getBaseUrl():string{
    return (this.isBaseUrlAvailable()) ? this.baseUrl : '';
  }
  
  getPatientEncounterUrl():string {
    return (this.isBaseUrlAvailable()) ? this.patientEncounterUrl : '';
  }
  
  getMemberPolicyUrl(): string{
    return (this.isBaseUrlAvailable()) ? this.memberPolicyUrl : '';
  }
  
}
