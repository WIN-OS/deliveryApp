import { TestBed } from '@angular/core/testing';

import { FormAlertsService } from './form-alerts.service';

describe('FormAlertsService', () => {
  let service: FormAlertsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FormAlertsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
