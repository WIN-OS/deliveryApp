/* eslint-disable @typescript-eslint/no-unsafe-argument */
import { environment } from 'src/environments/environment';
import { Injectable, Renderer2, RendererFactory2, inject } from '@angular/core';
import { fromEvent, Observable, of, ReplaySubject } from 'rxjs';
import { HttpParams } from '@angular/common/http';
import { filter, map, switchMap, tap } from 'rxjs/operators';
import { OAuthConfigService } from './oauth/oauth-config.service';
import { IUser, IUserProfile } from '../shared/model/interfaces';
import { OauthTokenService } from './oauth/oauth-token.service';


@Injectable({
  providedIn: 'root'
})
export class AuthenticationService2 {

  private _iFrame: HTMLIFrameElement | undefined;
  private _loggedIn = false;
  private renderer: Renderer2 | undefined;
  public params: string | undefined;
  public user : IUser = { isAuthenticated: false, token: '' };
  public isAuthenticated = new ReplaySubject<boolean>(1);

  constructor(
    private readonly _rendererFactory: RendererFactory2,
    private _oauthconfigservice :OAuthConfigService,
    private _oauthtokenservice: OauthTokenService
  ) {
    this.renderer = _rendererFactory.createRenderer(null, null);
    this.params = this.createParams();
  }

  //private readonly _rendererFactory = inject(RendererFactory2);
  //private _oauthconfigservice = inject(OAuthConfigService);

  
  public set loggedIn(loggedIn: boolean) {
    this._loggedIn = loggedIn;
  }

  public get loggedIn(): boolean {
    return this._loggedIn;
  }

  private createParams():string {
    const httpParams = new HttpParams()
      .append('client_id', this._oauthconfigservice.getOauthClientId())
      .append('scope', this._oauthconfigservice.getOauthScopes().join(' '))
      .append('redirect_uri', this._oauthconfigservice.getOauthRedirectPage());
    if (this._oauthconfigservice.getErrorRedirectUri()) {
      httpParams.append('error_redirect_uri', this._oauthconfigservice.getErrorRedirectUri() ?? '');
    }
    return httpParams.toString();
  }
  
  public login():void{
    console.log('LOGIN URL: ',`${this._oauthconfigservice.getBaseUrl()}/acs2/login?${this.params}`, '_parent');
    window.open(`${this._oauthconfigservice.getBaseUrl()}/acs2/login?${this.params}`, '_parent');
  
  }

  public logout():void{
    this._iFrame?.contentWindow?.postMessage(JSON.stringify({ type: 'logout' }), '*');
    this.user.token = '';
    this.user.isAuthenticated = false;

  }


  private setUserData(tokenWithType: string):void {
    this.user = {
      ...this.user,
      isAuthenticated: Boolean(tokenWithType),
      token: tokenWithType
    };
    if (tokenWithType) {
      console.log('Auth SERvice: '+tokenWithType);
      const token = tokenWithType.split(' ')[1];
      const encodedUserData = token.split('.')[1];
      this.user.userProfile = JSON.parse(atob(encodedUserData));
    }
  }

  /**
   * Called by the AuthGuard to determine if the session is active for all secure pages. If true is returned then the
   * user is logged in, false if the user is not logged in.
   * @returns Observable<boolean>
   */
  isSessionActive(): Observable<boolean> {
    return new Observable((observer) => {
      // resolve with true if there is a valid ACS session
      if (this.loggedIn) {
        
        observer.next(true);
        observer.complete();
      } else {
        // Initialize ACS iFrame and check for token, token means they are logged in and session is active.
        //this.login();
        this.initAuthenticationService().subscribe((acsActive: boolean) => {
          console.log('AUTH SERVICE: acsActiveFlag',  acsActive);
          observer.next(acsActive);
          observer.complete();
        });
      }
    });
  }

  /**
   * This method will instantiate the iframe for ACS if it doesn't already exist and also start watching for tokens
   * being sent to the UI from the ACS iframe. The subscription to watching the iframe messages is not closed, but the
   * new Observable instantiated and returned by this method is completed so that the response observable is closed.
   * @returns Observable<boolean>
   */

  /*
  private initAuthenticationService(): Observable<boolean> {

    if(this.renderer){
      this.createIframe();
    }
    return new Observable((observer) => {
      fromEvent(window, 'message').pipe(
          filter((messageEvent: Partial<MessageEvent>) => {
           const { origin } = messageEvent || {origin: '' };
            return origin ? origin.includes(this._oauthconfigservice.acsIframeUrl): false ;
          }),
           // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
           map((messageEvent) => {
            const { data } = messageEvent || {data : undefined};
            return data;
           }),
           tap((token : string) => {
            if(token){
              console.log('AUTH TOKEN:',  token);
              this.setUserData(token);
              this.isAuthenticated.next(Boolean(token));
              this.loggedIn = true;
            }else {
              observer.next(false);
              observer.complete();
          }
           }))
          })}
this._oauthconfigservice.acsIframeUrl
this._oauthconfigservice.baseUrl
*/
           initAuthenticationService(): Observable<boolean> {
            return new Observable((observer) => {
              fromEvent(window, 'message').pipe(
                filter((messageEvent: Partial<MessageEvent>) => {
                  const { origin } = messageEvent || {origin: '' };
                  return origin ?  origin.includes(this._oauthconfigservice.acsIframeUrl) : false;
                }),
                map((event) => event.data))
                .subscribe((token: string) => {
                  if (token) {
                    this.setUserData(token);
                   // this._oauthtokenservice.setAccessToken(token);
                    this.isAuthenticated.next(Boolean(token));
                    this.loggedIn = true;
                    observer.next(true);
                    observer.complete();
                  } else {
                    observer.next(false);
                    observer.complete();
                  }
                });
                if(this.renderer){
                  const iFrame = this.renderer?.createElement('iframe');
                  iFrame.src = `${this._oauthconfigservice.getBaseUrl()}/acs2/iframe?${this.createParams()}`;
                  iFrame.style.display = 'none';
                  document.body.appendChild(iFrame);
                  //post message login
                  iFrame?.contentWindow?.postMessage(JSON.stringify({ type: 'login' }), '*');
                }
            
          });
        }
      }

  
            /*
              ,
              switchMap((token: string) => {
                if (token) {
                  // Set user data, mark as authenticated, etc.
                  console.log('AUTH TOKEN:',  token);
                 this.setUserData(token);
                 this.isAuthenticated.next(Boolean(token));
                 this.loggedIn = true;
                  return of(true);
                } else {
                  return of(false);
                }
              })
            );
          }
          */
/*
  private createIframe(): void {
    if(this.renderer){
    this._iFrame = this.renderer?.createElement('iframe');
    if(this._iFrame){
      this._iFrame.src = `${this._oauthconfigservice.baseUrl}/acs2/iframe?${this.createParams()}`;
      this._iFrame.style.display = 'none';
      this.renderer.appendChild(document.body, this._iFrame);
    }}
  }
  */
