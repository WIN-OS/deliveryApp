/* eslint-disable @typescript-eslint/no-explicit-any */
import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
import { delay, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FormService {

    // Sets view values on a list of elements to the value specified and re-renders the elements
    private setViewValues(items: NodeListOf<Element>, value: any): void {
      items.forEach(item => {
        const ngModelCtrl = (item as any).__ngModel__;
        if (ngModelCtrl) {
          ngModelCtrl.control.setValue(value);
          ngModelCtrl.control.updateValueAndValidity();
        }
      });
    }
  
    // Clears all inputs/dropdowns/etc. on the form and also resets the form state
    // Returns an observable that will resolve when clear is complete
    clearAndResetForm(form: FormGroup): Observable<any> {
      const formElement = document.querySelector(`[name='${form.controls['name'].value}']`);
  
      if (formElement) {
        this.setViewValues(formElement.querySelectorAll('input'), '');
        this.setViewValues(formElement.querySelectorAll('.dropdown-select'), null);
      } else {
        console.warn('CommonFormService.clearAndResetForm(): Could not find the form element to reset. The form parameter must be an Angular FormGroup instance with a name control!');
      }
  
      return of(null).pipe(
        delay(0),
        tap(() => this.resetFormState(form))
      );
    }
  
    // Sets a form to its initial state (untouched and pristine) to clear all validation errors
    resetFormState(form: FormGroup): void {
      form.markAsPristine();
      form.markAsUntouched();
    }
  
    // Checks if the form is missing any required fields
    isMissingRequiredFields(form: FormGroup): boolean {
      return form.invalid && form.errors?.['required'];
    }
  }
  

