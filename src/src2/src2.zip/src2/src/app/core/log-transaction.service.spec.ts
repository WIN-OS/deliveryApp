import { TestBed } from '@angular/core/testing';

import { LogTransactionService } from './log-transaction.service';

describe('LogTransactionService', () => {
  let service: LogTransactionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LogTransactionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
