/* eslint-disable @typescript-eslint/no-explicit-any */
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ArrayService {


  // Removes an item from the array by finding an item that has a matching "id" property
  // Returns true if the item was found and deleted, otherwise returns false
  removeItemById(array: any[], id: any): boolean {
    if (id !== undefined) {
      const itemIndex = array.findIndex(item => item.id === id);
      if (itemIndex !== -1) {
        this.removeItemByIndex(array, itemIndex);
        return true;
      }
    }
    return false;
  }

  // Removes an item from the array by item reference
  // Returns true if the item was found and deleted, otherwise returns false
  removeItem(array: any[], item: any): boolean {
    const itemIndex = array.indexOf(item);
    if (itemIndex !== -1) {
      this.removeItemByIndex(array, itemIndex);
      return true;
    }
    return false;
  }

  // Removes multiple items from the array - items must also be an array
  removeItems(array: any[], items: any[]): void {
    items.forEach(item => this.removeItem(array, item));
  }

  private removeItemByIndex(array: any[], index: number): void {
    array.splice(index, 1);
  }

  // Finds an item in the array by a specific property value
  // array: the array to find the item in
  // mapping: a mapping object to determine which property/value to find
  //          should be a single property on the object, where the property name is the property
  //          to check on the array items and the value is the value to check for
  //          i.e. if mapping = {name: 'Jon'}, this function will search the array for any item
  //          with a "name" property that equals 'Jon'
  findItemByProperty(array: any[], mapping: { [key: string]: any }): any {
    const key = Object.keys(mapping)[0];
    const value = mapping[key];
    return array.find(item => item[key] === value) || null;
  }
}
