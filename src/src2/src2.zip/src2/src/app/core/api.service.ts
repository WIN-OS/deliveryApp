/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */

import { Injectable } from '@angular/core';
import { BaseHttpService } from './base-http.service';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { IHttpClient } from '../../app/shared/model/http-client.interface';
import { AuthenticationServiceInternal } from './authentication.service';
import { AuthenticationService } from '@vsp/angular-core-libraries';


@Injectable({
  providedIn: 'root'
})
export class ApiService extends BaseHttpService {
  protected get serviceUrl():string {
    return environment.apiUrl;
  }

  constructor(
    httpClient: IHttpClient,
    private vspAuthenticationService :AuthenticationService,
    private authenticationService: AuthenticationServiceInternal
    ) {
    super(httpClient);
  }

  public override post<TResult>(relativeUrl: string, params?: any, options?: any): Observable<TResult> {
    return super.post<TResult>(
      relativeUrl,
      { ...(params || {}) },
      { headers: { Authorization: this.vspAuthenticationService.getToken() }, ...options });
  }

  public override get<TResult>(relativeUrl: string, params?: any, options?: any): Observable<TResult> {
    const secureApiParams = { headers: { Authorization: this.vspAuthenticationService.getToken() }, ...options, ...params };
    return super.get<TResult>(
      relativeUrl,
      { ...(secureApiParams || {}), t: new Date().getTime() });
  }

  public override put<TResult>(relativeUrl: string, params?: any, options?: any): Observable<TResult> {
    return super.put<TResult>(
      relativeUrl,
      { ...(params || {}) },
      { headers: { Authorization: this.vspAuthenticationService.getToken()}, ...options });
  }

  public override delete<TResult>(relativeUrl: string, options?: any): Observable<TResult> {
    return super.delete<TResult>(
      relativeUrl,
      { headers: { Authorization: this.vspAuthenticationService.getToken() }, ...options });
  }
}

