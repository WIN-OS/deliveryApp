import { TestBed } from '@angular/core/testing';

import { AuthorizedUsersApiConfigService } from './authorized-users-api-config.service';

describe('AuthorizedUsersApiConfigService', () => {
  let service: AuthorizedUsersApiConfigService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthorizedUsersApiConfigService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
