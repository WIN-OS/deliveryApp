import { Component, inject } from '@angular/core';
import { NavigationEnd, Route, Router } from '@angular/router';
import { OAuthConfigService } from './core/oauth/oauth-config.service';
import { ApiConfigService } from './core/api-config.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { event } from 'jquery';
import { filter } from 'rxjs/operators';
import { environment } from '../environments/environment';
import { AuthenticationServiceInternal } from './core/authentication.service';
//import { AuthorizedUsersApiConfigService } from './core/authorized-users-api-config.service';
  @Component({
  // eslint-disable-next-line @angular-eslint/component-selector
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
  })

    export class AppComponent {

      //based on - Legacy APP - provider-portal-2020-admin/src/app.js
      
      title = '2020source-admin-ui';
      url : SafeResourceUrl;


      constructor(private _router:Router,
        private _sanitizer: DomSanitizer,
        private _oauthConfig: OAuthConfigService,
        private _apiConfig: ApiConfigService,
        private _authenticationService: AuthenticationServiceInternal
      //  private _appEnvironment: envir,
       // private _authorizedUsersApiConfig: AuthorizedUsersApiConfigService
         ){
          // whitelist APIs - this is required for including the OAuth logout in an IFrame
          // Allow same origin resource loads.
          // Allow loading from vsp for OAuth
          this.url = this._sanitizer.bypassSecurityTrustResourceUrl('https://api*.vsp.com/**');
          
          // configure the OAuth provider
          this._oauthConfig.setOauthBaseUrl(environment.oauthApiUrl);
          this._oauthConfig.setOauthClientId('vsp-retail-admin-ui');
          this._oauthConfig.setOauthScopes([
            'auth_employee_sso',
            'openid',
            'profile',
            'write:gb.retailadmin',
            'read:gb.retailadmin',
            'read:vc.pe_management',
            'provider_view'
          ]);
          this._oauthConfig.setOauthRedirectPage(environment.oauthRedirectPageUrl);

          // configure the api config provider
          this._apiConfig.setApiBaseUrl(environment.apiUrl);
          this._apiConfig.setPatientEncounterBaseUrl(environment.patientEncounterUrl);
          
          /* TODO
          this._authenticationService.isSessionActive().subscribe((isActive:boolean)=>{
            if(isActive === false){
              this._authenticationService.signOn();
            }
          })
          */
          
          // set the Admin Tool authorized users API endpoint
         //this._authorizedUsersApiConfig.setEndpoint('/retail-admin-account/accountstatus');

          // don't show error alert automatically when user profile fails - for 401s we will redirect to an Access Denied page
          // so Admin Tool needs to handle these errors manually
          this._oauthConfig.setShowUserProfileErrorMessage(false);
          
          
          // scroll to the top of the page whenever state changes
          this._router.events.pipe(
            filter(event=> event instanceof NavigationEnd)
          ).subscribe(()=>{
            window.scrollTo(0,0);
      });
    }

    // set the root template path
    //pathProvider.setTemplateRoot('html/pages');

    // -- TODO -- refactor "otherwise" business logic from old app - default route   
    navigate():void{
      // For any unmatched url, redirect to /secure/home home page
      this._router.navigate(['sat-search-form']);
    }

    // use oauth.http-interceptor to push Authorization header with token into requests
    //$httpProvider.interceptors.push('common.oauth.http-interceptor');

    // initialize the security provider to add security to specific states
    //securityProvider.initializeStateSecurity();

    }


/*
]).

run([
'$rootScope',
'$window',
function($rootScope, $window){
  // scroll to the top of the page whenever state changes
  $rootScope.$on('$stateChangeSuccess',function(){
      $window.scrollTo(0, 0);
  });
}]).

// Setup scroll easing for duScroll directive
value('duScrollEasing', function (t) { return t<0.5 ? 4*t*t*t : (t-1)*(2*t-2)*(2*t-2)+1; }).
value('duScrollDuration', 700);

}
} */