/* eslint-disable @typescript-eslint/naming-convention */
import { Component, OnInit, inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationServiceInternal } from './core/authentication.service';

@Component({
  selector: 'sat-oauth-redirect',
  templateUrl: '../oauth_redirect.html'
})
export class OauthRedirectComponent implements OnInit {
 _router = inject(Router);
 _authService = inject(AuthenticationServiceInternal);

 ngOnInit(): void {
   // (this._authService.isSessionActive()).subscribe(
    //  (hasActiveSession: boolean) =>  
    //  {
        if(this._authService.isSessionActive()){
          //navigate to search form
          this._router.navigate(['sat-account-search'])
        }
    //  })
    
 }
}
