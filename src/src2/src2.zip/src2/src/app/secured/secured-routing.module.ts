import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AccountSearchComponent } from './pages/account-search/account-search.component';
import { AccessDeniedComponent } from '../public/access-denied/access-denied.component';
import { CreateAccountComponent } from './pages/create-account/create-account.component';
import { AccountDetailsComponent } from './pages/account-details/account-details.component';
import { SearchResultsComponent } from './pages/account-search/search-results/search-results.component';
import { MessagesComponent } from './pages/messages/messages.component';
import { AuthGuard } from 'app/core/oauth/guards/auth.guard';
import { EditProfileComponent } from './pages/edit-account/edit-profile/edit-profile.component';
import { EditAuthorizedUsersComponent } from './pages/edit-account/edit-authorized-users/edit-authorized-users.component';
import { EditPasswordComponent } from './pages/edit-account/edit-password/edit-password.component';
import { EditProfileFormComponent } from 'app/shared/vsp-ui-components/edit-profile-form/edit-profile-form.component';
import { EditAccountComponent } from './pages/edit-account/edit-account.component';
import { EditPopulationsComponent } from './pages/edit-populations/edit-populations.component';

const routes: Routes = [
  //{ path: '', component: SearchFormComponent, canActivate: ['canActivateUser'] },
  { path: '401', component: AccessDeniedComponent },
  { path: 'sat-account-search', component: AccountSearchComponent },
  { path: 'sat-create-account', component: CreateAccountComponent },
  { path: 'sat-account-details', component: AccountDetailsComponent, canActivate: [AuthGuard] },
  { path: 'sat-edit-populations', component: EditPopulationsComponent, canActivate: [AuthGuard] },
  { path: 'sat-edit-account', component: EditAccountComponent,
    children: [
      { path: 'sat-edit-profile', component: EditProfileComponent, canActivate: [AuthGuard] },
      { path: 'sat-edit-password', component: EditPasswordComponent, canActivate: [AuthGuard] },
      { path: 'sat-edit-authorized-users', component: EditAuthorizedUsersComponent, canActivate: [AuthGuard] },
      { path: '', redirectTo: 'sat-edit-profile', pathMatch: 'full' }
    ],
    canActivate: [AuthGuard] },
  { path: 'sat-search-results', component: SearchResultsComponent },
  { path: 'sat-messages', component: MessagesComponent },
  { path: '', redirectTo: 'sat-account-search', pathMatch: 'full' },
  { path: '**', component: AccessDeniedComponent },
];
//{ path: 'secured/search-form', component: SearchFormComponent, canActivate: ['canActivateUser'] },
//{ path: '', component: AccountSearchComponent },
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SecuredRoutingModule { }

//future components under secure module
//secure/account-search
//secure/account-details
// /secure/messages
// /secure/create-account
// /secure/edit-account
// /secure/edit-contact-us
// /secure/reference-table
// /secure/claim-search
// /secure/edit-populations
// /secure/edit-manuals
// /secure/view-claim
// register the claim form state under 'secure.view-claim.form'
