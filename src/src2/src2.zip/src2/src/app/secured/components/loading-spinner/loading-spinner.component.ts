import { Component, Input } from '@angular/core';

@Component({
  selector: 'sat-loading-spinner',
  templateUrl: './loading-spinner.component.html',
  styleUrls: ['./loading-spinner.component.scss']
})
export class LoadingSpinnerComponent {
  @Input() spinnerSize: 'small' | 'medium' | 'large' | 'x-large' = 'medium';

  get spinnerSizeClass() { 
    switch(this.spinnerSize){
      case 'small': return 'spinner-border-sm';
      case 'large': return 'spinner-large';
      case 'x-large': return 'spinner-x-large';
      case 'medium':
      default: return '';
    }
  }
  
  get textFontClass() {
      switch(this.spinnerSize){
      case 'large': return 'fs-5';
      case 'x-large': return 'fs-4';
      case 'small':
      case 'medium':
      default: return 'fs-6';
    }
  }
}
