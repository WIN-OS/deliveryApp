import { Component } from '@angular/core';

@Component({
  selector: 'sat-edit-phone-lines',
  templateUrl: './edit-phone-lines.component.html',
  styleUrls: ['./edit-phone-lines.component.scss']
})
export class EditPhoneLinesComponent {

}
