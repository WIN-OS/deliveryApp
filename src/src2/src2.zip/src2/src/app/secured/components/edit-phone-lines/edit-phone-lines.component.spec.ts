import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPhoneLinesComponent } from './edit-phone-lines.component';

describe('EditPhoneLinesComponent', () => {
  let component: EditPhoneLinesComponent;
  let fixture: ComponentFixture<EditPhoneLinesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EditPhoneLinesComponent]
    });
    fixture = TestBed.createComponent(EditPhoneLinesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
