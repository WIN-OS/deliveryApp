import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sat-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit{
   
  ngOnInit(): void {
    this.userProfile = {
      hasFullAccess : true
    };
   }

  //userprofile from API call - TODO -- later
   userProfile = {
    hasFullAccess:true
   }
}
