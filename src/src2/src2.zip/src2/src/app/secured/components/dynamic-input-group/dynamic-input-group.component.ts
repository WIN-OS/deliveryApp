import { Component } from '@angular/core';

@Component({
  selector: 'sat-dynamic-input-group',
  templateUrl: './dynamic-input-group.component.html',
  styleUrls: ['./dynamic-input-group.component.scss']
})
export class DynamicInputGroupComponent {

}
