import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicInputGroupComponent } from './dynamic-input-group.component';

describe('DynamicInputGroupComponent', () => {
  let component: DynamicInputGroupComponent;
  let fixture: ComponentFixture<DynamicInputGroupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DynamicInputGroupComponent]
    });
    fixture = TestBed.createComponent(DynamicInputGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
