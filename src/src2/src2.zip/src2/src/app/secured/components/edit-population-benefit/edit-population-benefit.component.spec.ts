import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPopulationBenefitComponent } from './edit-population-benefit.component';

describe('EditPopulationBenefitComponent', () => {
  let component: EditPopulationBenefitComponent;
  let fixture: ComponentFixture<EditPopulationBenefitComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EditPopulationBenefitComponent]
    });
    fixture = TestBed.createComponent(EditPopulationBenefitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
