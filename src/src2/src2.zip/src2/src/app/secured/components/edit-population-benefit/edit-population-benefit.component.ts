import { Component } from '@angular/core';

@Component({
  selector: 'sat-edit-population-benefit',
  templateUrl: './edit-population-benefit.component.html',
  styleUrls: ['./edit-population-benefit.component.scss']
})
export class EditPopulationBenefitComponent {

}
