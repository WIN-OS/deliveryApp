import { Component, Input } from '@angular/core';
import { FormArray, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';

export interface InputConfig {
  label: string,
  groupName: string,
  type: 'text' | 'email' | 'tel',
  validators?: ('required' | 'email' | {pattern: string})[],
  maxLength?: number,
  invalidMessage?: string,
  placeholder?: string
}

@Component({
  selector: 'sat-input-group',
  templateUrl: './input-group.component.html',
  styleUrls: ['./input-group.component.scss']
})
export class InputGroupComponent {
  @Input() formGroup!: FormGroup;
  @Input() config!: InputConfig;
  showAlert: any = {};

  get inputs() {
    return this.formGroup.get(this.config.groupName) as FormArray;
  }

  onRemoveInput(index: number) {
    this.inputs.removeAt(index);
  }

  get showAdd() {
    const control = this.inputs.at(this.inputs.length - 1) as FormControl;

    return control.dirty && control.valid && control.value;
  }

  onAddInput() {
    let validators: ValidatorFn[] = [];

    if (this.config.validators){
      for (const v of this.config.validators)
      {
        if (typeof v === 'string')
        {
          if (v === 'email') {
            validators.push(Validators.email);
          } else if (v === 'required') {
            validators.push(Validators.required)
          }
        } else if (typeof v === 'object'){
          if (v.hasOwnProperty('pattern')){
            validators.push(Validators.pattern((v as {pattern : string}).pattern))
          }
        }
      }

    }

    this.inputs.push(new FormControl('', validators));
  }

  onCheckValidity(i: number) {
    const input = this.inputs.at(i);
    this.showAlert[i] = input.dirty && input.invalid;
  }

  onValueChange(i: number){
    if (this.showAlert[i]) {
      this.showAlert[i] = false;
    }   

    if (this.config.type === 'tel') {
      const phoneString = (this.inputs.at(i).value ?? '').replace(/[\.]/g, '');

      let phoneNumberFormatted = phoneString.substring(0, 3);
      if (phoneString.substring(3, 6))
      {
        phoneNumberFormatted = `${phoneNumberFormatted}.${phoneString.substring(3, 6)}`;
  
        if (phoneString.substring(6))
        {
          phoneNumberFormatted = `${phoneNumberFormatted}.${phoneString.substring(6)}`;
        }    
      }

      this.inputs.at(i).setValue(phoneNumberFormatted);
    }
  }

  onClearAlert(i: number) {
    delete this.showAlert[i];
  }

}
