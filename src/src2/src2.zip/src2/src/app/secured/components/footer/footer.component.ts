import { Component } from '@angular/core';

@Component({
  selector: 'sat-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent {
 majorBuildNumber = 3;
 minorBuildNumber = 1;
 showBuildNumbers = false;
 
}
