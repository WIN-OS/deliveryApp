/* eslint-disable @typescript-eslint/no-inferrable-types */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { ThemePalette } from '@angular/material/core';
import { Router } from '@angular/router';
import { ChangeUserPasswordApiService } from 'app/api/change-user-password-api.service';
import { UserProfileApiService } from 'app/api/user-profile-api.service';
import { PageAlertService } from 'app/core/page-alert.service';
import { IEditUser } from 'app/shared/model/interfaces';

@Component({
  selector: 'sat-edit-password-form',
  templateUrl: './edit-password-form.component.html',
  styleUrls: ['./edit-password-form.component.scss']
})
export class EditPasswordFormComponent implements OnInit{
  @Input() passwordInfo: any;
  @Input() passwordLabel: string = 'New Password';
  @Input() passwordformGroup!: FormGroup;
  confirmPasswordTouched =false;
  passwordCheckerHideFlag =true;
  title = 'Change Password';
  passwordStrength = 0;
  hideShowLabel = 'Show';
  clickedEditUser :any;
 passedAccountNumber = '';
 passedEmailAddress = '';

  constructor(private formBuilder: FormBuilder,
    private pageAlertsService: PageAlertService,
    private changeUserPasswordApi: ChangeUserPasswordApiService,
    private router: Router,
    private userProfileApiService: UserProfileApiService
  ){

  this.passwordformGroup = this.formBuilder.group({
    password: new FormControl('', [Validators.required]),
    confirmPassword: new FormControl('', [Validators.required])
    });
  
  this.passwordformGroup.setValidators(this.passwordMatchValidator());
  }

  ngOnInit(): void {
    let account :any;
    let user :any;
    const newEditUserobj = this.userProfileApiService.onNewEditUserResults().subscribe({
      next: ((response: IEditUser) => 
        {
          this.clickedEditUser = response;
          this.passedAccountNumber = this.clickedEditUser.account;
          this.passedEmailAddress = this.clickedEditUser.user;
          console.log('response from userProfileApiService.onNewEditUserResults (Parent) : ',JSON.stringify(response) );
        }
      ),
      error: (error: any) => console.log('error from userProfileApiService.onNewEditUserResults : ',JSON.stringify(error))
    });
    
  }
  
  togglePasswordVisibility():boolean{
    return true;
  }

  updatePassword(): void {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
    if(this.passwordformGroup.valid){
    //  const createAccountPayload = this.buildCreateAccountPayload();
    const confirmedPassword :string = this.passwordformGroup.controls['confirmPassword']?.value;
      this.changeUserPasswordApi.updatePassword(this.passedAccountNumber, this.passedEmailAddress, confirmedPassword)
      .subscribe({
        next: (response) => this.savePasswordSuccess(response),
        error: () => this.savePasswordFailed() 
      });
    }
  else{
    console.log('Form is invalid');
    this.checkFormValidity();
  }
}

checkFormValidity(): void {
  Object.keys(this.passwordformGroup.controls).forEach(key => {
    const control = this.passwordformGroup.get(key);
    if (control && control.invalid) {
      console.log(`${key} is invalid. Errors:`, control.errors);
    }
  });
}


  savePasswordSuccess(response:any):void {
console.log('Success password uypdatd');
}

savePasswordFailed():void {
     console.log('Failed password uypdatd');
                   // show an error message
                   //this.pageAlertsService.showPageAlertErrorMessage(response, 'savePasswordError');

                   // clear the waiting flag
                   //this.saveInProgress = false;
   } 

  onStrengthChanged(strength: number):void{
    this.passwordStrength = strength;
    }
  
     passwordColor(): ThemePalette {
      if (this.passwordStrength > 80) {
        return 'primary'; // strong
      } else if (this.passwordStrength > 50) {
        return 'accent'; // medium
      } else {
        return 'warn'; // weak
      }
    }
    
    showPasswordToggle():void{
      this.passwordCheckerHideFlag = !this.passwordCheckerHideFlag;
      if(this.passwordCheckerHideFlag){
        this.hideShowLabel = 'Show';
      }
      else{
        this.hideShowLabel = 'Hide';
      }
    }
    
  //Validator functions
  passwordMatchValidator(): ValidatorFn {
    return (control: AbstractControl): ValidationErrors | null => {
      const password = this.passwordformGroup.controls['password']?.value;
      const confirmPassword =  this.passwordformGroup.controls['confirmPassword']?.value;
      // If both fields are filled and the values do not match, return an error
      if (password && confirmPassword && (password !== confirmPassword)) {
        return { 'passwordMismatch': true };
      }
      // If the confirmPassword field is empty, return an error
      if (confirmPassword === null || confirmPassword === '') {
        return { 'confirmPasswordEmpty': true };
      }
      return null;  // If there's no error, return null
    };
  }


      
}
