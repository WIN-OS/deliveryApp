import { Component, OnInit } from '@angular/core';

import { ManualsApiService } from 'app/api/manuals-api.service';
import { PopulationDTO, Population, ManualDTO, Manual } from 'app/shared/model/manuals.model';


@Component({
  selector: 'sat-edit-manuals',
  templateUrl: './edit-manuals.component.html',
  styleUrls: ['./edit-manuals.component.scss']
})
export class EditManualsComponent implements OnInit {
  populations: Population[] = [];
  manuals: Manual[] = [];
  selectedPopulation: Population | null = null;
  isLoadingPopulations = false;
  isLoadingManuals = false;
  isUploading = false;
  errorMessage = '';

  constructor(private manualsApi: ManualsApiService) { }

  ngOnInit(): void {
    this.isLoadingPopulations = true;

    this.manualsApi.getPopulations().subscribe({
      next: (response: PopulationDTO)=> {
        this.populations = response.populationList.sort((a: Population, b: Population) =>
          a.populationName < b.populationName ? -1 : (a.populationName === b.populationName ? 0 : 1));

        if (this.populations.length > 0) {
          this.selectedPopulation = this.populations[0];
          this.loadManuals();
        }
      },
      error: (error: string) => { 
        this.errorMessage = error;
      },
      complete: () =>{
        this.isLoadingPopulations =false;
      }
    });
  }

  OnChangePopulation() {
    this.loadManuals()
  }

  onAddManual() {
    this.manuals.push({hasFile: false});
  }

  onDeleteManual(index: number) {
    this.manuals.splice(index, 1);
  }

  onUploadFiles() {
    this.isUploading = true;
    
    const files: File[] = [];
    this.manuals.forEach(m => {
      if (m.file) {
        files.push(m.file);
      }
    });
    
    this.manualsApi.uploadManuals(this.selectedPopulation!.populationId, files).subscribe({
      next: () => {
        this.loadManuals();
      },
      error: (error: string) => { 
        this.errorMessage = error;
      },
      complete: () =>{
        this.isUploading =false;
      }
    })
  }

  get canUpload() {
    console.log(this.manuals);
    const manualsToUpload = this.manuals.filter(m => typeof(m.manualId) === 'undefined');
    if (manualsToUpload.length > 0 && !manualsToUpload.find(m => !m.hasFile)){
      return true;
    }

    return false;
  }

  private loadManuals() {
    if (this.selectedPopulation) {
      this.isLoadingManuals = true;
      this.manualsApi.getManual(this.selectedPopulation.populationId).subscribe({
        next: (response: ManualDTO)=> {
          this.manuals = response.retailManuals;
          this.manuals.forEach((m) => m.hasFile = true);
        },
        error: (error: string) => { 
          this.errorMessage = error;
        },
        complete: () =>{
          this.isLoadingManuals = false;
        }
      });
    }
  }

}
