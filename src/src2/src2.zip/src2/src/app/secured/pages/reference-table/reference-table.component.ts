import { Component, OnInit } from '@angular/core';
import { HttpResponse } from '@angular/common/http';

import { ReferenceTableApiService } from 'app/api/reference-table-api.service';
import { ReferenceTable, RetailReferenceData } from 'app/shared/model/reference-table.model';

@Component({
  selector: 'sat-reference-table',
  templateUrl: './reference-table.component.html',
  styleUrls: ['./reference-table.component.scss']
})
export class ReferenceTableComponent implements OnInit {
  referenceData: RetailReferenceData[] = [];
  isLoading = false;
  errorMessage = null;

  constructor(private rtApi: ReferenceTableApiService) {}

  ngOnInit(): void {
    this.isLoading = true;

    this.rtApi.getReferenceData().subscribe({
      next: (response: ReferenceTable) => {
        this.referenceData = response.retailReferenceData.sort((a: RetailReferenceData, b: RetailReferenceData) =>
          a.population < b.population ? -1 : (a. population === b.population ? 0 : 1));
        this.isLoading =false;
      },
      error: (error) => { 
        this.errorMessage = error;
      }
    });
  }

  onDownloadManual(manual: any): void{
    manual.isDownloading = true;

    this.rtApi.downloadManual(manual.manualLink.href).subscribe({
      next: response => {
        this.downloadFile(response, manual.manualName);
        manual.isDownloading = false;
      },
      error: (error) => {
        this.errorMessage = error;
      }
    });
  }

  onClearErrorMessage(){
    this.errorMessage = null;
  }

  private downloadFile(response: HttpResponse<any>, fileName: string){
    const contentType = response.headers.get('Content-Type');
    const blob = new Blob([response.body], {type: contentType ?? 'application/pdf'})
    const url = window.URL.createObjectURL(blob);

    const linkElement = document.createElement('a');
    linkElement.style.display = 'none';
    linkElement.href = url;
    linkElement.download = fileName;

    linkElement.click();

    linkElement.remove();
    window.URL.revokeObjectURL(url);
  }
}
