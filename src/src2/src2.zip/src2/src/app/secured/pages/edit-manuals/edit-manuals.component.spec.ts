import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditManualsComponent } from './edit-manuals.component';

describe('EditManualsComponent', () => {
  let component: EditManualsComponent;
  let fixture: ComponentFixture<EditManualsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EditManualsComponent]
    });
    fixture = TestBed.createComponent(EditManualsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
