import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReferenceTableComponent } from './reference-table.component';

describe('ReferenceTableComponent', () => {
  let component: ReferenceTableComponent;
  let fixture: ComponentFixture<ReferenceTableComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReferenceTableComponent]
    });
    fixture = TestBed.createComponent(ReferenceTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
