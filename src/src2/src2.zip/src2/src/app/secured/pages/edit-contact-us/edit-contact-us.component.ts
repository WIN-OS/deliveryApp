/* eslint-disable @typescript-eslint/no-explicit-any */

import { Component, inject, OnInit } from '@angular/core';
import { PopulationApiService } from 'app/api/population-api.service';
import { ApiErrorMessageService } from 'app/core/api-error-message.service';
import { PageAlertService } from 'app/core/page-alert.service';
import { IPopulationList } from 'app/shared/model/interfaces';
import { BehaviorSubject, Observable, of } from 'rxjs';


@Component({
  selector: 'sat-edit-contact-us',
  templateUrl: './edit-contact-us.component.html',
  styleUrls: ['./edit-contact-us.component.scss']
})
export class EditContactUsComponent implements OnInit {

  userData: any = {};
  populationsLoaded = false;
  populations: IPopulationList[] = [];

  selectedPopulationDetailsSub = new BehaviorSubject<IPopulationList>({
    populationId: 1008,
    populationName: '',
    programIdBenefitDescList:   [
      {
      programId : '',
    benefitDescription: '',
  }]
});

populationApiService =inject(PopulationApiService);

  //default value
  selectedPopulationDetails:IPopulationList = {
    populationId: 1008,
    populationName: '',
    programIdBenefitDescList:   [
      {
      programId : '',
    benefitDescription: '',
  }]
}; 
  errorMessage: any;
  successMessage: any;

  constructor(
    private populationsApi: PopulationApiService,
    private apiErrorMessageService: ApiErrorMessageService,
    private alertService : PageAlertService
  ) {}

  ngOnInit(): void {
    // load the list of populations to display in the dropdown
    this.populationsApi.getAllPopulations().subscribe({
      next : response => this.getAllPopulationsSuccess(response),
      error: error => this.getAllPopulationsFail(error)
    }
    );
  }

  private getAllPopulationsSuccess(response: any): void {
    console.log('getAllPopulationsSuccess ', JSON.stringify(response));
    // set the list of populations
    this.populations = response.populationList;

    // set the loaded flag to true to show the rest of the page and remove the loader
    this.populationsLoaded = true;

    // select the first population
    this.userData.selectedPopulation = this.populations[0];
    this.updateFormValues(this.userData.selectedPopulation);
    
  }

  private getAllPopulationsFail(error: any): void {
    // show an error message
    this.apiErrorMessageService.showPageAlertErrorMessage(error, 'getAllPopulationsApiFail');
  }

  onPopulationChange(): void {
    this.updateFormValues(this.userData.selectedPopulation);
  }

  private updateFormValues(selectedPopulation: any): void {
    if(this.populations){
      this.selectedPopulationDetails = this.populations.find(pop => pop.populationId === selectedPopulation.populationId) || this.selectedPopulationDetails;
      console.log('selected: ',JSON.stringify(this.selectedPopulationDetails) )
      //this.selectedPopulationDetailsSub = of(this.selectedPopulationDetails) ;
      
      
      if (this.selectedPopulationDetails) {
        this.userData = { ...this.userData, ...this.selectedPopulationDetails };
        this.selectedPopulationDetailsSub.next(this.selectedPopulationDetails);
        //for edit phone line component to receive a subscription of the selectedPopuplation
        this.populationApiService.setSelectedPopulation(this.selectedPopulationDetails);
      }
    }
  }


  get selectedPopulation$(): Observable<IPopulationList> {
    return this.selectedPopulationDetailsSub.asObservable();
  }

  getErrorMessage(id: string): void {
    const alert = this.alertService.getAlertById('updateContactUsFail');
    if (alert) {
      this.errorMessage = alert.message;
    }
  }
  getSuccessMessage(id: string): void {
    const alert = this.alertService.getAlertById('updateContactUsSuccess');
    if (alert) {
      this.successMessage = alert.message;
    }
  }

  
  

}
