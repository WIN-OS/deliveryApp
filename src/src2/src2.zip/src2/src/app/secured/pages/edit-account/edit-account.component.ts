/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserProfileApiService } from 'app/api/user-profile-api.service';
import { IEditUser } from 'app/shared/model/interfaces';
import { AuthorizedUsersService } from 'app/shared/services/authorized-users.service';
import { RouteHelperService } from 'app/shared/services/route-helper.service';

@Component({
  selector: 'sat-edit-account',
  templateUrl: './edit-account.component.html',
  styleUrls: ['./edit-account.component.scss']
})
export class EditAccountComponent implements OnInit {
    showChildViews = false;
    account: any;
    user: any;
    childView = 'profile';
    accountNumber = '';
    userEmail = '';
    clickedEditUser : IEditUser | undefined ; 

    constructor(
        private route: ActivatedRoute,
        private authorizedUsersService: AuthorizedUsersService,
        private routeHelperService: RouteHelperService,
        private userProfileApiService: UserProfileApiService
    ) {
        //accountUserEmail accountNumber
        let account, user;
        // Check if an account was passed in via route parameters
        this.route.queryParams.subscribe(params => {
          if (params['account'] && params['user']) {
            //account = params['account'];
           // user = params['user'];
           this.accountNumber = params['account'];
           this.userEmail = params['user'];
          // this.accountNumber = account.accountNumber;
           //  this.userEmail = user.accountUserEmail;
              console.log('account: ', this.accountNumber, 'user: ',this.userEmail);
              if (this.accountNumber && this.userEmail) {
                  this.userProfileApiService.getUserProfile(this.accountNumber, this.userEmail)
                  .subscribe({
                    next: ((response: any) => 
                    {
                      console.log('response from getUserProfile (Parent) : ',JSON.stringify(response));
                     // this.loadUserProfileSuccess(response)
                    }
                    ),
                   // error: (response: any) => this.loadUserProfileFail(response)
              });
              } else {
                  // Handle the case where account or user is not provided
                  //this.alerts.loadUserProfileFail = this.apiErrorMessageService.showPageAlertErrorMessage(response, 'loadUserProfileFail');
              }
          }
        });
      // Check if an account was passed in via route parameters
              /*
              this.route.queryParams.subscribe(params => {
                if (params['account'] && params['user']) {

                  account = params['account'];
                   user = params['user'];
                  this.accountNumber = account.accountNumber;
                    this.userEmail = user.accountUserEmail;
                    console.log('account: ', this.accountNumber, 'user: ',this.userEmail);
                    if (this.accountNumber && this.userEmail) {
                        this.userProfileApiService.getUserProfile(this.accountNumber, this.userEmail)
                        .subscribe({
                          next: ((response: any) => 
                          {
                            console.log('response from getUserProfile: ',JSON.stringify(response));
                            this.loadUserProfileSuccess(response)
                          }
                          ),
                          error: (response: any) => this.loadUserProfileFail(response)
                    });
                    } else {
                        // Handle the case where account or user is not provided
                        //this.alerts.loadUserProfileFail = this.apiErrorMessageService.showPageAlertErrorMessage(response, 'loadUserProfileFail');
                    }
                }
              });
            */
    }

    ngOnInit(): void {
      //const obj = this.userProfileApiService.onNewEditUserResults();
      let account :any;
      let user :any;
      const newEditUserobj = this.userProfileApiService.onNewEditUserResults().subscribe({
        next: ((response: IEditUser) => 
          {
            this.clickedEditUser = response;
            account = this.clickedEditUser.account;
            user = this.clickedEditUser.user;
            console.log('response from userProfileApiService.onNewEditUserResults (Parent) : ',JSON.stringify(response) );
          }
        ),
        error: (error: any) => console.log('error from userProfileApiService.onNewEditUserResults : ',JSON.stringify(error))
      });
      
      if (account && user) {
          const userIndex = account.users.indexOf(user);
           // copy the account onto the scope - we need to get a copy otherwise
           // this controller will initialize with every child state change
          this.account = { ...account };
           // get the user from the index
          this.user = this.account.users[userIndex];
          // re-format the authorized users to set the isCurrentUser flag accordingly (based on the selected user)
          // and also re-sort the users
          this.authorizedUsersService.formatAuthorizedUsers(this.account.users, this.user.accountUserEmail);
          this.showChildViews = true;
      } else {
          this.routeHelperService.goToAccountSearch();
      }
    }


    loadChildView(view:string):void{
      this.childView = view;
    }
  }

