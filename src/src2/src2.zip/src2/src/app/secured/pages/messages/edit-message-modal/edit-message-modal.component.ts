/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input, Output, EventEmitter, inject, TemplateRef } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'sat-edit-message-modal',
  templateUrl: './edit-message-modal.component.html',
  styleUrls: ['./edit-message-modal.component.scss']
})

export class EditMessageModalComponent {

  @Input() message: any;
  @Input() populations: any;

  @Output() saveMessageSuccess = new EventEmitter<void>();
  @Output() cancel = new EventEmitter<void>();
  private modalService = inject(NgbModal);
  
  constructor(public activeModal: NgbActiveModal) { }

  closeModal():void {
    this.saveMessageSuccess.emit();
    this.activeModal.close();
  }

  dismissModal():void {
    this.cancel.emit();
    this.activeModal.dismiss('cancel');
  }

  openXl(content: TemplateRef<any>):void {
		this.modalService.open(content, { size: 'xl' });
	}

}
