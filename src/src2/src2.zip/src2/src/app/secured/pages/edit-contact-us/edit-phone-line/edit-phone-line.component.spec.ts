import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPhoneLineComponent } from './edit-phone-line.component';

describe('SatEditPhoneLineComponent', () => {
  let component: EditPhoneLineComponent;
  let fixture: ComponentFixture<EditPhoneLineComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EditPhoneLineComponent]
    });
    fixture = TestBed.createComponent(EditPhoneLineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
