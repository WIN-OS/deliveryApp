/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CreateAccountApiService } from 'app/api/create-api.service';
import { UserProfileApiService } from 'app/api/user-profile-api.service';
import { ApiErrorMessageService } from 'app/core/api-error-message.service';
import { PageAlertService } from 'app/core/page-alert.service';
import { ICreateAccountFormResponse, IEditAccountFormPayload } from 'app/shared/model/interfaces';
import { BehaviorSubject, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';


@Component({
  selector: 'sat-edit-profile-form',
  templateUrl: './edit-profile-form.component.html',
  styleUrls: ['./edit-profile-form.component.scss']
})

export class EditProfileFormComponent implements OnInit {

  npiTouched = false;
  firstNameTouched = false;
  lastNameTouched = false;
  emailTouched = false;
  taxIdTouched = false;
  phoneNumberTouched = false;
  titleTouched = false;
  confirmPasswordTouched =false;
  passwordCheckerHideFlag =true;
  isEditAccountFailed = new BehaviorSubject<boolean>(false);
  

  @Input() profileInfo: any = {};
 @Input() saveButtonText = 'Save Profile';
  @Input() editEmailDisabled: boolean | undefined;
  @Input() includePasswordInputs: boolean | undefined;
  @Input() clearPasswordFieldsOnSubmit = false;
  @Input() includeClaimFormCheckbox: boolean | undefined;
  @Output() submitEvent = new EventEmitter<any>();
  editProfileForm : FormGroup;

  saveAccountInProgress = false;
  private SAVE_ACCOUNT_ERROR_KEY = 'editProfileFormSaveAccountError';
  private saveAccountErrorAlert: any;

  constructor(
    private pageAlertsService: PageAlertService,
    private apiErrorMessageService: ApiErrorMessageService,
    private createAccountApi: CreateAccountApiService,
    private router: Router,
    private formBuilder: FormBuilder,
    private userProfileApiService: UserProfileApiService
  ) {

    this.editProfileForm = this.formBuilder.group({
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', [Validators.required]),
      title: new FormControl('', []),
      taxId: new FormControl('', [Validators.required, Validators.pattern('^\\d{2}-\\d{7}$')]),
      npi: new FormControl('', [Validators.required, Validators.pattern('^\\d{10}$')]),
      phoneNumber: new FormControl('', [Validators.required, Validators.pattern('^\\d{3}\\.\\d{3}\\.\\d{4}$')]),
      email: new FormControl('', [Validators.required, Validators.email]),
      });

  }


  ngOnInit(): void {
    if(this.profileInfo){
      this.editProfileForm.controls['firstName']?.setValue(this.profileInfo['firstName']);
      this.editProfileForm.controls['lastName']?.setValue(this.profileInfo['lastName']);
      this.editProfileForm.controls['title']?.setValue(this.profileInfo['title']);
      this.editProfileForm.controls['email']?.setValue(this.profileInfo['emailAddress']);

      // Format and set the values for taxId, NPI, and phoneNumber
      const formattedTaxId = this.formatTaxId(this.profileInfo['taxID']);
      const formattedNPI = this.formatNPI(this.profileInfo['NPI']);
      const formattedPhoneNumber = this.formatPhoneNumber(this.profileInfo['phoneNumber']);

      this.editProfileForm.controls['taxId'].setValue(formattedTaxId);
      this.editProfileForm.controls['npi'].setValue(formattedNPI);
      this.editProfileForm.controls['phoneNumber'].setValue(formattedPhoneNumber);
    }
  }


  private formatTaxId(value: string): string {
    // Format as XX-XXXXXXX
    return value.replace(/(\d{2})(\d{7})/, '$1-$2');
  }

  private formatNPI(value: string): string {
    // NPI is a 10-digit number, no special formatting needed
    return value;
  }

  private formatPhoneNumber(value: string): string {
    // Format as XXX.XXX.XXXX
    return value.replace(/(\d{3})(\d{3})(\d{4})/, '$1.$2.$3');
  }

  isFormEdited():boolean {
    return !(this.firstNameTouched  || this.lastNameTouched  || this.npiTouched || this.taxIdTouched  || this.emailTouched  || this.phoneNumberTouched || this.titleTouched )

  }
  
  editnSaveAccount(): void {
    if(this.editProfileForm.valid){
      //this.closeAllAlerts();
      const updateUserProfilePayload = this.buildUpdateUserProfilePayload();
      console.log('edit-profile-form: ',JSON.stringify(updateUserProfilePayload));
      this.submitEvent.emit(updateUserProfilePayload);
      /*
      return this.userProfileApiService.updateUserProfile(
        this.profileInfo.accountNumber,
        this.profileInfo.emailAddress,
        updateUserProfilePayload
        );
        */
      }else{
      console.log('Form is invalid');
      this.checkFormValidity();
    }
  }

  checkFormValidity(): void {
    Object.keys(this.editProfileForm.controls).forEach(key => {
      const control = this.editProfileForm.get(key);
      if (control && control.invalid) {
        console.log(`${key} is invalid. Errors:`, control.errors);
      }
    });
  }
  

  private buildUpdateUserProfilePayload() : any{
    const taxIdWithSplChar = this.editProfileForm.controls['taxId']?.value;
    const phoneNumberWithSplChar = this.editProfileForm.controls['phoneNumber']?.value;
    let taxIdWithOutSplChar = '';
    let phoneNumberWithOutSplChar = '';
    //remove spl chars
    if (taxIdWithSplChar) {
      taxIdWithOutSplChar = taxIdWithSplChar.replace(/-/g, '');
    }
    
    if (phoneNumberWithSplChar) {
      phoneNumberWithOutSplChar = phoneNumberWithSplChar.replace(/\./g, '');
    }
    return {
      firstName: this.editProfileForm.controls['firstName']?.value,
      lastName: this.editProfileForm.controls['lastName']?.value,
      emailAddress : this.editProfileForm.controls['email']?.value,
      title: this.editProfileForm.controls['title']?.value,
      taxID: taxIdWithOutSplChar,
      NPI: this.editProfileForm.controls['npi']?.value,
      phoneNumber: phoneNumberWithOutSplChar
    }
  }

   

  private handleSaveAccountError(error: any): void {
    console.error('Error during pre-save account action:', error);
  }
}

 /*
  name: An invalid name has been entered. Please enter First Name;
  value: An invalid character has been entered. Please enter First Name;
  required:Please enter First Name


  name:An invalid name has been entered. Please enter Last Name;
              value: An invalid character has been entered. Please enter Last Name;
              required:Please enter Last Name
  
  email:Please enter a valid Email Address;required:Please enter Email Address


  taxid:Invalid entry - A 9 digit number is required;
              required:Please enter Federal Tax ID"

              "minlength,numeric:Invalid entry - A 10 digit number is required;
              required:Please enter NPI


              phone:Invalid entry - A 10 digit number is required; required:Please enter Phone Number
              */