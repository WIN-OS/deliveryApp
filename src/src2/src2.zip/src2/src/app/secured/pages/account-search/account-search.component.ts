/* eslint-disable @typescript-eslint/no-explicit-any */
/** Derived from Legacy App - provider-portal-2020-admin/src/components/account-search-results/account-search-result-detailed/account-search-result-detailed.directive.js */

import { Component, Input, OnInit, inject } from '@angular/core';

//import { pathProvider } from 'common.path.provider';
//import { apiErrorMessageService } from 'common.api-error-message.service';
//import { paginationService } from 'common.pagination.service';
//import { routeHelperService } from 'route-helper.service';
//import { accountSettingsApi } from 'account-settings.api';
//import { accountActivityHistoryApi } from 'account-activity-history.api';
//import { Observable, of, throwError } from 'rxjs';
//import { catchError, finalize, map, tap } from 'rxjs/operators';
//import { AccountActivityHistoryApiService } from 'src/app/api/account-activity-history-api.service';
//import { AccountSettingsApiService } from 'src/app/api/account-settings-api.service';
//import { ApiErrorMessageService } from 'src/app/shared/services/api-error-message.service';
//import { PaginationService } from 'src/app/shared/services/pagination.service';
//import { RouteHelperService } from 'src/app/shared/services/route-helper.service';


@Component({
  selector: 'sat-account-search',
  templateUrl: './account-search.component.html',
  styleUrls: ['./account-search.component.scss']
})
export class AccountSearchComponent  {
/*
  @Input() item: any;
  @Input() baseId: string | undefined;
  paginationService = inject(PaginationService);
  routeHelperService = inject(RouteHelperService);
  apiErrorMessageService = inject(ApiErrorMessageService);
  accountSettingsApi = inject(AccountSettingsApiService);
  accountActivityHistoryApi = inject(AccountActivityHistoryApiService);

  // reference to any API alerts
  private _alerts : any;

  // toggle to true to open the Account Activity History section
  accountActivityHistoryOpen = false;

  // tracks whether or not we have loaded the history
  accountActivityHistoryLoaded = false;

   // set these to true to indicate data is loading and to lock down the fields     
  loadingFlags = {
    updateStatus: false,
    updateClaimFormAccess: false,
    updateLegacy2020Access: false,
    accountActivityHistory: false
  };

  // set the isAccountActive flag - this flag drives whether or not to show the Edit User buttons
  // we need a separate flag from the status property so we can only update it after successful API calls
  isAccountActive = false;

  // initialize the account activity history results object
  accountActivityHistoryResults : any;

  // set the account activity history onto the pagination object (needs to be nested on the pagination object
  // for angular bindings to work properly back and forth)
  pagination = {
    accountActivityHistory : {
      itemSort : {
        sortProperty : '',
        reverse : false
      }
    }
  };
  
  
  ngOnInit():void {
    // initialize the account activity history pagination state
    // get the default state and then set pagination to sort by actionDate reversed
    if(this.paginationService.getDefaultPaginationState() !== undefined){
      // TODO -- create the getDefaultPaginationState() in paginationService
      //this.pagination = this.paginationService.getDefaultPaginationState()
      this.pagination.accountActivityHistory.itemSort.sortProperty = 'DATE';
      this.pagination.accountActivityHistory.itemSort.reverse = true;
    }
    this.setIsAccountActive();
  }

  getUserFullName(user:any): string {
    return [user.accountUserFirstName, user.accountUserLastName].join('').trim();
  }

  statusChanged():void {
    // check the new value to see if we are activating or deactivating
    const activate = this.item.ui.statusString === 'Active';
    // update the status value accordingly
    this.updateAccountStatusValue(activate);

    // call the updateStatus API to save the update
    this.updateAccountSetting('updateStatus', activate)
      .pipe(
        tap(() => {
          // only update the isAccountActive flag on success
          this.setIsAccountActive();
        }),
        catchError(error => {
        const originalActiveStatus = !activate;
        this.item.ui.statusString = originalActiveStatus ? 'Active' : 'Inactive';
        this.updateAccountStatusValue(originalActiveStatus);
        return throwError(error);
      }));
  }

  claimFormStatusChanged(): void {
    // check the new value to see if we are activating or deactivating
    const activate = this.item.claimFormViewStatus === 'Y';
    // call the updateClaimFormAccess API to save the update
    this.updateAccountSetting('updateClaimFormAccess', activate)
      .pipe(catchError(error => {
         // revert the changes made on the UI
        const originalActiveStatus = !activate;
        this.item.claimFormViewStatus = originalActiveStatus ? 'Y' : 'N';
        return throwError(error);
      }));
  }

  legacy2020StatusChanged():void {
    // check the new value to see if we are activating or deactivating
    const activate = this.item.legacy2020Access === 'Allow';
    // call the updateLegacy2020Access API to save the update
    this.updateAccountSetting('updateLegacy2020Access', activate)
      .pipe(catchError(error => {
    // revert the changes made on the UI
        const originalActiveStatus = !activate;
        this.item.legacy2020Access = originalActiveStatus ? 'Allow' : 'Block';
        return throwError(error);
      }));
  }

  editUser(user: any):void {
    this.routeHelperService.goToEditAccount(user, this.item);
  }

  toggleAccountActivityHistory():void {
    // toggle the open status of the account activity history section
    this.accountActivityHistoryOpen = !this.accountActivityHistoryOpen;

    // check if we are expanding the history section for the first time
    if (this.accountActivityHistoryOpen && !this.accountActivityHistoryLoaded) {
       // set the loading flag to true
      this.loadingFlags.accountActivityHistory = true;

      // load the first page of activity
      this.loadAccountActivityHistory(this.pagination.accountActivityHistory)
      .subscribe((itemsData: {}) => {
        // set the items data on the scope
        this.accountActivityHistoryResults = itemsData;
        // clear the loading flag and set the loaded state to true
        this.loadingFlags.accountActivityHistory = false;
        this.accountActivityHistoryLoaded = true;
      });
    }
  }

  showHistoryTable():boolean {
    return this.accountActivityHistoryLoaded && this.hasHistoryItems();
  }

  showNoHistoryMessage():boolean {
    return this.accountActivityHistoryLoaded && !this.hasHistoryItems();
  }

  // invokes one of the account settings APIs to activate/deactivate the setting
  // updateAction: the function to invoke on account-settings.api, as well as the flag name in $scope.loadingFlags
  // activate:     set to true to activate the setting for this account, false to deactivate it
  updateAccountSetting(updateAction: string, activate:boolean):Observable<any>{

    // close any API error messages
    this.closeAllAlerts();

    let response :any;

   if (updateAction === ('updateStatus' || 'updateClaimFormAccess' || 'updateLegacy2020Access')){
        // set the appropriate loading flag to true
        this.loadingFlags[updateAction] = true;
        // invoke the account-settings.api action to send the appropriate API request
     
          this.accountSettingsApi[updateAction](this.item.accountNumber, activate)
          .pipe(
            // set the loading flag back to false regardless of success or failure
            catchError(this.updateAccountSettingFail.bind(this)),
            finalize(() => this.loadingFlags[updateAction] = false)
          )
          .subscribe(returnedResponse => {
            response = returnedResponse;
          });
        }
        return of(response);
  }

  updateAccountSettingFail(response: any): Observable<never> {
    // show an error message from the response
    this._alerts.updateAccountSettingApiError = this.apiErrorMessageService.showPageAlertErrorMessage(response, 'updateAccountSettingApiError');
  
    // return a rejected promise to break the promise chain
    return throwError('Something bad happened; please try again later.');
  }
  
  closeAllAlerts():void{
    this.apiErrorMessageService.closePageAlertErrorMessages(this._alerts);
  }
  
  // set the status property on the account to "1" (active) or "2" (inactive)
  updateAccountStatusValue(isActive: boolean):void{
    this.item.status = isActive ? '1' : '2';
  }
  
  // loads the specified page of account activity history records
  loadAccountActivityHistory(paginationState: { itemSort: { sortProperty: string; reverse: boolean; }; }):any {
    return this.accountActivityHistoryApi.getActivity(this.item.accountNumber, paginationState)
    .pipe(
      map(this.loadAccountActivityHistorySuccess),
      catchError(this.loadAccountActivityHistoryFail)
      );
    }
    
    loadAccountActivityHistorySuccess(response: { data: { retailMessages: any; totalElements: any; }; }):any {
      return {
        items: response.data.retailMessages,
        totalItems: response.data.totalElements
      };
    }
    
    loadAccountActivityHistoryFail(response: any):Observable<never> {
      // show an error message from the response
      this._alerts.loadAccountActivityHistoryApiError = this.apiErrorMessageService.showPageAlertErrorMessage(response, 'loadAccountActivityHistoryApiError');
    
      // return a rejected promise to break the promise chain
      return throwError('Something bad happened; please try again later.');
    }
    
    hasHistoryItems():boolean {
      return this.accountActivityHistoryResults.items && this.accountActivityHistoryResults.items.length > 0;
    }
    
    setIsAccountActive():void {
      // account is active is status = 1
      this.isAccountActive = this.item.status === '1';
    }
    
    // TODO: Implement the following methods
    // updateAccountStatusValue
    // updateAccountSetting
    */
  }

