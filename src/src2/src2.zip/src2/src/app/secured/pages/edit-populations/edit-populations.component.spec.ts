import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPopulationsComponent } from './edit-populations.component';

describe('EditPopulationsComponent', () => {
  let component: EditPopulationsComponent;
  let fixture: ComponentFixture<EditPopulationsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EditPopulationsComponent]
    });
    fixture = TestBed.createComponent(EditPopulationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
