/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { ChangeDetectorRef, Component, OnChanges, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, NgForm, Validators } from '@angular/forms';
import { PopulationApiService } from 'app/api/population-api.service';
import { ArrayService } from 'app/core/array-service.service';
import { FormService } from 'app/core/form-service.service';
import { PageAlertService } from 'app/core/page-alert.service';
import { ApiErrorMessageService } from 'app/shared/services/api-error-message.service';
import { catchError, finalize, Observable, of, tap } from 'rxjs';



@Component({
  selector: 'sat-edit-populations',
  templateUrl: './edit-populations.component.html',
  styleUrls: ['./edit-populations.component.scss']
})

export class EditPopulationsComponent implements OnInit, OnChanges {
  @ViewChild('editPopulationsForm') editPopulationsForm: NgForm | undefined;
  userData: any = {};
  updateInProgress = false;
  populationsLoaded = false;
  populations: any[] = [];
  private _originalPopulation: any;
  private _savingPopulation: any;
  private _alerts = {
    updateSuccess: null,
    updateFail: null,
    deleteSuccess: null,
    deleteFail: null,
    confirmOtherPopulations: null
  };
  updateSuccessMessage :string | undefined;
  confirmOtherPopulationsMessage : string | undefined;
  deleteSuccessMessage: string | undefined;
  deleteFailMessage: string | undefined;
  //editPopulationsForm: FormGroup<any> | undefined;
  constructor(
    private fb: FormBuilder,
    private populationsApi: PopulationApiService,
    private pageAlertsService: PageAlertService,
    private apiErrorMessageService: ApiErrorMessageService,
    private formService: FormService,
    private arrayService: ArrayService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit():void {
   // this.editPopulationsForm = this.fb.group({
    //  populationName: ['', Validators.required],
    //});

     // refresh/load the populations list
     this.refreshPopulations().subscribe(() => {
      // select the first population
      this.selectFirstPopulation();

      // set the loaded flag to true to show the edit form
      this.populationsLoaded = true;
    });
  }

  ngOnChanges():void {
    this.cdr.detectChanges();
  }

  // watch for changes to the selectedPopulation (the population selected in the dropdown)
  onSelectedPopulationChange(selectedPopulation: any):void {
    if (selectedPopulation) {
      // store a reference to the selected population
      this._originalPopulation = selectedPopulation;

      // set a copy of the population on the scope - editing is done on the copied population
      // so that original does not get changed until saved
      this.userData.populationEdit = { ...selectedPopulation };

      // population name is editable unless "All" is selected
      this.userData.populationNameEditEnabled = selectedPopulation.populationName.toUpperCase() !== 'ALL';

      // if user selected "Add New Population", set the population name to an empty string
      if (this.userData.populationEdit.newItem) {
        this.userData.populationEdit.populationName = '';
      }

      // if there is no "benefits" array, create a new one
      if (!this.userData.populationEdit.programIdBenefitDescList) {
        this.userData.populationEdit.programIdBenefitDescList = [];
      }

      // if the benefits list is empty, add a new empty one (there should always be at least one row)
      if (this.userData.populationEdit.programIdBenefitDescList.length === 0) {
        this.addBenefit();
      }

      // set the originalProgramId value on each benefit
      this.updateOriginalProgramIds();

      // reset the form state - resets validation styling
      this.resetFormState();
    } else {
      // no population selected, clear references
      this._originalPopulation = null;
      this.userData.populationEdit = null;
      this.userData.populationNameEditEnabled = false;
    }
    // close all alerts when a new population is selected
    // don't do this in the selectedPopulation watch because we don't want to close alerts when population is
    // changed programmatically, just when user changes
    this.closeAllAlerts();
  }

  newPopulationSelected():void {
    // close all alerts when a new population is selected
    // don't do this in the selectedPopulation watch because we don't want to close alerts when population is
    // changed programmatically, just when user changes
    this.closeAllAlerts();
  }

  saveChanges():void {
    // close all alerts
    this.closeAllAlerts();

    if (this.editPopulationsForm && this.editPopulationsForm.form.valid) {
      // store a copy of the population being saved
      this._savingPopulation = { ...this.userData.populationEdit };

      // set the updateInProgress flag to true to update the UI state
      this.updateInProgress = true;

      // call the create population API if this is a new item, otherwise call the update API
      let updateObservable;
      if (this._savingPopulation.newItem) {
        updateObservable = this.populationsApi.createPopulation(this._savingPopulation).pipe(
          tap(() => this.createPopulationSuccess()),
          catchError((error) => this.updatePopulationFail(error))
        );
      } else {
        updateObservable = this.populationsApi.updatePopulation(this._savingPopulation).pipe(
          tap(() => this.updatePopulationSuccess()),
          catchError((error) => this.updatePopulationFail(error))
        );
      }

      // subscribe to the observable
      updateObservable.pipe(
        finalize(() => {
          // reset the form state to remove required validation styling
          this.resetFormState();

          // show a save success alert
         //this._alerts.updateSuccess this.pageAlertsService.addSuccess('Benefit Description/Program ID combinations have successfully been updated', 'updatePopulationApiSuccess');
          this.updateSuccessMessage = 'Benefit Description/Program ID combinations have successfully been updated', 'updatePopulationApiSuccess';

          // show the message to ensure there are no other populations to update
          //this._alerts.confirmOtherPopulations = this.pageAlertsService.addWarning(
          //  '<span>Please ensure there are no <a href="" ui-sref="secure.reference-table">other populations</a> within which to update this Program ID.</span>',
          //  'editPopulations-confirmOtherPopulations', { trustedHTML: true, compileHTML: true }
         // );

          this.confirmOtherPopulationsMessage = '<span>Please ensure there are no <a href="" ui-sref="secure.reference-table">other populations</a> within which to update this Program ID.</span>',
            'editPopulations-confirmOtherPopulations',

          // clear the savingPopulation reference
          this._savingPopulation = null;

          // clear the updateInProgress flag
          this.updateInProgress = false;
        })
      ).subscribe();
    } else {
 if(this.editPopulationsForm){
   Object.keys(this.editPopulationsForm.controls).forEach(key => {
     const control = this.editPopulationsForm?.controls[key];
     if (control && control.invalid) {
       console.log(`${key} is invalid. Errors:`, control.errors);
     }
   });
 }
      }
  }

  // checks if this is the last benefit in the list
  isLastBenefit(benefit: any):boolean {
    const benefits = this.userData.populationEdit.programIdBenefitDescList || [];
    return benefits.indexOf(benefit) === benefits.length - 1;
  }

  // checks if there is only one benefit in the list
  isOnlyBenefit():boolean {
    return this.userData.populationEdit.programIdBenefitDescList.length === 1;
  }

  /*
  addBenefit():void {
    this.userData.populationEdit.programIdBenefitDescList.push({});
  }
  // invoked from the edit-population-benefit directive
  deleteBenefit(benefit: any):void {
    // close all previous alerts
    this.closeAllAlerts();

    // set the isDeleting flag to true on the benefit item
    benefit.isDeleting = true;

    // if this is the only benefit, delete the entire population
    // otherwise just delete the benefit
    if (this.isOnlyBenefit()) {
      this.deleteSelectedPopulation();
    } else {
      this.deleteBenefitItem(benefit);
    }
  }
*/
 showDeleteWarningMessage():void {

 //TODO- Alert service
  //  this._alerts.confirmOtherPopulations = this.pageAlertsService.addWarning(
    //    '<span>Please ensure there are no <a href="" ui-sref="secure.reference-table">other populations</a> to delete this Program ID from.</span>',
    //    'confirmOtherPopulationsMessage', { trustedHTML: true, compileHTML: true }
    //   );
    
    // shows the message to warn users to update other populations if necessary after a delete action
    this.confirmOtherPopulationsMessage = '<span>Please ensure there are no <a href="" ui-sref="secure.reference-table">other populations</a> to delete this Program ID from.</span>';

  }

  // checks if there is a population selected
  hasSelectedPopulation():boolean {
    return this.userData.populationEdit !== null;
  }



  // invokes the API to get all populations
  private refreshPopulations(): Observable<any> {
    return this.populationsApi.getAllPopulations().pipe(
      tap((response) => this.getAllPopulationsSuccess(response)),
      catchError((error) => this.getAllPopulationsFail(error))
    );
  }

  // loops through each benefit on the populationEdit and sets an originalProgramId property on it to the
  // current programId value. This is needed when deleting benefits - the API uses the programId as the unique identifier,
  // so we need to keep track of the original programId for delete purposes in case the user changes the programId
  // but doesn't save and then deletes the benefit
  private updateOriginalProgramIds():void {
    // loop through each benefit on the populationEdit
    for (const benefit of this.userData.populationEdit.programIdBenefitDescList) {
      // set the originalProgramId to the current programId
      benefit.originalProgramId = benefit.programId;
    }
  }

  private getAllPopulationsSuccess(response: any):void {
    console.log('getAllPopulationsSuccess: ',JSON.stringify(response));
    // set the list of populations on the scope
    this.populations = response.populationList;
    this.userData.populationEdit = this.populations[0];
  }

  private getAllPopulationsFail(response: any):any {
    // show an error message and return a rejected promise to break the promise chain
    this.apiErrorMessageService.showPageAlertErrorMessage(response, 'getAllPopulationsApiFail');
    return of(null);
  }

  private createPopulationSuccess():void {
    // creating a population does not return the populationId, which is needed for further edits. So instead
    // we need to refresh the populations list and then select the newly created population by name
    this.refreshPopulations().pipe(
      tap(() => this.selectPopulationByName(this._savingPopulation.populationName))
    ).subscribe();
  }

  private updatePopulationSuccess():void {
    // copy the population name and benefits array to the original population to persist the changes locally
    this._originalPopulation.populationName = this._savingPopulation.populationName;
    this._originalPopulation.programIdBenefitDescList = this._savingPopulation.programIdBenefitDescList;
  
    // update the originalProgramIds to match the saved data
    this.updateOriginalProgramIds();
  }
  
  private updatePopulationFail(response: any):any {
    // show an error message and return a rejected promise to break the promise chain
   // this._alerts.updateFail = this.apiErrorMessageService.showPageAlertErrorMessage(response, 'updatePopulationApiFail');
   //TODO - alert message using service
    return of(null);
  }
  
  // selects the first population
  private selectFirstPopulation():void {
    this.userData.populationEdit = this.populations[0];
  }
  
  private selectPopulationByName(populationName: string):void {
    let populationFound = false;
  
    // loop through each population on the scope
    for (const population of this.populations) {
      // check if the population name matches the name we are searching for
      if (population.populationName === populationName) {
        // set the selectedPopulation to the matching population
        this.userData.selectedPopulation = population;
  
        // set the populationFound flag to true and break out of the loop
        populationFound = true;
        break;
      }
    }
  
    // if we couldn't find the population by name, select the first population instead
    if (!populationFound) {
      this.selectFirstPopulation();
    }
  }
  
  // adds an empty benefit to the programIdBenefitDescList
   addBenefit():void {
    this.userData.populationEdit.programIdBenefitDescList.push({});
  }
  
  private closeAllAlerts():void {
    //TODO
   // this.pageAlertsService.closeAlerts(this._alerts);
  }
  
  private resetFormState():void{
    if(this.editPopulationsForm){      
      //this.formService.resetFormState(this.editPopulationsForm!);
  
      this.editPopulationsForm.form.markAsPristine();
      this.editPopulationsForm.form.markAsUntouched();
      this.editPopulationsForm.form.updateValueAndValidity();
    }
  }
  
  private deleteSelectedPopulation():void{
    // get the index of the population to delete
    const populationIndex = this.populations.indexOf(this._originalPopulation);
    if (populationIndex !== -1) {
      // get the name before deleting to show in the success message
      const populationName = this._originalPopulation.populationName;
  
      // set the updateInProgress flag to lock down the UI
      this.updateInProgress = true;
  
      // invoke the API to delete the population
      this.populationsApi.deletePopulation(this._originalPopulation).pipe(
        tap(() => {
          // remove the population from the scope list
          this.populations.splice(populationIndex, 1);
  
          // select the first population
          this.selectFirstPopulation();
  
          // show a delete success alert
          //this._alerts.deleteSuccess = this.pageAlertsService.addSuccess(
          //  `Population "${populationName}" and all Benefit Description/Program ID combinations have successfully been deleted`,
          //  'editPopulations-deleteSuccess'
          //);

          this.deleteSuccessMessage = `Population "${populationName}" and all Benefit Description/Program ID combinations have successfully been deleted`
  
          // show the delete warning message
          this.showDeleteWarningMessage();
        }),
        catchError((error) => this.deleteBenefitFail(error)),
        finalize(() => {
          // clear the updateInProgress flag
          this.updateInProgress = false;
        })
      ).subscribe();
    } else {
      // original population not found (most likely a new population that was never saved)
      // just select the first population
      this.selectFirstPopulation();
    }
  }
  
  onPopulationChange():void{
    console.log('after drop down change: ', this.userData.selectedPopulation.programIdBenefitDescList);
    console.log('after drop down change - populationEdit: ',  this.userData.populationEdit);
  }
  
   deleteBenefit(benefit: any):void {
    let deleteBenefitObservable;
  
    // check if the benefit has an originalProgramId value
    // if not, it is a new benefit that hasn't been saved yet - don't call the API to delete
    if (benefit.originalProgramId !== undefined) {
      // start the payload to send to the API by first copying the originalPopulation object
      // there may be other unsaved changes on the form, so we need to use the original population data
      const populationPayload = { ...this._originalPopulation };
  
      // remove the deleted benefit from the payload
      this.removeBenefitByProgramId(populationPayload.programIdBenefitDescList, benefit.originalProgramId);
  
      // set the updateInProgress flag to lock down the UI
      this.updateInProgress = true;
  
      deleteBenefitObservable = this.populationsApi.updatePopulation(populationPayload).pipe(
        tap(() => {
          this.removeBenefitByProgramId(this._originalPopulation.programIdBenefitDescList, benefit.originalProgramId);
  
          // show a delete success alert
        //  this._alerts.deleteSuccess = this.pageAlertsService.addSuccess(
         //  'Benefit Description/Program ID combination has successfully been deleted', 'editPopulations-deleteSuccess'
         // );

          this.deleteSuccessMessage = 'Benefit Description/Program ID combination has successfully been deleted'
          this.showDeleteWarningMessage();
        }),
        catchError((error) => this.deleteBenefitFail(error)),
        finalize(() => {
          // clear the saving flags
          benefit.isDeleting = false;
          this.updateInProgress = false;
        })
      );
    }
  
    // wait for the deleteBenefitObservable to resolve (if there is one - otherwise this will resolve immediately)
    (deleteBenefitObservable || of(null)).pipe(
      tap(() => {
        // remove the benefit from the copied list
        this.arrayService.removeItem(this.userData.populationEdit.programIdBenefitDescList, benefit);
      })
    ).subscribe();
  }
  
  private deleteBenefitFail(response: any):any {
    // show an error message and return a rejected promise to break the promise chain
   // this._alerts.deleteFail = this.apiErrorMessageService.showPageAlertErrorMessage(response, 'deleteBenefitApiFail');
    this.deleteFailMessage  = 'deleteBenefitApiFail'
    return of(null);
  }
  
  private removeBenefitByProgramId(benefitList: any[], programId: string):void {
    // loop through each benefit
    for (let i = 0; i < benefitList.length; i++) {
      const benefit = benefitList[i];
  
      // if the programId matches the programId we are searching for, remove this benefit from the list and
      // break out of the loop
      if (benefit.programId === programId) {
        benefitList.splice(i, 1);
        break;
      }
    }
  }
  

}