/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input, OnInit } from '@angular/core';
import { PopulationApiService } from 'app/api/population-api.service';
import { catchError, map, Observable, throwError } from 'rxjs';

@Component({
  selector: 'sat-create-message',
  templateUrl: './create-message.component.html',
  styleUrls: ['./create-message.component.scss']
})
export class CreateMessageComponent implements OnInit {

  @Input() populations : any[] | null | undefined;
  @Input() baseId : any[] | undefined;
  populationsFromApiCall$ : Observable<any> | undefined;
  constructor(
      private populationsApi: PopulationApiService
    ) { }
  
  // set to true to open the accordion
  accordionState = {
    isOpen: false
};

createMessageSuccess():void{
  // close the create/edit message accordion
  this.accordionState.isOpen = false;
}

ngOnInit(): void {  
  // get the list of populations to use in create/edit message views - only need this when not in readonly mode
  this.populationsFromApiCall$ = this.populationsApi.getAllPopulations()
  .pipe(
    map(this.getAllPopulationsSuccess.bind(this)),
    catchError(this.getAllPopulationsFail.bind(this))
  );
}

getAllPopulationsSuccess(response: { populationList: any[] | undefined; }): void {
  // set populations on the scope to bind to the child views
  this.populations = response.populationList;
}

getAllPopulationsFail(response: any):Observable<never>{
  console.log('getAllPopulationsFail from msg compt');
  // show an error message
  //TODO
//  this.apiErrorMessageService.showPageAlertErrorMessage(response, 'getAllPopulationsApiError',
// return a rejected promise to break the promise chain
return throwError('There was an error loading the list of populations. Please refresh and try again.'); 
}


}
