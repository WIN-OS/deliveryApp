import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPopulationBenefitsComponent } from './edit-population-benefits.component';

describe('EditPopulationBenefitsComponent', () => {
  let component: EditPopulationBenefitsComponent;
  let fixture: ComponentFixture<EditPopulationBenefitsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EditPopulationBenefitsComponent]
    });
    fixture = TestBed.createComponent(EditPopulationBenefitsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
