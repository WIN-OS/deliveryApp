import { Component } from '@angular/core';

@Component({
  selector: 'sat-edit-authorized-users',
  templateUrl: './edit-authorized-users.component.html',
  styleUrls: ['./edit-authorized-users.component.scss']
})
export class EditAuthorizedUsersComponent {

}
