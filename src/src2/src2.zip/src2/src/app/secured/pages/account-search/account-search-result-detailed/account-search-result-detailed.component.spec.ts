import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountSearchResultDetailedComponent } from './account-search-result-detailed.component';
import { LoadingSpinnerComponent } from 'app/secured/components/loading-spinner/loading-spinner.component';

describe('AccountSearchResultDetailedComponent', () => {
  let component: AccountSearchResultDetailedComponent;
  let fixture: ComponentFixture<AccountSearchResultDetailedComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AccountSearchResultDetailedComponent]
    });
    fixture = TestBed.createComponent(AccountSearchResultDetailedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
