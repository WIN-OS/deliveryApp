/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
/** Derived from Legacy App - provider-portal-2020-admin/src/components/account-search-results/account-search-result-detailed/account-search-result-detailed.directive.js */

import { Component, EventEmitter, Input, OnInit, Output, ViewChild, inject } from '@angular/core';
import { AccountActivityHistoryApiService } from 'app/api/account-activity-history-api.service';
import { AccountSearchApiService } from 'app/api/account-search-api.service';
import { AccountSettingsApiService } from 'app/api/account-settings-api.service';
import { ApiErrorMessageService } from 'app/core/api-error-message.service';
import { IAccountSearchFormQuery, IPaginationObj, IRetailMessages } from 'app/shared/model/interfaces';
import { PaginationService } from 'app/shared/services/pagination.service';
import { RouteHelperService } from 'app/shared/services/route-helper.service';
import { Observable, of, throwError } from 'rxjs';
import { catchError, finalize, map, tap } from 'rxjs/operators';
import {DataSource} from '@angular/cdk/collections';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { UserProfileApiService } from 'app/api/user-profile-api.service';

@Component({
  selector: 'sat-account-search-result-detailed',
  templateUrl: './account-search-result-detailed.component.html',
  styleUrls: ['./account-search-result-detailed.component.scss']
})
export class AccountSearchResultDetailedComponent implements OnInit {


@ViewChild(MatSort, { static: true })
sort: MatSort = new MatSort;
displayedColumns: string[] = ['actionDate', 'activity', 'actor'];
dataSource : any ;

  @Input() item: any ;
  @Input() baseId: string | undefined;
  paginationService = inject(PaginationService);
  routeHelperService = inject(RouteHelperService);
  apiErrorMessageService = inject(ApiErrorMessageService);
  accountSettingsApi = inject(AccountSettingsApiService);
  accountActivityHistoryApi = inject(AccountActivityHistoryApiService);
  accountSearchApiService = inject(AccountSearchApiService);
  userProfileApiService = inject(UserProfileApiService);

  accountActivityHistoryResults$: Observable<any> | undefined;
  historyResultsTotalElement = 0;
  // reference to any API alerts
  private _alerts : any;

  // toggle to true to open the Account Activity History section
  accountActivityHistoryOpen = false;

  // tracks whether or not we have loaded the history
  accountActivityHistoryLoaded = false;

   // set these to true to indicate data is loading and to lock down the fields     
  loadingFlags = {
    updateStatus: false,
    updateClaimFormAccess: false,
    updateLegacy2020Access: false,
    accountActivityHistory: false
  };

  // set the isAccountActive flag - this flag drives whether or not to show the Edit User buttons
  // we need a separate flag from the status property so we can only update it after successful API calls
  isAccountActive = false;

  // initialize the account activity history results object
  accountActivityHistoryResults : any;

  // set the account activity history onto the pagination object (needs to be nested on the pagination object
  // for angular bindings to work properly back and forth)
  pagination = {
    accountActivityHistory : {
      itemSort : {
        sortProperty : '',
        reverse : false
      }
    }
  };
  
  // properties that are active links that perform searches - the value for each key is the property to search by
  // eslint-disable-next-line @typescript-eslint/naming-convention
  SEARCH_PROPERTIES = {
      NPI: 'npi',
      PHONE: 'phoneNumber',
      EMAIL: 'email',
      TAX_ID: 'taxId',
      INVITED_USER_STATUS: '2'
  };


  
  ngOnInit():void {
    // initialize the account activity history pagination state
    // get the default state and then set pagination to sort by actionDate reversed
    if(this.paginationService.getDefaultPaginationState() !== undefined){
      this.pagination.accountActivityHistory = this.paginationService.getDefaultPaginationState()
      this.pagination.accountActivityHistory.itemSort.sortProperty = 'DATE';
      this.pagination.accountActivityHistory.itemSort.reverse = true;
    }
    this.setIsAccountActive();

    console.log('item', JSON.stringify(this.item));
    console.log('baseID', JSON.stringify(this.baseId));
  }


  
  getUserFullName(user:any): string {
    return [user.accountUserFirstName, user.accountUserLastName].join('').trim();
  }

  statusChanged():void {
    // check the new value to see if we are activating or deactivating
    const activate = this.item.ui.statusString === 'Active';
    // update the status value accordingly
    this.updateAccountStatusValue(activate);

    // call the updateStatus API to save the update
    this.updateAccountSetting('updateStatus', activate)
      .pipe(
        tap(() => {
          // only update the isAccountActive flag on success
          this.setIsAccountActive();
        }),
        catchError(error => {
        const originalActiveStatus = !activate;
        this.item.ui.statusString = originalActiveStatus ? 'Active' : 'Inactive';
        this.updateAccountStatusValue(originalActiveStatus);
        return throwError(error);
      }));
  }

  claimFormStatusChanged(): void {
    // check the new value to see if we are activating or deactivating
    const activate = this.item.claimFormViewStatus === 'Y';
    // call the updateClaimFormAccess API to save the update
    this.updateAccountSetting('updateClaimFormAccess', activate)
      .pipe(catchError(error => {
         // revert the changes made on the UI
        const originalActiveStatus = !activate;
        this.item.claimFormViewStatus = originalActiveStatus ? 'Y' : 'N';
        return throwError(error);
      }));
  }

  legacy2020StatusChanged():void {
    // check the new value to see if we are activating or deactivating
    const activate = this.item.legacy2020Access === 'Allow';
    // call the updateLegacy2020Access API to save the update
    this.updateAccountSetting('updateLegacy2020Access', activate)
      .pipe(catchError(error => {
    // revert the changes made on the UI
        const originalActiveStatus = !activate;
        this.item.legacy2020Access = originalActiveStatus ? 'Allow' : 'Block';
        return throwError(error);
      }));
  }

  editUser(user: any):void {
    console.log('editUser clicked', user,' ',JSON.stringify(this.item));
    //this.routeHelperService.goToEditAccount({user: user.accountUserEmail, account: this.item.accountNumber});
    this.routeHelperService.goToEditAccount({user: user.accountUserEmail, account: this.item.accountNumber});
    //this.routeHelperService.goToEditAccount(user, this.item);
    //    const accountStr = JSON.stringify(this.item);
    //const userStr = JSON.stringify(user);
    this.userProfileApiService.sendEditUserEvent({user:user, account: this.item});
  }


  toggleAccountActivityHistory():void {
    // toggle the open status of the account activity history section
    this.accountActivityHistoryOpen = !this.accountActivityHistoryOpen;

    // check if we are expanding the history section for the first time
    if (this.accountActivityHistoryOpen && !this.accountActivityHistoryLoaded) {
       // set the loading flag to true
      this.loadingFlags.accountActivityHistory = true;

      console.log('pagination before the Account history call: ', JSON.stringify(this.pagination.accountActivityHistory));
      // load the first page of activity
    this.loadAccountActivityHistory(this.pagination.accountActivityHistory)
    ?.subscribe((itemsData: any) => {
      if((itemsData != null) && (itemsData != undefined)){
        console.log('itemsData: ',JSON.stringify(itemsData));
        // set the items data on the scope
        this.accountActivityHistoryResults = itemsData;
        this.dataSource = new MatTableDataSource(this.accountActivityHistoryResults);
        this.dataSource.sort = this.sort;
        // clear the loading flag and set the loaded state to true
        this.loadingFlags.accountActivityHistory = false;
        this.accountActivityHistoryLoaded = true;
      }
      });
    }
  }
  
  showHistoryTable():boolean {
return this.accountActivityHistoryLoaded && this.hasHistoryItems();
  }
  
  showNoHistoryMessage():boolean {
    return this.accountActivityHistoryLoaded && !this.hasHistoryItems();
  }
  

  // invokes one of the account settings APIs to activate/deactivate the setting
  // updateAction: the function to invoke on account-settings.api, as well as the flag name in $scope.loadingFlags
  // activate:     set to true to activate the setting for this account, false to deactivate it
  updateAccountSetting(updateAction: string, activate:boolean):Observable<any>{

    // close any API error messages
    this.closeAllAlerts();

    let response :any;

   if (updateAction === 'updateStatus' || updateAction === 'updateClaimFormAccess' || updateAction === 'updateLegacy2020Access'){
        // set the appropriate loading flag to true
        this.loadingFlags[updateAction] = true;
        // invoke the account-settings.api action to send the appropriate API request
     
          this.accountSettingsApi[updateAction](this.item.accountNumber, activate)
          .pipe(
            // set the loading flag back to false regardless of success or failure
            catchError(this.updateAccountSettingFail.bind(this)),
            finalize(() => this.loadingFlags[updateAction] = false)
          )
          .subscribe(returnedResponse => {
            response = returnedResponse;
          });
        }
        return of(response);
  }

  updateAccountSettingFail(response: any): Observable<never> {
    // show an error message from the response
    this._alerts.updateAccountSettingApiError = this.apiErrorMessageService.showPageAlertErrorMessage(response, 'updateAccountSettingApiError');
  
    // return a rejected promise to break the promise chain
    return throwError('Something bad happened; please try again later.');
  }
  
  closeAllAlerts():void{
    this.apiErrorMessageService.closePageAlertErrorMessage();
  }
  
  // set the status property on the account to "1" (active) or "2" (inactive)
  updateAccountStatusValue(isActive: boolean):void{
    this.item.status = isActive ? '1' : '2';
  }
  

  // loads the specified page of account activity history records
  loadAccountActivityHistory(paginationState: { itemSort: { sortProperty: string; reverse: boolean; }; }):any {
    // call the API with the given account number and pagination state
    this.accountActivityHistoryResults$ = this.accountActivityHistoryApi.getActivity(this.item.accountNumber, paginationState)
    .pipe(
      map(this.loadAccountActivityHistorySuccess.bind(this)),
      catchError(this.loadAccountActivityHistoryFail.bind(this))
      );
    
    }
    
    loadAccountActivityHistorySuccess(response: { retailMessages: IRetailMessages[]; totalElements: any;}):any {
      if (response && response.retailMessages && response.totalElements) {
        this.historyResultsTotalElement = response.totalElements;

      return {
        items: response.retailMessages,
        totalItems: response.totalElements
      };
    }else{
      throw new Error('Unexpected response in History Api');
    }
    }
    
    loadAccountActivityHistoryFail(response: any):Observable<never> {
      // show an error message from the response
      this._alerts.loadAccountActivityHistoryApiError = this.apiErrorMessageService.showPageAlertErrorMessage(response, 'loadAccountActivityHistoryApiError');
    
      // return a rejected promise to break the promise chain
      return throwError('Something bad happened; please try again later.');
    }
    
    hasHistoryItems():boolean {
    return this.accountActivityHistoryResults.items && this.accountActivityHistoryResults.items.length > 0;
    }
    
    
    setIsAccountActive():void {
      // account is active is status = 1
      this.isAccountActive = this.item.status === '1';
    }


  // invoked when an active property link is clicked to perform a new search
  performNewSearch(searchProperty:string, value:string):void{
    //search Query Obj
    const searchCriteria:  Record<string, any> = {
      accountStatus: null,
      accountNumber: null,
      email: null,
      taxId: null,
      phoneNumber: null,
      npi: null
      };

    // build an object with the search property and value to send to the account search service
      searchCriteria[searchProperty] = value;
      console.log('searchCriteria from performNewSearch: ',searchCriteria)
      // send the new search event - account search controllers will be listening
      this.accountSearchApiService.sendRequestNewSearchEvent(searchCriteria);
      this.accountSearchApiService.clickedLinkSubject.next(searchCriteria);
    }
}

//TODO 
// fontawesome icon
//standard view - search account -DONE
//perform new search - DONE
//add edit feature
//change status API -DONE
//pagination item --DONE
//table sorting
//add + in the form
//page alerts
//form alerts
//format phone no and tax id - DONE
//new perform for acc no in detail and standard - DONE
//spinner while loading 