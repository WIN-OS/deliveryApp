/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, OnChanges, OnDestroy, OnInit, SimpleChanges, computed, inject, signal } from '@angular/core';
import { FormArray, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { AccountSearchApiService } from 'app/api/account-search-api.service';
import { ApiErrorMessageService } from 'app/core/api-error-message.service';
import { AuthenticationServiceInternal } from 'app/core/authentication.service';
import { OauthTokenService } from 'app/core/oauth/oauth-token.service';
import { ISearchForm, IAccountSearchFormQuery } from 'app/shared/model/interfaces';
import { AbstractControlOptions} from '@angular/forms';
//import { MatOption } from '@angular/material/core';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { Observable, of, Subscription } from 'rxjs';

@Component({
  selector: 'sat-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.scss'],
})
export class SearchFormComponent implements OnInit {
    private authenticationService = inject(AuthenticationServiceInternal);
    private accountSearchApiService = inject(AccountSearchApiService);
    private apiErrorMessageService = inject(ApiErrorMessageService);
    private router = inject(Router);

    //Query from detailed or standard view links
    incomingSearchQueryFromLinks : any;

    // object containing the has-input-values flag for each input group
    hasInputFlags: { [key: string]: boolean } = {};
    
    // object containing the input-values array for each input group
    inputValues: { [key: string]: any } = {};
    
    // tracks whether or not the form has any valid input data, used to enable/disable the Search button
    formHasInputValues = false;
    
    isSearching = false;
    
    // reference to any API error alerts being displayed
    private _accountSearchApiErrorMessage = '';
    
    // reference to the current search (search type and query)
    private _currentSearch = {
        searchType : '',
        searchQuery : {} as Partial<IAccountSearchFormQuery>
    };
    
    //subscription to PerformNewSearch (when user clicks the link in detailed and standard view components)
    subscriptionToClickedSearch: Observable<any> | undefined;
    isIncomingQueryComing = false;

    accountSearchForm: FormGroup<ISearchForm>;
    searchResults: any;
    errorMessage: any;
    
    // start the filter with 'All' selected
    selectedAccountStatus = '';

    constructor(){

        this.accountSearchForm = this.createFormGroup();

        //logic to refresh the data on performNewSearch
        this.accountSearchApiService.clickedLinkSubject.subscribe(incomingQuery =>{
            if (incomingQuery) {
                this.incomingSearchQueryFromLinks = incomingQuery;
                this.isIncomingQueryComing = true;
                this.submitAccountSearch();
                } else {
                    // Clear messages when an empty message is received
                    this.incomingSearchQueryFromLinks = {};
                    this.isIncomingQueryComing = false;
                    }
        });
     


                        //logic to refresh the data on performNewSearch

        
    }
    
    // list of options for the Account Status dropdown
    accountStatusOptions = [
        'All',
        'Active',
        'Inactive'
        ];
  
  
   // ngOnChanges(changes: SimpleChanges): void {

   // }


    ngOnInit(): void {
        // start the filter with 'All' selected
        this.selectedAccountStatus = 'All';

        //clear the form search
        // this.clearAccountSearch();
        console.log('');
    }  
    
   // ngOnDestroy():void {
        // unsubscribe to ensure no memory leaks
      //  this.subscriptionToNewSearch?.unsubscribe();
   // }

    private createFormGroup() {
        return new FormGroup({
            accountStatus: new FormControl(''),
            accountNumber: new FormArray([new FormControl('', [Validators.pattern('\\d{1,6}')])]),
            email: new FormArray([new FormControl('', [Validators.email])]),
            taxId: new FormArray([new FormControl('', [Validators.pattern('\\d{9,9}')])]),
            phoneNumber: new FormArray([new FormControl('', [Validators.pattern('\\d{3}[.]\\d{3}[.]\\d{4}')])]),
            npi: new FormArray([new FormControl('', [Validators.pattern('\\d{10,10}')])]),
        });
    }

    logout():void{
        this.authenticationService.logout();

        //navigate to PingFed auth page
        window.location.reload();
    }
    
    getSearchObject():any{
        //inputObj could come from either the form or from the clickedSearchQuery
        let searchObj: {[s: string]: any}  = {};
        if(this.isIncomingQueryComing && this.incomingSearchQueryFromLinks){
            searchObj = this.incomingSearchQueryFromLinks;
        }else if(this.accountSearchForm.valid){
            const formValue =  this.accountSearchForm.value as {[s: string]: string | string[]};
            for (const key in formValue) {
                if (formValue[key].constructor === Array){
                    const value = formValue[key] as string[];
                    searchObj[key] = value.filter(v => v).join(',');
                    if (key === 'phoneNumber') {
                        searchObj[key] = searchObj[key].replace(/[\.]/g, '')
                    }
                } else {
                    searchObj[key] = formValue[key];
                }
            }
        }
        return searchObj;
    }

    submitAccountSearch(): void{
        
        if(this.accountSearchForm.valid || this.isIncomingQueryComing){
            // set the isSearching flag to true
            this.isSearching = true;

            // close any existing error messages - TODO
           // this.closeApiErrorMessage();

            // send the clear search resutls event so that the search results controller can clear its current data
            //this.accountSearchApiService.sendClearSearchResultsEvent();

            // get the search type
             this._currentSearch.searchType = this.getSearchType();

            // build the search query object
             this._currentSearch.searchQuery = this.buildSearchQueryObject();
            this.accountSearchApiService.search(this._currentSearch.searchQuery)
            .subscribe({
             next: (data) => {
                this.searchResults = data;
                this.getAccountSearchSuccess(data);
            },
            error: (error) => {
                this.getAccountSearchFail(error);
            },
            complete: () => {
            this.isSearching = false;
            }
            });

        }
        return;
    }

    closeApiErrorMessage():void {
        throw new Error('Method not implemented.');
    }
    
    getErrorMessage(field:string):string{
        return 'Error'
    }
    
    clearAccountSearch():void {
        this.accountSearchForm = this.createFormGroup();
        this.accountSearchForm.reset();
        // set the filter with 'All' selected
        this.accountSearchForm.controls['accountStatus'].setValue('All');
        this.searchResults = null;
        this.errorMessage = null;
    }


     // returns "standard" or "detailed", depending on the search type
     // detailed occurs when only account numbers are being searched, otherwise it's a standard search
    getSearchType():string {
        //inputObj could come from either the form or from the clickedSearchQuery
       const searchObject = this.getSearchObject();
        // loop through each search input property - if any of them have values and are not account number, this is not
        // a detailed account search
            for (const inputProperty in searchObject) {
                if ((inputProperty !== 'accountNumber' && inputProperty !== 'accountStatus') && searchObject[inputProperty]?.length > 0) {
                  return 'standard';
                }
            }
            return 'detailed';
    }

    // builds a query object to pass into the account search API
    buildSearchQueryObject():Partial<IAccountSearchFormQuery> {
        const searchQuery: Partial<IAccountSearchFormQuery> = {
            accountStatus: null,
            accountNumber: null,
            email: null,
            taxID: null,
            phoneNumber: null,
            npi: null
          };
        

        //check if the query is from the form or from the children components (standard and detailed view)
       const inputs = this.getSearchObject();
        console.log('buildSearchQueryObject: inputs - ',JSON.stringify(inputs));
        // loop through each group of input values
        for (const inputProperty in inputs) {
            // add the inputs to the query object, keyed on the input property, joined by a comma
            // npi needs to be called "nationalProviderId" in the query
            if (inputProperty == 'npi') {
                searchQuery['nationalProviderId'] = inputs[inputProperty as keyof IAccountSearchFormQuery];
                delete searchQuery['npi']; // delete the 'npi' key
            } else {
                searchQuery[inputProperty as keyof IAccountSearchFormQuery] = inputs[inputProperty as keyof IAccountSearchFormQuery];
            }
        }
        
        // set the accountStatus to the filter value (all caps)
        searchQuery.accountStatus = this.accountSearchForm.value.accountStatus ? this.selectedAccountStatus.toUpperCase() : null;
    return searchQuery;
    }


  getAccountSearchSuccess(response:any):void {
    // send the results and search details to the account search service to tell the results view
    // to show the results
    
    console.log('accountSearchApiService.sendNewSearchResultsEvent');
    this.accountSearchApiService.sendNewSearchResultsEvent({
        type: this._currentSearch.searchType,
        query: this._currentSearch.searchQuery as IAccountSearchFormQuery,
        responseData: response,
        stateData: { inputs: this.accountSearchForm.value, filter: this.accountSearchForm.value.accountStatus ?? '' }
      });
  }

  getAccountSearchFail(response:string):void {
    // show an API error message - TODO
    this._accountSearchApiErrorMessage = this.apiErrorMessageService.showPageAlertErrorMessage(response, 'accountSearchApiError');
  }
  
  //Check if there is atleast one value entered
  isFormEmptyOrInvalid():boolean {
      const form = this.accountSearchForm.value;
      return !form.accountNumber[0] && !form.email[0] && !form.taxId[0] && !form.phoneNumber[0] && !form.npi[0] 
        || !this.accountSearchForm.valid;
    }
  
}

