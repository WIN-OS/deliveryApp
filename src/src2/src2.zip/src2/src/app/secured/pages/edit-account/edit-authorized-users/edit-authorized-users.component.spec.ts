import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditAuthorizedUsersComponent } from './edit-authorized-users.component';

describe('EditAuthorizedUsersComponent', () => {
  let component: EditAuthorizedUsersComponent;
  let fixture: ComponentFixture<EditAuthorizedUsersComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EditAuthorizedUsersComponent]
    });
    fixture = TestBed.createComponent(EditAuthorizedUsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
