/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MessagesApiService } from 'app/api/messages-api.service';
import { PopulationApiService } from 'app/api/population-api.service';
import { DateUtilService } from 'app/core/date-util.service';
import { IMessages, IPopulationList } from 'app/shared/model/interfaces';
import { MessagesService } from 'app/shared/services/messages.service';
import { Observable, of } from 'rxjs';
import { catchError, finalize, map, startWith, tap } from 'rxjs/operators';


@Component({
  selector: 'sat-edit-message-form',
  templateUrl: './edit-message-form.component.html',
  styleUrls: ['./edit-message-form.component.scss']
})

export class EditMessageFormComponent implements OnInit {
  
  editMessageForm!: FormGroup;
  populationsLoaded = false;
  saveInProgress = false;
  @Input() populations: any[] = [];
  allPopulation: any;
  namedPopulations: any[] = [];
  hasSelectedPopulationsFlag: boolean | undefined;
  messageData: any;
  @Input() editingMessage: any;
  @Input() baseId :string | 'editMessage' | undefined;

  constructor(private fb: FormBuilder, private messagesService: MessagesApiService,
    private dateService: DateUtilService,
    private populationApiService: PopulationApiService
  ) { }

  ngOnInit():void {
    this.editMessageForm = this.fb.group({
      effectiveDates: this.fb.group({
        from: this.fb.group({
          date: [new Date(), Validators.required],
          time: ['', Validators.required]
        }),
        to: this.fb.group({
          date: [new Date(), Validators.required],
          time: ['', Validators.required]
        })
      }),
      message: ['', Validators.required],
      noEndDateSelected: [null]
    });

    // format the populations list
    // Ensure populations is an array before formatting
    if (Array.isArray(this.populations)) {
      this.formatPopulations(this.populations);
    }
    // set the messageData object to its empty/default state
    this.setEmptyMessageData();
      // if we are editing a message, set the scope data from the message being edited
    if (this.editingMessage) {
      this.setScopeFromEditingMessage();
    }

  
    this.populationApiService.getAllPopulations().pipe(
      tap(populations => {
        this.populations = populations;
        if (Array.isArray(this.populations)) {
          this.formatPopulations(this.populations);
      }
      this.setEmptyMessageData();
      if (this.editingMessage) {
        this.setScopeFromEditingMessage();
      }
      this.populationsLoaded = true;
      }),
      catchError(error => {
        console.error(error);
      return of([]);
      })
      ).subscribe();

    this.editMessageForm.valueChanges.subscribe(() => {
    this.hasSelectedPopulationsFlag = this.getSelectedPopulations().length > 0;
});
}


  submitCreateMessage():void {
    if (this.editMessageForm.valid && this.hasSelectedPopulations()) {
      // set the saveInProgress flag to true
      this.saveInProgress = true;
      // build a message object from the scope data
      const message = this.buildMessagePayload();

      // if we are editing a message, invoke the Update Message API
      // otherwise, use Create Message
      let createOrUpdate$: Observable<any>;
      if (this.editingMessage) {
        createOrUpdate$ = this.messagesService.updateMessage(this.editingMessage.messageId, message);
      //TODO
        //this.updateMessageSuccess();
      } else {
        createOrUpdate$ = this.messagesService.createMessage(message);
        //this.createOrUpdateMessageFail();
      }
      createOrUpdate$.pipe(
        tap(messageId => {
          // set the message Id on the message
          message.messageId = messageId;
          // update ui properties on the message
          this.messagesService.updateUiProperties(message);
          // send the add message event to add it to the View Messages Table
          this.messagesService.sendAddMessageEvent(message);
          // clear the edit message form
          this.clearEditMessageForm();
        }),
        // clear the saveInProgress flag in a finally block so that it occurs on success or failure
        finalize(() => this.saveInProgress = false),
        catchError(error => {
          console.error(error);
          return of(null);
        })
      ).subscribe();
    }
    else {
      this.addPopulationsRequiredMessage();
    }
  }

  clearEditMessageDirective():void {
    this.clearEditMessageForm();
  }

   // the expiration time cannot be less than the the from time, only if the from and to dates are equal
   // if the expiration date is less than the form date, the date field itself will be invalid, not the time field
   // if the expiration date is greater than the from date, then the time doesn't matter
  
  getMinExpirationTime():any{
    const fromDate = this.editMessageForm.controls['effectiveDates.from.date']?.value;
    const toDate = this.editMessageForm.controls['effectiveDates.to.date']?.value;
     // compare the from and to date, ignoring the time values
    if (fromDate.getTime() === toDate.getTime()) {
       // from and to date are equal = return the from time
      return this.editMessageForm.controls['effectiveDates.from.time']?.value;
    } else {
      // dates are not equal - return null for no min date
      return null;
    }
  }

  // watch for changes to the "All" populations checkbox
  allPopulationsCheckboxChanged():void {
    if (this.allPopulation.selected) {
      // if "All" is selected, de-select all other options
      this.clearNamedPopulationSelections();
    }
  }

  // watch for changes to the "No End Date" Selection
  noEndDateSelectionChanged():void {
    // if No End Date was selected, clear the To Date and Time
    if (this.editMessageForm.controls['noEndDateSelected']?.value) {
      this.editMessageForm.controls['effectiveDates.to.date']?.reset();
      this.editMessageForm.controls['effectiveDates.to.time']?.reset();
    }
  }


  private setEmptyMessageData():void {
    // set messageData to its default state
    this.editMessageForm.reset({
      effectiveDates: {
        from: {
          date: new Date(),
          time: ''
        },
        to: {
          date: new Date(),
          time: ''
        }
      },
      message: '',
      noEndDateSelected: null
    });

    // clear all population selections
    this.clearAllPopulationSelections();
  }
  
  // checks if any of the populations are selected on the form
   hasSelectedPopulations():boolean {
    //TODO - check logic
    // return true if "All" is selected - no need to check others
    return this.getSelectedPopulations().length > 0;
  }

  // clears the Edit Message form
   clearEditMessageForm():void {
    this.setEmptyMessageData();
    this.editMessageForm.markAsPristine();
    this.editMessageForm.markAsUntouched();
  }

   getSelectedPopulations():string[] {
    // if the "All" option is selected, return "All"
    if (this.allPopulation.selected) {
      return ['All'];
    }
    // for each population, if it is selected, add the populationName to the new populations array
    return this.namedPopulations.filter(population => population.selected).map(population => population.populationName);
  }

  // show the "Please select at least one Population" input message
    addPopulationsRequiredMessage():void{
    //this.inputMessageService.addInputMessage(POPULATION_GROUP_ID, 'Please select at least one Population', {appendToElement: true, width: 300});
}

// remove the "Please select at least one Population" input message
  removePopulationsRequiredMessage():void{
   // this.inputMessageService.removeInputMessage(POPULATION_GROUP_ID);
}

// builds a message object to send to the API/Search Messages view
private buildMessagePayload():IMessages {
  // get the list of selected populations
  const populations = this.getSelectedPopulations();

  // build the message object
  const newMessage:IMessages = {
    message: this.editMessageForm.controls['message']?.value,
    populations: populations,
    startDate: this.editMessageForm.controls['effectiveDates.from.date']?.value,  
    startTime: this.editMessageForm.controls['effectiveDates.from.time']?.value,
    endDate: '',
    endTime:'',
    messageId: '',
    messageStatus: ''
  };

  // if No End Date is selected, omit the endDate/Time properties, otherwise format and set them on the payload
  if (!this.editMessageForm.controls['noEndDateSelected']?.value) {
    newMessage.endDate = this.editMessageForm.controls['effectiveDates.to.date']?.value,  
    newMessage.endTime = this.editMessageForm.controls['effectiveDates.to.time']?.value 
  }

  return newMessage;
}

// invoked when the Create Message API request is successful
private createMessageSuccess(response: { data: { messageId: string; }; }):string {
  // show a success message
  // _alerts.createMessageSuccess = pageAlertsService.addSuccess('The message has been successfully created.', 'createMessageApiSuccess');

  // return the new messageId created
  return response.data.messageId;
}

// invoked when the Update Message API request is successful
private updateMessageSuccess(response: { data: { messageId: string; }; } | undefined):  string| undefined  {
  // show a success message
  // _alerts.updateMessageSuccess = pageAlertsService.addSuccess('The message has been successfully updated.', 'createMessageApiSuccess');

  // expire the original message (set it to today's time) - no need to save this message vai the API because the API does this automatically
  const localTimePST = this.dateService.getDateInPacificTime(new Date());
  const todayDateTime = this.dateService.getDateTimeObjectFromDateObject(localTimePST);
  this.editingMessage.endDate = todayDateTime.date;
  this.editingMessage.endTime = todayDateTime.format('HH:mm:ss');
  this.editingMessage.messageStatus = 'INACTIVE';

  // update the ui object properties
  this.messagesService.updateUiProperties(this.editingMessage);

  // return the new messageId created - updating messages actually creates a new message and expires the old message
  return response?.data.messageId;
}

//private createOrUpdateMessageFail(response: string | undefined) {
  // show an error message
  // _alerts.createOrUpdateMessageFail = apiErrorMessageService.showPageAlertErrorMessage(response, 'createOrUpdateMessageApiFail');

  // return a rejected promise to break the promise chain
 //throw new Error(response);
//}

private setScopeFromEditingMessage():void {
  // copy the message being edited so that we don't change any values until the message is saved
  const message = { ...this.editingMessage };

  // set the message value and from date/time
  this.editMessageForm.controls['message'].setValue(message.message);
  this.editMessageForm.controls['effectiveDates.from.date'].setValue(new Date(message.startDate));
  this.editMessageForm.controls['effectiveDates.from.time'].setValue(message.startTime);

  // check if the message has an end date
  if (message.endDate) {
    // set the effectiveDates.to values from the message data
    this.editMessageForm.controls['effectiveDates.to.date'].setValue(new Date(message.endDate));
    this.editMessageForm.controls['effectiveDates.to.time'].setValue(message.endTime);
  } else {
    // if endDate is not set, this is a static message - set the "No End Date" checkbox to true and clear the date and time fields
    this.editMessageForm.controls['noEndDateSelected'].setValue(true);
    this.editMessageForm.controls['effectiveDates.to.date'].reset();
    this.editMessageForm.controls['effectiveDates.to.time'].reset();
  }

  if (message.populations) {
    // if populations has the "All" option, just select the "All" box
    if (this.editingMessage.populations.indexOf('All') !== -1) {
      this.allPopulation.selected = true;
    } else {
      // otherwise, loop through each population on the message and set it's corresponding value to true
      for (let i = 0; i < message.populations.length; i++) {
        this.selectPopulationByName(message.populations[i]);
      }
    }
  }
}

// loops through each population object, looking for a match by "populationName". Returns the population object or null if not found
private getPopulationByName(populationName: string ,popList?: IPopulationList[] ):any {
  let searchedResult ;
  if(popList){
    searchedResult = popList.find(population => population.populationName.toUpperCase() === populationName.toUpperCase()) || null;
  }else {
    searchedResult = this.namedPopulations.find(population => population.populationName.toUpperCase() === populationName.toUpperCase());
  }
  return searchedResult
}

// finds a population object by "populationName", sets selected to true if it is found
private selectPopulationByName(populationName: string):void {
  const population = this.getPopulationByName(populationName);
  //TODO  - check logic
  if (population) {
   // population.selected = true;
  }
}

// builds a formatted copy of the populations for use with the Populations checkboxes
private formatPopulations(populations: IPopulationList[]):void {
  // copy the list of populations as to not modify the original list
  const populationList = [...populations];

  // get the "All" population
  let allPopulation = this.getPopulationByName( 'All', populationList);
  if (allPopulation) {
    // remove the all population from the population list - this allows us to keep it separate,
    // as it needs to have separate HTML/functionality and cannot be part of the populations ng-repeat
    const allPopulationIndex = populationList.indexOf(allPopulation);
    populationList.splice(allPopulationIndex, 1);
  } else {
    // couldn't find a population named "All" in the list - create one instead
    allPopulation = {
      populationName: 'All'
    };
  }

  // set a reference to the "All" population
  this.allPopulation = allPopulation;

  // set a reference to the "named" populations (all populations besides "All")
  this.namedPopulations = populationList;
}

// sets all named populations and the "All" population selections to null (unchecked)
private clearAllPopulationSelections():void {
  // clear all named populations
  this.clearNamedPopulationSelections();

  // clear the "All" population
  this.allPopulation.selected = null;
}

// loops through all named populations (all populations other than "All") and sets
// selected to null (unchecked)
private clearNamedPopulationSelections():void {
  for (let i = 0; i < this.namedPopulations.length; i++) {
    this.namedPopulations[i].selected = null;
  }
}
/*
private closeAllAlerts() {
  // pageAlertsService.closeAlerts(_alerts);
}

private getDateTimeObjectFromDateObject(date: Date) {
  // implementation omitted for brevity
}

*/
  cancelChanges():void{
  console.log('Dummy function - TEMP');

}
  
}