/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, Input, OnChanges, OnInit, SimpleChanges, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup,Validators } from '@angular/forms';
import { catchError } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { ApiErrorMessageService } from 'app/core/api-error-message.service';
import { PageAlertService } from 'app/core/page-alert.service';
import { PopulationApiService } from 'app/api/population-api.service';
import { ContactUsApiService } from 'app/api/contact-us-api.service';
import { IPhoneLine, IPopulationList } from 'app/shared/model/interfaces';
//import { EventEmitter } from 'events';

@Component({
  selector: 'sat-edit-phone-lines',
  templateUrl: './edit-phone-lines.component.html',
  styleUrls: ['./edit-phone-lines.component.scss']
})

export class EditPhoneLinesComponent implements OnInit, OnChanges {
  //@Input() populationSub!: Observable<IPopulationList> | undefined;
  @Input() population : IPopulationList | null = null;
  phoneLinesForm: FormGroup | undefined;
  loadingPhoneLines = false;
  updateInProgress = false;
  phoneLines: IPhoneLine[] = [];
  originalPhoneLines: any[] = [];
  alerts: any = {};


  constructor(
    private fb: FormBuilder,
    private contactUsApiService: ContactUsApiService,
    private pageAlertsService:PageAlertService
  ) {}

  ngOnInit():void {
    //get the object from the parent
    /*
    if(this.populationSub){
      this.populationSub.subscribe(populationSelectedObj => {
        this.population = populationSelectedObj;
        });
        }
        */
        if(this.population){
          this.loadPhoneLines();
        }

    this.phoneLinesForm = this.fb.group({
      phoneLines: this.fb.array([])
    });
  }
  
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['population'] && this.population) {
      this.loadPhoneLines();
    }
  }

  loadPhoneLines():void {
    if (this.population) {
      this.loadingPhoneLines = true;
      this.contactUsApiService.getContactUsForPopulation(this.population.populationId).subscribe({
       next:  (response: any) => {
        console.log('contactUsApiService.getContactUsForPopulation: ',JSON.stringify(response));
          this.phoneLines = response.retailContactUsList || [];
          this.originalPhoneLines = [...this.phoneLines];
          this.loadingPhoneLines = false;
        },
        error:
        (error: any) => {
          this.alerts.getContactUsFail = 'Failed to load phone lines.';
          this.loadingPhoneLines = false;
        }
    });
    }
  }

  saveChanges():void {
    if (this.phoneLinesForm?.valid && this.population) {
      this.updateInProgress = true;
      console.log('Phonelines before formating', JSON.stringify(this.phoneLines));
      this.contactUsApiService.updateContactUsForPopulation(this.population.populationId, this.phoneLines).subscribe({
        next : () => {

          this.alerts.confirmOtherPopulations = this.pageAlertsService.addSuccess(
            'Phone Lines have been successfully updated',
            'updateContactUsSuccess', { trustedHTML: true, compileHTML: true }
          );
          
          this.alerts.updateContactUsSuccess = 'Phone Lines have been successfully updated';
          this.loadPhoneLines();
          this.updateInProgress = false;
        },
        error: (error: any) => {
                    this.alerts.confirmOtherPopulations = this.pageAlertsService.addWarning(
                      'Failed to update phone lines.',
                      'updateContactUsFail', { trustedHTML: true, compileHTML: true }
                    );
          this.alerts.updateContactUsFail = 'Failed to update phone lines.';
          this.updateInProgress = false;
        }
    });
    }
  }

  addPhoneLine():void {
    console.log('Add phone line event received');
    this.phoneLines.push({ phoneLine: '', phoneNumber: '', phoneAlias: '' });
    console.log('addPhoneLine',JSON.stringify( this.phoneLines));
  }
  
  removePhoneLine(index: number): void {
    this.phoneLines.splice(index, 1);
    console.log('removePhoneLine',JSON.stringify( this.phoneLines));
  }

  noPhoneLines():boolean {
    return !this.phoneLines || this.phoneLines.length === 0;
  }

  closeAllAlerts():void {
    this.alerts = {};
  }

  
}



