/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, inject, Input, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { IMessageQuery, IMessagesResponse, IPaginationObj } from 'app/shared/model/interfaces';
import { MessagesApiService } from 'app/api/messages-api.service';
import {DataSource} from '@angular/cdk/collections';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { PaginationService } from 'app/shared/services/pagination.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'sat-view-messages',
  templateUrl: './view-messages.component.html',
  styleUrls: ['./view-messages.component.scss']
})

export class ViewMessagesComponent implements OnInit {
  private messagesApiService = inject(MessagesApiService);
  private paginationService = inject(PaginationService);
  private modalService = inject(NgbModal);
  
  searchMessagesForm: FormGroup;
  messageStatusOptions = [
    {label: 'All', value: 'MESSAGE_ALL'},
    {label: 'Active', value: 'MESSAGE_ACTIVE'},
    {label: 'Inactive', value: 'MESSAGE_INACTIVE'}
  ];


   // object to contain search results data - nesting messages inside because of back-and-forth angular bindings
  searchResultsData = { messages: [], totalMessages: 0 };
  // will be set to true when the initial messages load succeeds
  messagesLoaded = false;
   // flag to track whether or not a search is currently loading
  messageSearchLoading = false;
  // set to true if no messages are found
  noMessagesFound = false;
  private _searchPerformed = false;
  private _currentSearchQuery = '';
  searchMessageData :any;
  paginationState :IPaginationObj | undefined;
  pagination :any;
  
 
  
  @Input() readOnly:boolean | undefined;
  @ViewChild(MatSort, { static: true })
  sort: MatSort = new MatSort;
  displayedColumns: string[] = ['messageId', 'message', 'populationsString','startDateTimeString','endDateTimeString'];
  dataSource : any ;
  
  
  
  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.searchMessagesForm = new FormGroup({
      statusFilter: new FormControl(this.messageStatusOptions[0].value),
      query: new FormControl('', Validators.required)
    });
  }
  
  ngOnInit():void {
  
    // create the pagination state from the default state and set the initial sort to FROM_DATE (effective date) in reverse
    // get the default state and then set pagination to sort by actionDate reversed
    if(this.paginationService.getDefaultPaginationState() !== undefined){
      this.paginationState = this.paginationService.getDefaultPaginationState()
      this.paginationState.itemSort.sortProperty = 'FROM_DATE';
      this.paginationState.itemSort.reverse = true;
    }

     // create a pagination object with our custom paginationState inside
  this.pagination = {
    paginationState: this.paginationState
  };

    // initialize the search data
    this.searchMessageData = {
     statusFilter: this.messageStatusOptions[0].value,
     query: ''
    };

    this.getMessages(this.pagination.paginationState).subscribe(messageData => {
      console.log('getMessages() - messageData :', JSON.stringify(messageData));
      this.updateScopeFromMessagesData(messageData);
      this.messagesLoaded = true;
    });

  }

  getHeaderText(): string {
    // show "Recent Messages" when page first loads, and then "Search Results" after a search is performed
    return this._searchPerformed ? 'Search Results' : 'Recent Messages';
  }

  // selects a message (invoked when the message number is clicked from the table)
  selectMessage(message:string): void{
      // only open the edit message modal if we are not in read-only mode (non-super-user)
      if (!this.readOnly){
        //TODO create Modal 
          this.openEditMessageModal(message);
      }
  }
        
  openEditMessageModal(message: string): void{
  //this.openXl(message);
  }
  
  openXl(content: TemplateRef<any>):void {
    this.modalService.open(content, { size: 'xl' });
  }

  submitMessageSearch(): void {
    // save the current search query
    this._currentSearchQuery = this.searchMessagesForm.value.query;
     // set the search performed flag to true
    this._searchPerformed = true;
    // perform a search for messages
    this.performMessageSearch();
  }

  showMessageResults(): boolean {
    return this.messagesLoaded && !this.noMessagesFound;
  }

   // invoked when the Message Status filter changes
  messageFilterChanged(): void {
     // perform a new search with the new filter value
    this.performMessageSearch();
  }

  private getMessages(paginationState: boolean | IPaginationObj | undefined): Observable<any> {
    const getMessagesSearchQueryObject:IMessageQuery = this.buildGetMessagesSearchQueryObject();

    return this.messagesApiService.getMessages(getMessagesSearchQueryObject, paginationState).pipe(
      map(response => (
        {
          items: response.retailMessages,
          totalItems: response.totalElements
      })),
      catchError(error => {
        console.error('getMessagesApiError', error);
        return throwError(error);
      })
    );
  }

  private performMessageSearch(): void {
    this.messageSearchLoading = true;
    this.getMessages(this.pagination.paginationState).subscribe(messageData => {
      console.log('performMessageSearch() - messageData :', JSON.stringify(messageData));
      this.updateScopeFromMessagesData(messageData);
      this.messageSearchLoading = false;
    });
  }

  private updateScopeFromMessagesData(messageData: { items: never[]; totalItems: number; }): void {
    this.searchResultsData.messages = messageData.items;
    this.searchResultsData.totalMessages = messageData.totalItems;
    console.log('updateScopeFromMessagesData fn - searchResultsData :', JSON.stringify(this.searchResultsData));
    this.noMessagesFound = (messageData.totalItems === 0);
  }

  private buildGetMessagesSearchQueryObject(): IMessageQuery {
    return {
      messageText: this._currentSearchQuery,
      messageType: this.searchMessagesForm.value.statusFilter
    };
  }
}

