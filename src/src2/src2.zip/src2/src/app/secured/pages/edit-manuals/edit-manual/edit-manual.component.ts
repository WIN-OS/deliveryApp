import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ManualsApiService } from 'app/api/manuals-api.service';

import { Manual } from 'app/shared/model/manuals.model';


@Component({
  selector: 'sat-edit-manual',
  templateUrl: './edit-manual.component.html',
  styleUrls: ['./edit-manual.component.scss']
})
export class EditManualComponent {
  @Input() manual!: Manual;
  @Input() index!: number;
  @Input() isLastManual = false;

  @Output() addManual = new EventEmitter<void>();
  @Output() deleteManual = new EventEmitter<number>();

  confirmingDelete = false;
  isDeleting = false;
  errorMessage = '';

  constructor(private manualsApi: ManualsApiService) {}

  onAddManual(): void {
    this.addManual.emit();
  }

  onSelectFile(e: Event, fileUpload: HTMLInputElement) {
    e.preventDefault();
    fileUpload.value = '';
    fileUpload.click();
  }

  onFileSelected(files: File[]) {
    this.prepareManualFile(files);
  }

  onFileDropped(files: FileList) {
    this.prepareManualFile(files);
  }

  startDeleteManual() {
    this.confirmingDelete = true;
  }

  confirmDelete(shouldDelete: boolean) {
    if (!shouldDelete) {
      this.confirmingDelete = false;
      return;
    }
    
    if (shouldDelete) {
      this.isDeleting = true;

      if (this.manual.manualId) {
        this.manualsApi.deleteManual(this.manual.manualId).subscribe({
          error: (error) => {
            this.errorMessage = error;
          },
          complete: () => {
            this.removeManualFromUI();
          }
        })
      }
      else {
        this.removeManualFromUI();
      }
    }
  }

  private removeManualFromUI() {
    this.deleteManual.emit(this.index);

    this.confirmingDelete = false;
    this.isDeleting = false;
  }

  private prepareManualFile(files: File[] | FileList) {
    this.manual.file = files[0];
    this.manual.manualName = files[0].name;
    this.manual.hasFile = true;
  }
} 
