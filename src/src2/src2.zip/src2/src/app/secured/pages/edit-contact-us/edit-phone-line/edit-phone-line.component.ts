/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */

import { Component, Input, OnInit, Output, EventEmitter, OnChanges, SimpleChanges, inject } from '@angular/core';
import { EditPhoneLinesComponent } from '../edit-phone-lines/edit-phone-lines.component';
import { ContactUsApiService } from 'app/api/contact-us-api.service';
import { PopulationApiService } from 'app/api/population-api.service';


@Component({
  selector: 'sat-edit-phone-line',
  templateUrl: './edit-phone-line.component.html',
  styleUrls: ['./edit-phone-line.component.scss']
})

export class EditPhoneLineComponent implements OnInit{
  @Input() phoneLine: any;
  @Input() index = 0;
  @Output() addPhoneLineEvent = new EventEmitter<void>();
  confirmingDelete = false;
  isDeleting = false;
  phoneLines: any[] = [];
  originalPhoneLines: any[] = [];
  alerts: any = {};
  population: any;
  populationApiService = inject(PopulationApiService);
  formattedPhoneNumber = ''
  constructor(private contactUsApiService : ContactUsApiService ) {}

  ngOnInit(): void {
    //this.population = this.populationApiService.getSelectedPopulationSub();
    this.populationApiService.getSelectedPopulationSub()?.subscribe({
      next: (selectedPopulation) => {
        this.population = selectedPopulation;
      },
      error: () => {
        console.log('Error subscribing to the selected Population from Parent');
      }
    })

    if(this.phoneLine.phoneNumber){
      this.phoneLine.phoneNumber = this.formatPhoneNumber(this.phoneLine['phoneNumber']);
    }
  }
  

  startDeletePhoneLine(): void {
    this.confirmingDelete = true;
  }

confirmDelete(confirm: boolean):void {
  if (confirm && this.population.populationId) {
    this.isDeleting = true;
    const deletePayload = this.originalPhoneLines.filter(line => line.contactUsId !== this.phoneLine.contactUsId);

    this.contactUsApiService.updateContactUsForPopulation(this.population['populationId'], deletePayload).subscribe({
      next : () => {
        this.phoneLines = this.phoneLines.filter(line => line.contactUsId !== this.phoneLine.contactUsId);
        this.originalPhoneLines = this.originalPhoneLines.filter(line => line.contactUsId !== this.phoneLine.contactUsId);
        this.alerts.deletePhoneLineSuccess = 'Phone Line has been successfully deleted';
        this.isDeleting = false;
        this.confirmingDelete = false;
      },
      error: (error: any) => {
        this.alerts.deletePhoneLineFail = 'Failed to delete phone line.';
        this.isDeleting = false;
        this.confirmingDelete = false;
      }
    }
    );
  } else {
    this.confirmingDelete = false;
  }
}

isLastPhoneLine():boolean {
  return this.phoneLines.indexOf(this.phoneLine) === this.phoneLines.length - 1;
}

addPhoneLine():void {
  //this.phoneLines.push({});
  this.addPhoneLineEvent.emit();
}

private formatPhoneNumber(value: string): string {
  // Format as XXX.XXX.XXXX
  return value.replace(/(\d{3})(\d{3})(\d{4})/, '$1.$2.$3');
}

}
