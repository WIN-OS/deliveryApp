import { Component } from '@angular/core';

@Component({
  selector: 'sat-claim-search',
  templateUrl: './claim-search.component.html',
  styleUrls: ['./claim-search.component.scss']
})
export class ClaimSearchComponent {

}
