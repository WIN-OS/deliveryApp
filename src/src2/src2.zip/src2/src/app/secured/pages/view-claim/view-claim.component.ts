import { Component } from '@angular/core';

@Component({
  selector: 'sat-view-claim',
  templateUrl: './view-claim.component.html',
  styleUrls: ['./view-claim.component.scss']
})
export class ViewClaimComponent {

}
