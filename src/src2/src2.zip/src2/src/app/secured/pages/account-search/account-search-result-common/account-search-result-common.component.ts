/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/naming-convention */
import { Component, EventEmitter, Input, Output, inject } from '@angular/core';
import { AccountActivityHistoryApiService } from 'app/api/account-activity-history-api.service';
import { AccountSearchApiService } from 'app/api/account-search-api.service';
import { AccountSettingsApiService } from 'app/api/account-settings-api.service';
import { ApiErrorMessageService } from 'app/core/api-error-message.service';
import { PaginationService } from 'app/shared/services/pagination.service';
import { RouteHelperService } from 'app/shared/services/route-helper.service';

@Component({
  selector: 'sat-account-search-result-common',
  templateUrl: './account-search-result-common.component.html',
  styleUrls: ['./account-search-result-common.component.scss']
})
export class AccountSearchResultCommonComponent {

  @Input() item: any ;
  @Input() baseId: string | undefined;
  routeHelperService = inject(RouteHelperService);
  accountSearchApiService = inject(AccountSearchApiService);
  @Output() goToAccountDetails = new EventEmitter<any>();

  
  SEARCH_PROPERTIES = {
    NPI: 'npi',
    PHONE: 'phoneNumber',
    EMAIL: 'email',
    TAX_ID: 'taxId',
    INVITED_USER_STATUS: '2'
};

  // invoked when an active property link is clicked to perform a new search
  performNewSearch(searchProperty:string, value:string):void{
    //search Query Obj
    const searchCriteria:  Record<string, any> = {
      accountStatus: null,
      accountNumber: null,
      email: null,
      taxId: null,
      phoneNumber: null,
      npi: null
      };

    // build an object with the search property and value to send to the account search service
      searchCriteria[searchProperty] = value;
      console.log('searchCriteria from performNewSearch: ',searchCriteria)
      // send the new search event - account search controllers will be listening
      this.accountSearchApiService.sendRequestNewSearchEvent(searchCriteria);
      this.accountSearchApiService.clickedLinkSubject.next(searchCriteria);
    }
}

      

