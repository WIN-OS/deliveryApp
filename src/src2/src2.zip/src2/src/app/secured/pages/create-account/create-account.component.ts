/* eslint-disable @typescript-eslint/no-unsafe-argument */
import { Component, OnInit, ChangeDetectionStrategy, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { ThemePalette } from '@angular/material/core';
import { ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { PageAlertService } from 'app/core/page-alert.service';
import { Router } from '@angular/router';
import { ICreateAccountForm, ICreateAccountFormPayload, ICreateAccountFormResponse } from 'app/shared/model/interfaces';
import { CreateAccountApiService } from 'app/api/create-api.service';
import { AccountSearchApiService } from 'app/api/account-search-api.service';
import { BehaviorSubject } from 'rxjs';
@Component({
  selector: 'sat-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CreateAccountComponent implements OnInit {
  npiTouched = false;
  firstNameTouched = false;
  lastNameTouched = false;
  emailTouched = false;
  taxIdTouched = false;
  phoneNumberTouched = false;
  confirmPasswordTouched =false;
  passwordCheckerHideFlag =true;
  title = 'Create Password Form';
  userInfoForm : FormGroup;
  isCreateAccountFailed = new BehaviorSubject<boolean>(false);
  
  constructor(private formBuilder: FormBuilder,
    private createAccountApi: CreateAccountApiService,
    private pageAlertsService: PageAlertService,
    private router: Router,
    private accountSearchApi: AccountSearchApiService
  ){
    
    this.userInfoForm = this.formBuilder.group({
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', [Validators.required]),
      title: new FormControl('', []),
      taxId: new FormControl('', [Validators.required, Validators.pattern('^\\d{2}-\\d{7}$')]),
      npi: new FormControl('', [Validators.required, Validators.pattern('^\\d{10}$')]),
      phoneNumber: new FormControl('', [Validators.required, Validators.pattern('^\\d{3}\\.\\d{3}\\.\\d{4}$')]),
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required]),
      confirmPassword: new FormControl('', [Validators.required]),
      deactivateClaimForm: new FormControl(false)
      });

    this.userInfoForm.setValidators(this.passwordMatchValidator());
  }


  passwordStrength = 0;
  hideShowLabel = 'Show';

  ngOnInit():void {
    console.log('Form');

  }


  createAccount(): void {
    // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
    if(this.userInfoForm.valid){
      const createAccountPayload = this.buildCreateAccountPayload();
      this.createAccountApi.createAccount(createAccountPayload)
      .subscribe({
        next: (response: ICreateAccountFormResponse) => this.createAccountSuccess(response),
        error: () => this.createAccountFailed() 
      });
    }
  }

  createAccountSuccess(responseObj:ICreateAccountFormResponse): void {
    this.isCreateAccountFailed.next(false);
    if(responseObj.status === '400'){
      this.isCreateAccountFailed.next(true);
    }
    this.router.navigate(['sat-account-details'],  { queryParams: { accountNumber: responseObj.accountNumber } }).then(() => {
      this.pageAlertsService.addSuccess('The new account has been created successfully.', 'createAccountSuccess');
    });
  }

  createAccountFailed():void {
      this.isCreateAccountFailed.next(true);
  }

   
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  buildCreateAccountPayload(): ICreateAccountFormPayload {
    const taxIdWithSplChar = this.userInfoForm.controls['taxId']?.value;
    const phoneNumberWithSplChar = this.userInfoForm.controls['phoneNumber']?.value;
    let taxIdWithOutSplChar = '';
    let phoneNumberWithOutSplChar = '';
    //remove spl chars
    if (taxIdWithSplChar) {
      taxIdWithOutSplChar = taxIdWithSplChar.replace(/-/g, '');
    }
    
    if (phoneNumberWithSplChar) {
      phoneNumberWithOutSplChar = phoneNumberWithSplChar.replace(/\./g, '');
    }

    return {
      billingFederalTaxId: taxIdWithOutSplChar,
      billingNPI: this.userInfoForm.controls['npi']?.value,
      billingPhoneNumber: phoneNumberWithOutSplChar,
      claimFormAccess: !this.userInfoForm.controls['deactivateClaimForm']?.value,
      userEmailAddress: this.userInfoForm.controls['email']?.value,
      userFirstName: this.userInfoForm.controls['firstName']?.value,
      userLastName: this.userInfoForm.controls['lastName']?.value,
      userTitle: this.userInfoForm.controls['title']?.value,
      userPassword: this.userInfoForm.controls['password']?.value,
    };
  }

  onStrengthChanged(strength: number):void{
  this.passwordStrength = strength;
  }

   passwordColor(): ThemePalette {
    if (this.passwordStrength > 80) {
      return 'primary'; // strong
    } else if (this.passwordStrength > 50) {
      return 'accent'; // medium
    } else {
      return 'warn'; // weak
    }
  }
  
  showPasswordToggle():void{
    this.passwordCheckerHideFlag = !this.passwordCheckerHideFlag;
    if(this.passwordCheckerHideFlag){
      this.hideShowLabel = 'Show';
    }
    else{
      this.hideShowLabel = 'Hide';
    }
  }
    
    //Validator functions
    passwordMatchValidator(): ValidatorFn {
      return (control: AbstractControl): ValidationErrors | null => {
        const password = this.userInfoForm.controls['password']?.value;
        const confirmPassword =  this.userInfoForm.controls['confirmPassword']?.value;
        // If both fields are filled and the values do not match, return an error
        if (password && confirmPassword && (password !== confirmPassword)) {
          return { 'passwordMismatch': true };
        }
        // If the confirmPassword field is empty, return an error
        if (confirmPassword === null || confirmPassword === '') {
          return { 'confirmPasswordEmpty': true };
        }
        return null;  // If there's no error, return null
      };
    }
    

}



