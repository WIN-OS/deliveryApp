/* eslint-disable @typescript-eslint/no-explicit-any */

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountSearchApiService } from 'app/api//account-search-api.service';
import { PageAlertService } from 'app/core/page-alert.service';
@Component({
  selector: 'sat-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.scss']
})
export class AccountDetailsComponent implements OnInit {
  account: any;
  fromAccountSearch = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private pageAlertsService: PageAlertService,
    //private accountSearchService: AccountSearchService,
    private accountSearchApi: AccountSearchApiService,
    //private 
  ) {
        // Check if an account was passed in via route parameters
        this.route.queryParams.subscribe(params => {
          if (params['account']) {
            // Set the account on the component and the fromAccountSearch flag to true
            this.account = params['account'];
            this.fromAccountSearch = true;
          } else if (params['accountNumber']) {
            // We only have the account number (i.e., from Create Account flow)
            // Call the Account Search API to get the full account details by account number
            this.accountSearchApi.search({
              accountNumber: params['accountNumber'],
              accountStatus: 'ALL'
            }).subscribe({
             next: (response => this.getAccountSuccess(response)),
              error :() => this.getAccountFail()
            });
          } else {
            console.log('param from URL: ', params['accountNumber']);
            console.log(params);
            // No account or accountNumber passed in
            // Redirect back to account search (without restoring any previous state)
           // this.router.navigate(['/sat-search-form']);
          }
        });
  }

  ngOnInit():void {
    console.log('');
  }

  goBackToSearchResults():void { 
    // Restore the previous account search state - TODO
   // this.accountSearchService.restoreAccountSearch();
  }

  accountLoaded(): boolean {
    // Checks if this component has an account object set
    return !!this.account;
  }


  private getAccountSuccess(response: any):void {
    const accounts = response.accounts;
    // Make sure we have a list of accounts with at least one item
    if (accounts && accounts.length > 0) {
      // Set the first item on the component
      this.account = accounts[0];
    } else {
      // No accounts in the response - trigger the fail scenario
      this.getAccountFail();
    }
  }

  private getAccountFail():void {
    // Route to account search and show an error message
    this.router.navigate(['/account-search']).then(() => {
      //TODO
     // this.pageAlertsService.addDanger('There was a problem loading the account details for Account #' + this.route.snapshot.params['accountNumber'] +
    //    '. Please search and try again.', 'getAccountApiFail');
    });
  }
}
