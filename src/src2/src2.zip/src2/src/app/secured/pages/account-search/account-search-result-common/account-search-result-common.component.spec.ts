import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountSearchResultCommonComponent } from './account-search-result-common.component';

describe('AccountSearchResultCommonComponent', () => {
  let component: AccountSearchResultCommonComponent;
  let fixture: ComponentFixture<AccountSearchResultCommonComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AccountSearchResultCommonComponent]
    });
    fixture = TestBed.createComponent(AccountSearchResultCommonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
