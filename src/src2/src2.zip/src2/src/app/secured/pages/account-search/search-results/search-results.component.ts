/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable, Subscription, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { AccountSearchApiService } from 'app/api/account-search-api.service';
import { ApiErrorMessageService } from 'app/core/api-error-message.service';
import { SaveStateService } from 'app/core/save-state.service';
import { IAccountSearchFormQuery } from 'app/shared/model/interfaces';
@Component({
  selector: 'sat-search-results',
  templateUrl: './search-results.component.html',
  styleUrls: ['./search-results.component.scss']
})
export class SearchResultsComponent implements OnInit, OnDestroy {
  private subscriptions: Subscription[] = [];

    //subscription to PerformNewSearch (when user clicks the link in detailed and standard view components)
    subscriptionToNewSearch: Observable<any> | undefined;
    incomingSearchQueryFromLinks :  Partial<IAccountSearchFormQuery> | undefined;
   // will be set to true after a search if no results were found
  noResultsFound = false;

  // will be set to true when pagination-wrapper is loading a new page
  pageLoading  = false;

  accountSearch = {
    searchResults: [],
    pagination: {
      currentPage : 0
    },
    searchType: '',
    totalItems: 0
  };


  private _accountSearchQuery: any;
  private _getNextAccountResultsErrorAlert: any;
  noResultsFoundMessage: string | undefined;
  searchDataFromIncomingQuery : any;

  constructor(
    private apiErrorMessageService: ApiErrorMessageService,
    private accountSearchApi: AccountSearchApiService
  ) {}


  ngOnInit(): void {
    // listen for the new search results and start new search events
    this.subscriptions.push(
      this.accountSearchApi.onNewSearchResults().subscribe(searchData =>  this.onNewSearchResults(searchData)),
      this.accountSearchApi.onClearSearchResults().subscribe(() => this.onClearSearchResults())
    );

  }



  // show/hide the entire results view until a search is performed
  showResultsView(): boolean {
     return this.hasSearchResults() || this.noResultsFound;
  }

  // checks if we have standard account search results
  hasAccountSearchResults(): boolean {
    return this.hasSearchResults() && !this.isDetailedSearch();
  }

  // checks if we have detailed account search results
  hasAccountSearchDetailedResults(): boolean {
    return this.hasSearchResults() && this.isDetailedSearch();
  }

  // dynamically set the header based on what type of search was performed
  getHeaderText(): string {
    return this.hasAccountSearchDetailedResults() ? 'Account Results' : 'Search Results';
  }

  // invoked when the Account Number is clicked on the account-search-result card
  goToAccountDetails(account: any): void {
     // go the the account details page for the selected account, pass in accountSearch so we can restore it if necessary
    this.accountSearchApi.saveStateAndGoToAccountDetails(account, this.accountSearch);
  }

  // invoked by pagination-wrapper to get the next page of results
  getNextAccountResultsPage(paginationState: any): any {
   return this.accountSearchApi.search(this._accountSearchQuery, paginationState)
      .pipe(
        // return the items and totalItems to pagination-wrapper
        map(response => ({
          items: response.data.accounts,
          totalItems: Number(response.data.totalElements)
        })),
        catchError(response => {
          // show an error message
          this._getNextAccountResultsErrorAlert = this.apiErrorMessageService.showPageAlertErrorMessage(response, 'getNextAccountResultsPageError');
          return of(null);
        })
      )
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(subscription => subscription.unsubscribe());
  }


  private hasSearchResults(): boolean {
    return this.accountSearch.searchResults.length > 0;
  }

  private isDetailedSearch(): boolean {
    return this.accountSearch.searchType === 'detailed';
  }

  private onNewSearchResults(searchData: any): void {
    console.log('onNewSearchResults : ', JSON.stringify(searchData));
    
    if((searchData?.responseData != null) && (searchData?.responseData != undefined )){
      const responseData = searchData.responseData;
      // set noResultsFound to true if totalElements = 0
      this.noResultsFound = (responseData.totalElements === 0);
      
      // check if we have results
      if (this.noResultsFound) {
        // no results found - show "No Results Found" if only one input type was searched,
        // otherwise show "No results found for this combination"
        this.noResultsFoundMessage = this.hasMultipleSearchInputs(searchData.query) ?
        'No results found for this combination' : 'No Results Found';
      } else {
        // set the necessary scope values
        this.accountSearch.searchResults = responseData.accounts;
        this.accountSearch.totalItems = Number(responseData.totalElements);
        this.accountSearch.searchType = searchData.type;
        // store a reference to the account search query object to use while paginating
        this._accountSearchQuery = searchData.query;
     }
    }
  }

  // check if the search query has multiple types of inputs
  private hasMultipleSearchInputs(searchQuery: any): boolean {
    let propertyCount = 0;
     // loop through each property on the search query object
    for (const searchProperty in searchQuery) {
      // ignore inherited properties and accountStatus (accountStatus is the filter and will always be present)
      if (Object.prototype.hasOwnProperty.call(searchQuery, searchProperty) && searchProperty !== 'accountStatus') {
        // add 1 to the property counter
        propertyCount++;

        // if we have more than 1 property, return true - we are searching by multiple property values
        if (propertyCount > 1) {
          return true;
        }
      }
    }
    // return false - more than one property was not found in the query
    return false;
  }

  private onClearSearchResults(): void {
    // close any error alerts
    this.closeGetNextAccountResultsErrorAlert();
    // set noResultsFound to false
    this.noResultsFound = false;
    // clear the current list when a new search is started
    this.accountSearch.searchResults = [];
     // go back to the first pagination page
    this.accountSearch.pagination.currentPage = 1;
    // clear the search type
    this.accountSearch.searchType = '';
    // clear the previous search query
    this._accountSearchQuery = null;
  }

  private closeGetNextAccountResultsErrorAlert(): void {
    this.apiErrorMessageService.closePageAlertErrorMessage();
  }

}
