/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, OnInit } from '@angular/core';
import { PopulationApiService } from 'app/api/population-api.service';
import { AuthenticationServiceInternal } from 'app/core/authentication.service';
import { IAdminUserResponse } from 'app/shared/model/interfaces';
import { catchError, map, Observable, throwError } from 'rxjs';
//import { ApiErrorMessageService } from 'common/api-error-message.service';


@Component({
  selector: 'sat-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.scss']
})
export class MessagesComponent implements OnInit {
  // start in readonly mode
  readOnly = true;
  populations: any[] | undefined;

  constructor(
      private authenticationServiceInternal: AuthenticationServiceInternal,
      private populationsApi: PopulationApiService
    ) { }
    //private apiErrorMessageService: ApiErrorMessageService,

  ngOnInit(): void {
    // get the user's profile to check access rights
    this.authenticationServiceInternal.getUserProfile().subscribe((response: IAdminUserResponse) => {
      // set the readonly flag - will be false if user has full access (super-user)
      this.readOnly = !response.hasFullAccess;
      console.log('response.hasFullAccess: ',response.hasFullAccess);
      if (!this.readOnly) {
        // get the list of populations to use in create/edit message views - only need this when not in readonly mode
        this.populationsApi.getAllPopulations().subscribe({
          next : (data: any) => 
            { 
              console.log('date from pop Api:', JSON.stringify(data));
              this.getAllPopulationsSuccess(data)
            },
          error: (error: any) => this.getAllPopulationsFail(error)
        }
        );
      }
    });
  }

  getAllPopulationsSuccess(response: { populationList: any[] | undefined; }): void {
    // set populations on the scope to bind to the child views
    this.populations = response.populationList;
  }

  getAllPopulationsFail(response: any): void {
    console.log('getAllPopulationsFail from msg compt');
    // show an error message
    //TODO
  //  this.apiErrorMessageService.showPageAlertErrorMessage(response, 'getAllPopulationsApiError',
  //    'There was an error loading the list of populations. Please refresh and try again.');
}
}
