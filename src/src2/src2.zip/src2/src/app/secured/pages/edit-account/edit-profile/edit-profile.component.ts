/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserProfileApiService } from 'app/api/user-profile-api.service';
import { PageAlertService } from 'app/core/page-alert.service';
import { ApiErrorMessageService } from 'app/shared/services/api-error-message.service';
import { catchError, Observable, Subscription } from 'rxjs';

@Component({
  selector: 'sat-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.scss']
})

export class EditProfileComponent {
  profileInfo: any = {};
  practiceInfo: any = {};
  billingInfo: any = {};
  userProfileLoaded = false;
  private alerts: any = {};
  accountNumber = '';
  userEmail = '';
  private subscriptions: Subscription[] = [];
  saveAccountInProgress = false;
  errorMessage: string | undefined;
  successMessage: string | undefined;

    constructor(
      private route: ActivatedRoute,
      private pageAlertsService: PageAlertService,
      private apiErrorMessageService: ApiErrorMessageService,
      private userProfileApiService: UserProfileApiService
    ) {
      //accountUserEmail accountNumber
      let account, user;
      // Check if an account was passed in via route parameters
      this.route.queryParams.subscribe(params => {
        if (params['account'] && params['user']) {
          this.accountNumber = params['account'];
          this.userEmail = params['user'];
          console.log('account: ', this.accountNumber, 'user: ',this.userEmail);
          if (this.accountNumber && this.userEmail) {
            this.userProfileApiService.getUserProfile(this.accountNumber, this.userEmail)
            .subscribe({
              next: ((response: any) => 
                {
                  console.log('response from getUserProfile: ',JSON.stringify(response));
                  this.loadUserProfileSuccess(response)
                }
              ),
              error: (response: any) => this.loadUserProfileFail(response)
            });
          } else {
            // Handle the case where account or user is not provided
            //this.alerts.loadUserProfileFail = this.apiErrorMessageService.showPageAlertErrorMessage(response, 'loadUserProfileFail');
          }
        }
      });
      
    }
    
    private loadUserProfileSuccess(response: any): void {
        const userProfile = response;

        // set the account number from the selected account
        this.profileInfo = {
            firstName: userProfile.userFirstName,
            lastName: userProfile.userLastName,
            emailAddress: userProfile.userEmailAddress,
            title: userProfile.userTitle,
            taxID: userProfile.federalTaxId,
            NPI: userProfile.npi,
            phoneNumber: userProfile.phoneNumber,
            accountNumber:  this.accountNumber
        };

        // practice info
        this.practiceInfo = {
            name: userProfile.practiceName,
            address: userProfile.practiceAddress
        };

        // billing info
        this.billingInfo = {
          name: userProfile.billingName,
          address: userProfile.billingAddress
        };
        
        // set the user profile loaded flag to true to show the form
        this.userProfileLoaded = true;
      }
  
      private loadUserProfileFail(response: any): void {
          this.alerts.loadUserProfileFail = this.apiErrorMessageService.showPageAlertErrorMessage(response, 'loadUserProfileFail');
      }
      
    //ngOnInit(): void {
      //this.subscriptions.push(
       //this.userProfileApiService.onNewSearchResults().subscribe(searchData =>  this.onNewSearchResults(searchData)),
     // );
    //}

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    saveProfile(updatedUserProfilePayload: any):void {
        this.closeAllAlerts();
        this.closeSaveAccountErrorMessage();
        console.log('edit-profile',JSON.stringify(updatedUserProfilePayload));
         this.userProfileApiService.updateUserProfile(
            this.profileInfo.accountNumber,
            this.profileInfo.emailAddress,
            updatedUserProfilePayload
        ).pipe(
          catchError((err) => {
            this.loadUserProfileFail(err);
            throw err;
          })
        ).subscribe({
          next: (response) => this.saveProfileSuccess(response),
          error: (err) => this.saveAccountFail(err)
        });
    }

    saveProfileSuccess(res:any): void {
      this.saveAccountInProgress = false;
      console.log('res from saveProfileSuccess:',res);
        this.alerts.updateUserProfileSuccess = this.pageAlertsService.addSuccess(
            "The user's profile has been updated successfully.",
            'updateUserProfileSuccess'
        );
        this.successMessage = "The user's profile has been updated successfully."
        this.updateUserInfo();
    }

    private saveAccountFail(response: any): void {
      let compileMessage: boolean;
  
      if (response.status === 400) {
        if (response.data.code === 'PROVERR') {
          this.errorMessage = [
            'We could not locate the practice and billing information for your account.',
            'Please make sure your Federal Tax ID, NPI and Phone Number are correct and try again.',
            'If you continue to receive the error, please contact',
            '<span mailto-apquestions account-number="' + this.profileInfo.accountNumber + '"></span>'
          ].join(' ');
        } else if (response.data.code === 'DUPUSER') {
          this.errorMessage = 'This email is already associated with a user on this account.';
        } else if (response.data.code === 'USERNOTFOUND') {
          this.errorMessage = 'This email and account combination being modified was not found. Was not able to make a change.';
        } else {
          this.errorMessage = response.data.userMessage;
        }
        compileMessage = true;
      } else {
        //this.errorMessage = this.apiErrorMessageService.GENERIC_MESSAGE;
        compileMessage = false;
      }

          /*
    this.saveAccountErrorAlert = this.pageAlertsService.addDanger(this.errorMessage, this.SAVE_ACCOUNT_ERROR_KEY, {
      trustedHTML: compileMessage,
      compileHTML: compileMessage
    });
    */

    this.saveAccountInProgress = false;
  }
  
  private closeSaveAccountErrorMessage(): void {
    //this.pageAlertsService.closeAlert(this.saveAccountErrorAlert);
  }

    private updateUserInfo(): void {
        const user = this.route.snapshot.data['user'];
        user.accountUserFirstName = this.profileInfo.firstName;
        user.accountUserLastName = this.profileInfo.lastName;
        user.accountUserEmail = this.profileInfo.emailAddress;
        user.accountUserTitle = this.profileInfo.title;
    }

    private buildUpdateUserProfilePayload(): any {
        return {
            firstName: this.profileInfo.firstName,
            lastName: this.profileInfo.lastName,
            emailAddress: this.profileInfo.emailAddress,
            title: this.profileInfo.title,
            taxID: this.profileInfo.taxID,
            NPI: this.profileInfo.NPI,
            phoneNumber: this.profileInfo.phoneNumber,
            practiceName: this.practiceInfo.name,
            practiceAddress: this.practiceInfo.address,
            billingName: this.billingInfo.name,
            billingAddress: this.billingInfo.address
        };
    }

    private closeAllAlerts(): void {
        //this.pageAlertsService.closeAll();
    }
}


/*
        // Check if an account was passed in via route parameters
        this.route.queryParams.subscribe(params => {
          if (params['account']) {
            // Set the account on the component and the fromAccountSearch flag to true
            this.account = params['account'];
            this.fromAccountSearch = true;
          } else if (params['accountNumber']) {
            // We only have the account number (i.e., from Create Account flow)
            // Call the Account Search API to get the full account details by account number
            this.accountSearchApi.search({
              accountNumber: params['accountNumber'],
              accountStatus: 'ALL'
            }).subscribe(
              response => this.getAccountSuccess(response),
              () => this.getAccountFail()
            );
          } else {
            console.log('param from URL: ', params['accountNumber']);
            console.log(params);
            // No account or accountNumber passed in
            // Redirect back to account search (without restoring any previous state)
           // this.router.navigate(['/sat-search-form']);
          }
        });
*/