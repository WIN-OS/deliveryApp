/* eslint-disable @typescript-eslint/no-explicit-any */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'sat-edit-population-benefits',
  templateUrl: './edit-population-benefits.component.html',
  styleUrls: ['./edit-population-benefits.component.scss']
})
export class EditPopulationBenefitsComponent implements OnInit {

  @Input() benefit: any;
  @Input() index: number | undefined;
  @Input() isLastBenefit: boolean | undefined;
  @Input() isOnlyBenefit: boolean | undefined;
  @Output() addBenefitAction = new EventEmitter<void>();
  @Output() deleteBenefitAction = new EventEmitter<any>();

  confirmingDelete = false;

  // set to true to show the delete confirmation panel
  startDeleteBenefit():void {
    // show the confirmation panel
    this.confirmingDelete = true;
  }

  ngOnInit(): void {
    
    console.log('benefit obj: ', JSON.stringify(this.benefit));
  }
  addBenefit():void {
    // invoke the bound add-benefit-action on the parent controller
    this.addBenefitAction.emit();
  }

  confirmDelete(shouldDelete: boolean):void {
    if (shouldDelete) {
      // invoke the bound delete-benefit-action on the parent controller
      this.deleteBenefitAction.emit({ benefit: this.benefit });
    } else {
      // confirmation canceled - do nothing and close the confirmation panel
      this.confirmingDelete = false;
    }
  }
}
