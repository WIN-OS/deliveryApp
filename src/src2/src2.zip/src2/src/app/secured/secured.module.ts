import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DynamicInputGroupComponent } from './components/dynamic-input-group/dynamic-input-group.component';
import { AccountDetailsComponent } from './pages/account-details/account-details.component';
import { AccountSearchComponent } from './pages/account-search/account-search.component';
import { ClaimSearchComponent } from './pages/claim-search/claim-search.component';
import { CreateAccountComponent } from './pages/create-account/create-account.component';
import { EditAccountComponent } from './pages/edit-account/edit-account.component';
import { EditContactUsComponent } from './pages/edit-contact-us/edit-contact-us.component';
import { EditPopulationsComponent } from './pages/edit-populations/edit-populations.component';
import { MessagesComponent } from './pages/messages/messages.component';
import { ReferenceTableComponent } from './pages/reference-table/reference-table.component';
import { ViewClaimComponent } from './pages/view-claim/view-claim.component';
import { SecuredRoutingModule } from './secured-routing.module';
import { SearchResultsComponent } from './pages/account-search/search-results/search-results.component';
import { AppMaterialModule } from '../shared/app-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SessionTimeoutComponent } from './components/session-timeout/session-timeout.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { SearchFormComponent } from './pages/account-search/search-form/search-form.component';
import { AccountSearchResultDetailedComponent } from './pages/account-search/account-search-result-detailed/account-search-result-detailed.component';
import { AccountSearchResultCommonComponent } from './pages/account-search/account-search-result-common/account-search-result-common.component';
import { AccountSearchApiService } from 'app/api/account-search-api.service';
import { PopulationApiService } from 'app/api/population-api.service';
import { AccountSettingsApiService } from 'app/api/account-settings-api.service';
import { AccountActivityHistoryApiService } from 'app/api/account-activity-history-api.service';
import { CoreModule } from 'app/core/core.module';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { IHttpClient } from 'app/shared/model/http-client.interface';
import { PaginationService } from 'app/shared/services/pagination.service';
import { PaginationWrapperDirective } from 'app/shared/directives/pagination-wrapper.directive';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PhonePipe, TaxIdPipe } from 'app/shared/pipes/form.pipe';
import { PhoneNumberPipeDirective } from 'app/shared/directives/phone-number-pipe.directive';
import { TaxIdDirective } from 'app/shared/directives/tax-id.directive';
import { MatPasswordStrengthModule } from '@angular-material-extensions/password-strength';
import { CreateAccountApiService } from 'app/api/create-api.service';
import { LabelAddressDirective } from 'app/shared/directives/label-address.directive';
import { EditMessageFormComponent } from './pages/messages/edit-message-form/edit-message-form.component';
import { CreateMessageComponent } from './pages/messages/create-message/create-message.component';
import { EditMessageModalComponent } from './pages/messages/edit-message-modal/edit-message-modal.component';
import { ViewMessagesComponent } from './pages/messages/view-messages/view-messages.component';
import { MessagesApiService } from 'app/api/messages-api.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { VspDatepickerComponent } from 'app/shared/vsp-ui-components/vsp-datepicker/vsp-datepicker.component';
import { VspTimepickerComponent } from 'app/shared/vsp-ui-components/vsp-timepicker/vsp-timepicker.component';
import { EditAuthorizedUsersComponent } from './pages/edit-account/edit-authorized-users/edit-authorized-users.component';
import { EditPasswordComponent } from './pages/edit-account/edit-password/edit-password.component';
import { EditProfileComponent } from './pages/edit-account/edit-profile/edit-profile.component';
import { UserProfileApiService } from 'app/api/user-profile-api.service';
import { EditProfileFormComponent } from './pages/edit-account/edit-profile-form/edit-profile-form.component';
import { FillHeightDirective } from 'app/shared/directives/fill-height.directive';
import { ContactPipe } from '../shared/pipes/contact.pipe';
import { LoadingSpinnerComponent } from './components/loading-spinner/loading-spinner.component';
import { InputGroupComponent } from './components/input-group/input-group.component';
import { MatIconModule } from '@angular/material/icon';
import { EditPhoneLinesComponent } from './pages/edit-contact-us/edit-phone-lines/edit-phone-lines.component';
import { EditPhoneLineComponent } from './pages/edit-contact-us/edit-phone-line/edit-phone-line.component';
import { PhoneNumberFormatDirective } from 'app/shared/directives/phone-number-format.directive';
import { EditManualsComponent } from './pages/edit-manuals/edit-manuals.component';
import { EditManualComponent } from './pages/edit-manuals/edit-manual/edit-manual.component';
import { DragDropFileDirective } from 'app/shared/directives/drag-drop-file.directive';
import { EditPopulationBenefitsComponent } from './pages/edit-populations/edit-population-benefits/edit-population-benefits.component';
import { FormService } from 'app/core/form-service.service';
import { ArrayService } from 'app/core/array-service.service';
import { EditPasswordFormComponent } from './pages/edit-account/edit-password/edit-password-form/edit-password-form.component';
import { ChangeUserPasswordApiService } from 'app/api/change-user-password-api.service';

//all secured pages and components decalred in the secured module for security reasons
@NgModule({
  declarations: [
    DynamicInputGroupComponent,
    EditManualsComponent,
    AccountDetailsComponent,
    AccountSearchComponent,
    SearchFormComponent,
    SearchResultsComponent,
    ClaimSearchComponent,
    CreateAccountComponent,
    EditAccountComponent,
    EditContactUsComponent,
    MessagesComponent,
    ReferenceTableComponent,
    ViewClaimComponent,
    SessionTimeoutComponent,
    HeaderComponent,
    FooterComponent,
    AccountSearchResultDetailedComponent,
    AccountSearchResultCommonComponent,
    CreateAccountComponent,
    TaxIdPipe,
    TaxIdDirective,
    PhonePipe,
    PhoneNumberPipeDirective,
    PhoneNumberFormatDirective,
    PaginationWrapperDirective,
    LabelAddressDirective,
    EditMessageFormComponent,
    CreateMessageComponent,
    EditMessageModalComponent,
    ViewMessagesComponent,
    EditAuthorizedUsersComponent,
    EditPasswordComponent,
    EditProfileComponent,
    EditProfileFormComponent,
    FillHeightDirective,
    ContactPipe,
    LoadingSpinnerComponent,
    InputGroupComponent,
    EditPhoneLinesComponent,
    EditPhoneLineComponent,
    EditManualComponent,
    DragDropFileDirective,
    EditPopulationsComponent,
    EditPopulationBenefitsComponent,
    EditPasswordFormComponent
    
  ],
  providers : [
    AccountSearchApiService,
    AccountSettingsApiService,
    AccountActivityHistoryApiService,
    CreateAccountApiService,
    MessagesApiService,
    PopulationApiService,
    UserProfileApiService,
    ChangeUserPasswordApiService,
    FormService,
    ArrayService,
    TaxIdPipe,
    PhonePipe,
    { provide: IHttpClient, useExisting: HttpClient }
    
  ],
  imports: [
    CommonModule,
    SecuredRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    CoreModule,
    HttpClientModule,
    AppMaterialModule,
    BrowserAnimationsModule,
    MatPasswordStrengthModule,
    NgbModule,
    VspDatepickerComponent,
    VspTimepickerComponent,
    MatIconModule
    
  ]
})
export class SecuredModule { }

