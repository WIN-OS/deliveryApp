import { ILanguageModel } from 'src/app/shared/model/ilanguage-model';

const en: ILanguageModel = {
  languageName: 'en',
//dashboard:{
    // label1: string;
    // label2: string;
//}
}
export default en;